from fastapi import Depends, HTTPException, status
from fastapi.requests import Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select


from api.deps import get_async_session
from core.auth import current_active_user
from database import models
from schemas.auth import UserRead


async def check_project_access(
        request: Request,
        current_user: UserRead = Depends(current_active_user),
        db: AsyncSession = Depends(get_async_session)
):
    project_id = int(request.path_params['project_id'])

    if current_user.is_superuser:
        return current_user

    query = select(models.ProjectRole).where(
        models.ProjectRole.user_id == current_user.id,
        models.ProjectRole.project_id == project_id
    )
    result = await db.execute(query)
    project_role = result.scalar_one_or_none()

    if project_role is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You don't have access to this project."
        )

    return current_user