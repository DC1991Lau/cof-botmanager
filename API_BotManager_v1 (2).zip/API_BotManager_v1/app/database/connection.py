from sqlalchemy import MetaData, URL
from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeMeta, declarative_base
from contextlib import asynccontextmanager
from typing import AsyncGenerator
from config import settings
import logging

logger = logging.getLogger(__name__)

# Base declarativa com schema
metadata = MetaData(schema="BotManager")
Base: DeclarativeMeta = declarative_base(metadata=metadata)

class AsyncDBConnection:
    def __init__(self):
        self.connection_url = URL.create(
            drivername="mssql+aioodbc",
            query={"odbc_connect": self._build_connection_string()}
        )

        self.engine: AsyncEngine = create_async_engine(
            self.connection_url,
            pool_pre_ping=True,
            pool_recycle=3600,
        )

        self.async_session_factory = async_sessionmaker(
            bind=self.engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )

        logger.info("Async database engine initialized")

    def _build_connection_string(self) -> str:
        if not settings.db_username:
            return (
                f"DRIVER={settings.db_driver};"
                f"SERVER={settings.db_server};"
                f"DATABASE={settings.db_database};"
                f"Trusted_Connection=YES;"
            )
        return (
            f"DRIVER={settings.db_driver};"
            f"SERVER={settings.db_server};"
            f"DATABASE={settings.db_database};"
            f"UID={settings.db_username};"
            f"PWD={settings.db_password}"
        )

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        async with self.async_session_factory() as session:
            try:
                yield session
            finally:
                await session.close()

    async def create_tables(self):
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Tables created")

    async def dispose(self):
        await self.engine.dispose()
        logger.info("Engine disposed")
