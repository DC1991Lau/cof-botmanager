import os

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configurações da aplicação"""

    # Geral Settings
    PROJECT_NAME: str = os.environ.get("PROJECT_NAME") or 'API_BotManager'
    VERSION: str = os.environ.get("VERSION") or 'v1'

    # DB Settings
    db_driver: str = os.getenv('DB_DRIVER') or 'ODBC Driver 17 for SQL Server'
    db_server: str = os.getenv('DB_SERVER') or 'PF26P05S'
    db_database: str = os.getenv('DB_DATABASE') or 'ServiceGate'
    db_username: str | None = os.getenv('DB_USERNAME') or None
    db_password: str | None = os.getenv('DB_PASSWORD') or None

    #Auth
    SECRET_KEY: str = os.getenv('SECRET') or 'SECRET'
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES') or 60)

    # Logging
    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Instância global das configurações
settings = Settings()