from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI

from api.api_router import api_router
from config import settings

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    # [] Create Admin User
    yield
    # Shutdown

#Create the App
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan,
)

# Add routes to the App
app.include_router(api_router)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)