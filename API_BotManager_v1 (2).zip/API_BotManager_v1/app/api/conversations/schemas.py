from pydantic import BaseModel
from typing import Optional, List, Union
from datetime import datetime
from fastapi_filter.contrib.sqlalchemy import Filter
from database.models import Conversation as ConversationModel

class ConversationBase(BaseModel):
    project_id: int
    sender_id: int
    number_user_messages: int = 0
    latest_input_channel: Optional[str] = None
    latest_event_time: Optional[datetime] = None
    in_training_data: bool = False
    evaluation: Optional[str] = None
    minimum_action_confidence: Optional[float] = None
    maximum_action_confidence: Optional[float] = None
    minimum_intent_confidence: Optional[float] = None
    maximum_intent_confidence: Optional[float] = None
    review_status: str = "unread"
    
    class Config:
        from_attributes = True

class ConversationUpdate(BaseModel):
    review_status: str = None

class ConversationCreate(ConversationBase):
    pass

class Message(BaseModel):
    id: int
    sender: str
    text: str
    intent: Optional[str] = None
    intent_ranking: Optional[str] = None
    confidence: Optional[float] = None
    timestamp: datetime
    
    class Config:
        from_attributes = True

class LastMessage(BaseModel):
    text: str
    timestamp: datetime
    is_bot: bool
    
    class Config:
        from_attributes = True

class Conversation(ConversationBase):
    id: int
    sender_key: str
    last_message: Optional[LastMessage] = None
    
    class Config:
        from_attributes = True

class ConversationDetail(Conversation):
    messages: List[Message]
    
    class Config:
        from_attributes = True

class ConversationFilter(Filter):
    project_id: int
    sender_id: Optional[int] = None
    number_user_messages: Optional[int] = None
    number_user_messages__gte: Optional[int] = None
    latest_input_channel: Optional[str] = None
    latest_event_time: Optional[datetime] = None
    in_training_data: Optional[bool] = None
    evaluation: Optional[str] = None
    minimum_action_confidence: Optional[float] = None
    maximum_action_confidence: Optional[float] = None
    minimum_intent_confidence: Optional[float] = None
    maximum_intent_confidence: Optional[float] = None
    
    class Constants(Filter.Constants):
        model = ConversationModel