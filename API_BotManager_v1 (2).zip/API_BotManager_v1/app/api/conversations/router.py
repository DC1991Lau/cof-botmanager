from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from api.deps import get_async_session
from api.conversations import crud, schemas

from fastapi_filter import FilterDepends

conversations_router = APIRouter()

@conversations_router.get("/conversations/", response_model=List[schemas.Conversation])
async def read_conversations(
    conversation_filter: schemas.ConversationFilter = FilterDepends(schemas.ConversationFilter),
    db: AsyncSession = Depends(get_async_session),
):
    db_conversations = await crud.get_conversations(db, conversation_filter)
    if db_conversations is None:
        raise HTTPException(status_code=404, detail="Conversations not found")
    return db_conversations

@conversations_router.get("/conversations/{conversation_id}", response_model=schemas.Conversation)
async def read_conversation(
    conversation_id: int,
    db: AsyncSession = Depends(get_async_session),
):
    conversation = await crud.get_conversation(db, conversation_id=conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    
    return conversation

@conversations_router.get("/conversations/{conversation_id}/detail", response_model=schemas.ConversationDetail)
async def read_conversation_detail(
    conversation_id: int,
    db: AsyncSession = Depends(get_async_session),
):
    conversation_detail = await crud.get_conversation_detail(db, conversation_id=conversation_id)
    if conversation_detail is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    
    return conversation_detail

@conversations_router.put("/conversations/{conversation_id}", response_model=schemas.ConversationBase)
async def update_conversation_status(conversation_id: int, conversation: schemas.ConversationUpdate, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.update_conversation_review_status(db, conversation_id, conversation)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return db_item