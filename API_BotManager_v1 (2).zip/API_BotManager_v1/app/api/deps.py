from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession

from database.connection import AsyncDBConnection

db = AsyncDBConnection()

# Dependency for FastAPI
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with db.get_session() as session:
        yield session
