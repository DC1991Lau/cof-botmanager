from fastapi import APIRouter
from api.auth.router import auth_router
from api.projects.router import projects_router
from api.conversations.router import conversations_router

api_router = APIRouter()

api_router.include_router(auth_router, tags=["auth"])
api_router.include_router(projects_router, tags=["projects"])
api_router.include_router(conversations_router, tags=["conversations"])
