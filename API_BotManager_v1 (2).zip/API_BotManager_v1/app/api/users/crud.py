from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database import models

async def get_users(db: AsyncSession):
    query = select(models.User)
    result = await db.execute(query)
    return result.scalars().all()

async def create_super_user():
    try:
        async with get_async_session_context() as session:
            async with get_user_db_context(session) as user_db:
                async with get_user_manager_context(user_db) as user_manager:
                    user = await user_manager.create(
                        UserCreate(
                            email="admin@botmanager.cofidis.pt", password="changeme", is_superuser=True
                        )
                    )
                    return user
    except UserAlreadyExists:
        print(f"Admin user already exists")
    finally:
        pass
