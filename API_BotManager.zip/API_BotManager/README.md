# TO-DO

[] Conversation Tables:
[] Model
[] Schemas
[] Functions

[] public.chat_tokens
[] public.configuration
[] public.data_tag
[] public.environment
[] public.git_repository
[] public.lookup_table

[x] public.conversation
[] public.conversation_action_metadata
[] public.conversation_action_statistic
[] public.conversation_entity_metadata
[] public.conversation_entity_statistic
[x] public.conversation_event
[] public.conversation_intent_statistic
[] public.conversation_policy_metadata
[] public.conversation_policy_statistic
[] public.conversation_session
[] public.conversation_statistic
[] public.conversation_to_tag_mapping

public.domain
public.domain_action
public.domain_entity
public.domain_intent
public.domain_slot

public.entity_synonym
public.entity_synonym_value

public.intent
public.intent_evaluation_result
public.intent_insight
public.intent_insight_configuration

public.message_correction
public.message_log
public.message_log_entity_metadata
public.message_log_to_tag_mapping

public.model
public.model_tag

public.nlu_evaluation
public.nlu_evaluation_prediction
public.nlu_insight_report
public.nlu_training_data
public.nlu_training_data_entity

public.regex_feature

public.response

public.story

public.temporary_intent_example

public.permission
public.project
public.rasa_x_user
public.user_role
public.user_role_mapping
public.workspace

"category_type": {
"type": "any",
"mappings": [
{
"type": "from_entity",
"entity": "category_type",
"conditions": [
{
"active_loop": "report_form",
"requested_slot": "category_type"
}
]
},
{
"type": "from_trigger_intent",
"intent": "anomalia_pc",
"value": "Anomalia no PC ou portátil",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "avaria_hardware",
"value": "Avaria no rato, teclado, monitor ou telefone",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "avaria_print",
"value": "Impossibilidade ou anomalia ao imprimir",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "pedido_app_interna",
"value": "Acesso a Aplicações internas",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "pedido_acesso_ext",
"value": "Acesso externos (sites, etc.)",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "pedido_internet",
"value": "internet",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "pedido_lista_email",
"value": "Lista de email",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "pedido_pasta_rede",
"value": "Pastas de rede",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "fraude_pedido_parecer_documentos_suspeitos",
"value": "Fraude - Pedido de Parecer Documentos Suspeitos",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "armada_atraso_na_disponibilizacao_da_informacao",
"value": "Atraso na disponibilização da informação",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "armada_dados_incorrectos",
"value": "Dados incorretos",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "infante_sagres_dados_desatualizados",
"value": "Dados desatualizados",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "mobilidades_sem_posto_trabalho",
"value": "Mobilidades",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "infante_sagres_dados_incorrectos",
"value": "Dados incorretos",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "executar_scripts",
"value": "Executar Scripts",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "soi_extrações",
"value": "Extrações",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "soi_análise&estudo",
"value": "Análise | Estudo",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "soi_relatório&dashboard",
"value": "Relatório | Dashboard",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "soi_anomalia",
"value": "Anomalia",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "activacao_iban_parceiro",
"value": "Activação de IBAN Parceiro",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "fraude_flag",
"value": "Fraude - Flag",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "sup_aplicacional_outros",
"value": "Outros",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "generico",
"value": "Generico",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "procedimentos",
"value": "Procedimentos",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "outras_regularizacoes",
"value": "Pedido de regularização",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "requisicao_material",
"value": "Requisição de material",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_trigger_intent",
"intent": "dah",
"value": "DAH",
"conditions": [
{
"active_loop": "report_form"
}
]
},
{
"type": "from_entity",
"entity": "category_type"
}
]
},
