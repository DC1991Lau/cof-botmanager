
CREATE TABLE [BotManager].models (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NULL, 
	model_id VARCHAR(255) NULL, 
	json VARCHAR(max) NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id)
)


GO
