
CREATE TABLE [BotManager].rasa_session (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	conversation_id INTEGER NOT NULL, 
	timestamp DATETIME NULL, 
	start_sequence_number INTEGER NULL, 
	end_sequence_number INTEGER NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_session_timestamp] ON [BotManager].[rasa_session] (timestamp)
GO
