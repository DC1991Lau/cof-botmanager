
CREATE TABLE [BotManager].rasa_user_message (
	id INTEGER NOT NULL IDENTITY, 
	event_id INTEGER NULL, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	session_id INTEGER NULL, 
	conversation_id INTEGER NOT NULL, 
	intent VARCHAR(255) NULL, 
	intent_ranking VARCHAR(max) NULL, 
	confidence FLOAT NULL, 
	text VARCHAR(max) NULL, 
	timestamp DATETIME NULL, 
	model_id VARCHAR(255) NULL, 
	sequence_number INTEGER NULL, 
	message_id VARCHAR(255) NULL, 
	PRIMARY KEY (id), 
	UNIQUE (event_id), 
	FOREIGN KEY(event_id) REFERENCES [BotManager].rasa_event (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES [BotManager].rasa_session (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_user_message_intent] ON [BotManager].[rasa_user_message] (intent)
GO
CREATE INDEX [ix_BotManager_rasa_user_message_timestamp] ON [BotManager].[rasa_user_message] (timestamp)
GO
