
CREATE TABLE [BotManager].rasa_sender (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	sender_key VARCHAR(255) NULL, 
	channel VARCHAR(255) NULL, 
	first_seen DATETIME NULL, 
	last_seen DATETIME NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uix_project_sender UNIQUE (project_id, sender_key), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_sender_sender_key] ON [BotManager].[rasa_sender] (sender_key)
GO
