
CREATE TABLE [BotManager].projects (
	id INTEGER NOT NULL IDENTITY, 
	name VARCHAR(255) NOT NULL, 
	description VARCHAR(255) NULL, 
	url_connection VARCHAR(255) NOT NULL, 
	port INTEGER NOT NULL, 
	queue_name VARCHAR(255) NOT NULL, 
	active_model VARCHAR(255) NULL, 
	active BIT NOT NULL, 
	PRIMARY KEY (id)
)


GO
CREATE UNIQUE INDEX [ix_BotManager_projects_name] ON [BotManager].[projects] (name)
GO
