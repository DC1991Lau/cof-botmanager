
CREATE TABLE [BotManager].annotations_data (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	text VARCHAR(max) NOT NULL, 
	annotated_intent VARCHAR(max) NULL, 
	timestamp DATETIME NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id)
)


GO
CREATE INDEX [ix_BotManager_annotations_data_id] ON [BotManager].[annotations_data] (id)
GO
