
CREATE TABLE [BotManager].nlu_inbox_items (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	conversation_id INTEGER NOT NULL, 
	message_id VARCHAR(max) NOT NULL, 
	text VARCHAR(max) NOT NULL, 
	predicted_intent VARCHAR(max) NULL, 
	intent_ranking VARCHAR(max) NULL, 
	confidence FLOAT NULL, 
	is_correct BIT NULL, 
	annotated_intent VARCHAR(max) NULL, 
	annotated_at DATETIME NULL, 
	timestamp DATETIME NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_nlu_inbox_items_id] ON [BotManager].[nlu_inbox_items] (id)
GO
