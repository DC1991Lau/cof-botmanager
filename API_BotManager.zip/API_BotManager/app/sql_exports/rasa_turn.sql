
CREATE TABLE [BotManager].rasa_turn (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	session_id INTEGER NULL, 
	conversation_id INTEGER NOT NULL, 
	start_sequence_number INTEGER NULL, 
	end_sequence_number INTEGER NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES [BotManager].rasa_session (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
