
CREATE TABLE [BotManager].rasa_event (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	session_id INTEGER NULL, 
	conversation_id INTEGER NOT NULL, 
	timestamp DATETIME NULL, 
	event_type VARCHAR(255) NULL, 
	model_id VARCHAR(255) NULL, 
	environment VARCHAR(255) NULL, 
	sequence_number INTEGER NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES [BotManager].rasa_session (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_event_timestamp] ON [BotManager].[rasa_event] (timestamp)
GO
CREATE INDEX [ix_BotManager_rasa_event_event_type] ON [BotManager].[rasa_event] (event_type)
GO
