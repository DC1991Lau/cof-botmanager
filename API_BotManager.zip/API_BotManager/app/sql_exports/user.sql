
CREATE TABLE [BotManager].[user] (
	id INTEGER NOT NULL IDENTITY, 
	email VARCHAR(320) NOT NULL, 
	hashed_password VARCHAR(1024) NOT NULL, 
	is_active BIT NOT NULL, 
	is_superuser BIT NOT NULL, 
	is_verified BIT NOT NULL, 
	PRIMARY KEY (id)
)


GO
CREATE UNIQUE INDEX [ix_BotManager_user_email] ON [BotManager].[user] (email)
GO
