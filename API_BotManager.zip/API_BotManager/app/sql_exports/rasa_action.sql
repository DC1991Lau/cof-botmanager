
CREATE TABLE [BotManager].rasa_action (
	id INTEGER NOT NULL IDENTITY, 
	event_id INTEGER NULL, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	session_id INTEGER NULL, 
	conversation_id INTEGER NOT NULL, 
	name VARCHAR(255) NULL, 
	confidence FLOAT NULL, 
	policy VARCHAR(255) NULL, 
	timestamp DATETIME NULL, 
	model_id VARCHAR(255) NULL, 
	sequence_number INTEGER NULL, 
	PRIMARY KEY (id), 
	UNIQUE (event_id), 
	FOREIGN KEY(event_id) REFERENCES [BotManager].rasa_event (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES [BotManager].rasa_session (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_action_name] ON [BotManager].[rasa_action] (name)
GO
CREATE INDEX [ix_BotManager_rasa_action_timestamp] ON [BotManager].[rasa_action] (timestamp)
GO
