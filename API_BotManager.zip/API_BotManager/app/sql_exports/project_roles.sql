
CREATE TABLE [BotManager].project_roles (
	id INTEGER NOT NULL IDENTITY, 
	user_id INTEGER NULL, 
	project_id INTEGER NULL, 
	role VARCHAR(255) NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES [BotManager].[user] (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id)
)


GO
