
CREATE TABLE [BotManager].conversations (
	id INTEGER NOT NULL IDENTITY, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	number_user_messages INTEGER NULL, 
	latest_input_channel VARCHAR(255) NULL, 
	latest_event_time DATETIME NULL, 
	minimum_action_confidence FLOAT NULL, 
	maximum_action_confidence FLOAT NULL, 
	minimum_intent_confidence FLOAT NULL, 
	maximum_intent_confidence FLOAT NULL, 
	review_status VARCHAR(50) NULL, 
	flagged BIT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE
)


GO
CREATE INDEX [ix_BotManager_conversations_project_id] ON [BotManager].[conversations] (project_id)
GO
