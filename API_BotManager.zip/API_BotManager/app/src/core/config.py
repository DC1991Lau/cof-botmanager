import os

class APPSettings:
    enable_swagger: bool = True
    appname: str = 'API_BotManager'
    version: str = '1.0.0'
    wrkrsrv_botmanager_api: str = os.getenv('WRKRSRV_BOTMANAGER_API') or 'http://localhost:8001/new-project'
    
class RabbitSettings:
    rabbit_username: str = os.getenv('RABBITMQ_USERNAME') or "dev"
    rabbit_password: str = os.getenv('RABBITMQ_PASSWORD') or "R@bdevbit"
    rabbit_host: str = os.getenv('RABBIT_HOST') or 'devdocker.cofidis.pt'
    rabbit_port: str = os.getenv('RABBIT_PORT') or 5672

class DBSettings:
    driver: str = os.getenv('DB_DRIVER') or 'ODBC Driver 17 for SQL Server'
    server: str = os.getenv('DB_SERVER') or 'PF26P05S'
    database: str = os.getenv('DB_DATABASE') or  'ServiceGate'
    username: str = os.getenv('DB_USERNAME')
    password: str = os.getenv('DB_PASSWORD')

APM = {'SERVICE_NAME': os.getenv('ApmName'),
       'SERVER_URL': os.getenv('ApmUrl'),
       'SECRET_TOKEN': os.getenv('ApmToken'),
       'ENVIRONMENT': os.getenv('ApmEnv'),
       'VERIFY_SERVER_CERT': False}

settings = APPSettings()
rabbit_settings = RabbitSettings()
db_settings = DBSettings()