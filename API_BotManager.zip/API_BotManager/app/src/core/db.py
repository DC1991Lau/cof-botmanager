from typing import AsyncGenerator

from sqlalchemy import MetaData
from sqlalchemy.engine.url import URL
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.ext.declarative import DeclarativeMeta, declarative_base

from src.core.config import db_settings
from src.lib.helpers import create_service_gate_scripts

if not db_settings.username:
    connection_string = f"DRIVER={db_settings.driver};SERVER={db_settings.server};DATABASE={db_settings.database};MARS_Connection=Yes;Trusted_Connection=YES;"
else:
    connection_string = f"DRIVER={db_settings.driver};SERVER={db_settings.server};DATABASE={db_settings.database};MARS_Connection=Yes;UID={db_settings.username};PWD={db_settings.password}"

connection_url = URL.create("mssql+aioodbc", query={"odbc_connect": connection_string})

engine = create_async_engine(connection_url)
async_session_maker = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

metadata = MetaData(schema='BotManager')

Base: DeclarativeMeta = declarative_base(metadata=metadata)

async def create_db_and_tables():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        create_service_gate_scripts(Base=Base, engine=engine)
    

async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_maker() as session:
        yield session

async def shutdown_async_session():
    await engine.dispose()