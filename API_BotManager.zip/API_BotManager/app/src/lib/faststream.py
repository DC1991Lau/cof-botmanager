from faststream.rabbit import RabbitQueue
from faststream.rabbit.fastapi import RabbitRouter
from faststream.rabbit.utils import build_url

from src.core.config import rabbit_settings

port = int(rabbit_settings.rabbit_port)

bot_manager_connection_string = build_url(host=rabbit_settings.rabbit_host, password=rabbit_settings.rabbit_password, login=rabbit_settings.rabbit_username, port=port, virtualhost="BotFactories")

bot_manager_router = RabbitRouter(bot_manager_connection_string)

bot_manager_queue = RabbitQueue("bot_manager", durable=True)
