import requests
from typing import Optional
from pydantic import BaseModel
from src.api.projects.schemas import ProjectCreate

def create_project(
    base_url: str,
    name: str,
    url_connection: str,
    port: int,
    queue_name: str,
    description: Optional[str] = None,
    active: bool = True,
    timeout: int = 30
) -> dict:
    """
    Create a new project by calling the project creation endpoint.
    
    Args:
        base_url (str): The base URL of the API (e.g., "http://localhost:8000")
        name (str): Name of the project
        url_connection (str): URL connection string
        port (int): Port number
        queue_name (str): Name of the queue for the project
        description (Optional[str]): Optional project description
        active (bool): Project status flag, defaults to True
        timeout (int): Request timeout in seconds
        
    Returns:
        dict: Response from the server containing project details
        
    Raises:
        requests.RequestException: If the request fails
        ValueError: If the response is not in the expected format
        Exception: For other unexpected errors
    """
    try:
        # Validate request data using Pydantic
        project_data = ProjectCreate(
            name=name,
            url_connection=url_connection,
            port=port,
            queue_name=queue_name,
            description=description,
            active=active
        )
        
        # Create the request URL
        url = f"{base_url.rstrip('/')}/projects"
        
        # Prepare the request data
        payload = project_data.model_dump(exclude_none=True)
        
        # Make the request
        response = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=timeout
        )
        
        # Raise for bad status codes
        response.raise_for_status()
        
        return response.json()
            
    except requests.RequestException as e:
        raise Exception(f"Failed to create project: {str(e)}")
    except ValueError as e:
        raise ValueError(f"Invalid project data: {str(e)}")
    except Exception as e:
        raise Exception(f"Unexpected error creating project: {str(e)}")
