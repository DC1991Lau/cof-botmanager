import os
from sqlalchemy.schema import CreateTable, CreateSchema

def create_service_gate_scripts(Base, engine):
    if not os.path.exists('sql_exports'):
        os.makedirs('sql_exports')

    for table in Base.metadata.sorted_tables:
        create_table_sql = str(CreateTable(table).compile(engine))
        create_table_sql += "\nGO\n"

        for index in table.indexes:
            schema = table.schema if table.schema else 'dbo'
            if not index.unique:
                create_index_sql = f"CREATE INDEX [{index.name}] ON [{schema}].[{table.name}] ({', '.join(index.columns.keys())})"
            else:
                create_index_sql = f"CREATE UNIQUE INDEX [{index.name}] ON [{schema}].[{table.name}] ({', '.join(index.columns.keys())})"
            create_table_sql += f"{create_index_sql}\nGO\n"
        with open(f'sql_exports/{table.name}.sql', 'w') as f:
            f.write(create_table_sql)