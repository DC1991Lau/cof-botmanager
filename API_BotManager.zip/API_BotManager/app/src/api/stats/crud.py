from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, distinct, select, and_, cast, text
from sqlalchemy.sql import expression
from sqlalchemy.types import DATE
from datetime import datetime, timedelta
from typing import List


from src import models
from src.api.stats import schemas

async def get_sessions_distribution(db: AsyncSession, filters: schemas.SessionsFilters) -> List[schemas.SessionsDistribution]:
    
    date_column = func.cast(models.RasaSession.timestamp, DATE).label('date')
    
    query = select(
        date_column,
        func.count().label('count')
    ).where(
        models.RasaSession.project_id == filters.project_id
    )
    
    
    query = filters.filter(query)
    
    
    query = query.group_by(
        date_column
    ).order_by(
        date_column
    )
    
    result = await db.execute(query)
    
    
    return [
        schemas.SessionsDistribution(timestamp=row.date.isoformat(), sessions=row.count)
        for row in result
    ]

async def get_sessions_per_channel(db: AsyncSession, filters: schemas.SessionsFilters) -> List[schemas.SessionsPerChannel]:
    query = select(
        models.RasaSender.channel,
        models.RasaSession.timestamp,
        func.count(distinct(models.RasaSession.id)).label('count')
    ).join(models.RasaSession, models.RasaSender.id == models.RasaSession.sender_id).where(
        models.RasaSession.project_id == filters.project_id
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaSender.channel,
        models.RasaSession.timestamp
    ).order_by(models.RasaSender.channel, 'timestamp')

    result = await db.execute(query)
    return [schemas.SessionsPerChannel(channel=row.channel, timestamp=row.timestamp, count=row.count) for row in result]

async def get_senders_distribution(db: AsyncSession, filters: schemas.SendersFilters) -> List[schemas.SendersDistribution]:
    # Extract date part from first_seen (SQL Server compatible)
    date_column = cast(models.RasaSender.first_seen, DATE).label('date')

    # Count of new users per day (distinct IDs first seen on that date)
    new_users_count = func.count(distinct(models.RasaSender.id)).label('new_users')

    # Base query to get new users per day
    base_query = select(
        date_column,
        new_users_count
    ).where(
        models.RasaSender.project_id == filters.project_id
    )

    # Apply dynamic filters (like date ranges)
    base_query = filters.filter(base_query)

    # Group by and order by date
    base_query = base_query.group_by(date_column).order_by(date_column)

    # Use this as a subquery for cumulative total
    subquery = base_query.subquery()

    # Final query to add cumulative total_users using window function
    final_query = select(
        subquery.c.date,
        subquery.c.new_users,
        func.sum(subquery.c.new_users).over(
            order_by=subquery.c.date
        ).label('total_users')
    ).order_by(subquery.c.date)

    # Execute the query
    result = await db.execute(final_query)

    # Format and return results
    return [
        schemas.SendersDistribution(
            timestamp=row.date.isoformat(),
            new_users=row.new_users,
            total_users=row.total_users
        )
        for row in result
    ]

async def get_senders_per_channel(db: AsyncSession, filters: schemas.SendersFilters) -> List[schemas.SendersPerChannel]:
    query = select(
        models.RasaSender.channel,
        models.RasaSender.last_seen.label('timestamp'),
        func.count(distinct(models.RasaSender.id)).label('count')
    ).where(models.RasaSender.project_id == filters.project_id)

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaSender.channel,
        models.RasaSender.last_seen
    ).order_by(models.RasaSender.channel, 'timestamp')

    result = await db.execute(query)
    return [schemas.SendersPerChannel(channel=row.channel, timestamp=row.timestamp, count=row.count) for row in result]

async def get_actions_distribution(db: AsyncSession, filters: schemas.ActionsFilters) -> List[schemas.ActionsDistribution]:
    
    date_column = func.cast(models.RasaAction.timestamp, DATE).label('date')
    
    query = select(
        date_column,
        models.RasaAction.name,
        func.count().label('count')
    ).where(
        and_(
            models.RasaAction.project_id == filters.project_id,
            models.RasaAction.name.isnot(None)
        )
    )

    query = filters.filter(query)

    query = query.group_by(
        date_column,
        models.RasaAction.name
    ).order_by(date_column, models.RasaAction.name)

    result = await db.execute(query)
    
    return [
        schemas.ActionsDistribution(
            timestamp=row.date.isoformat(),
            action=row.name,
            count=row.count
        ) for row in result
    ]

async def get_actions_per_channel(db: AsyncSession, filters: schemas.ActionsFilters) -> List[schemas.ActionsPerChannel]:
    query = select(
        models.RasaSender.channel,
        models.RasaAction.timestamp,
        models.RasaAction.name,
        func.count().label('count')
    ).join(
        models.RasaSender,
        models.RasaAction.sender_id == models.RasaSender.id
    ).where(
        and_(
            models.RasaAction.project_id == filters.project_id,
            models.RasaAction.name.isnot(None)
        )
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaSender.channel,
        models.RasaAction.timestamp,
        models.RasaAction.name
    ).order_by(models.RasaSender.channel, 'timestamp', models.RasaAction.name)

    result = await db.execute(query)
    return [
        schemas.ActionsPerChannel(
            channel=row.channel,
            timestamp=row.timestamp,
            action=row.name,
            count=row.count
        ) for row in result
    ]

async def get_top_actions(db: AsyncSession, filters: schemas.ActionsFilters) -> List[schemas.TopAction]:
    """Get the most frequently executed actions overall"""
    query = select(
        models.RasaAction.name,
        func.count().label('count')
    ).where(
        and_(
            models.RasaAction.project_id == filters.project_id,
            models.RasaAction.name.isnot(None)
        )
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaAction.name
    ).order_by(text('count DESC')).limit(10)

    result = await db.execute(query)
    return [
        schemas.TopAction(
            action=row.name,
            count=row.count
        ) for row in result
    ]

async def get_intents_distribution(db: AsyncSession, filters: schemas.IntentsFilters) -> List[schemas.IntentsDistribution]:
    
    date_column = func.cast(models.RasaUserMessage.timestamp, DATE).label('date')
    
    query = select(
        date_column,
        models.RasaUserMessage.intent,
        func.count().label('count')
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            models.RasaUserMessage.intent.isnot(None)
        )
    )

    query = filters.filter(query)

    query = query.group_by(
        date_column,
        models.RasaUserMessage.intent
    ).order_by(date_column, models.RasaUserMessage.intent)

    result = await db.execute(query)
    
    return [
        schemas.IntentsDistribution(
            timestamp=row.date.isoformat(),
            intent=row.intent,
            count=row.count
        ) for row in result
    ]

async def get_intents_per_channel(db: AsyncSession, filters: schemas.IntentsFilters) -> List[schemas.IntentsPerChannel]:
    query = select(
        models.RasaSender.channel,
        models.RasaUserMessage.timestamp,
        models.RasaUserMessage.intent,
        func.count().label('count')
    ).join(
        models.RasaSender,
        models.RasaUserMessage.sender_id == models.RasaSender.id
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            models.RasaUserMessage.intent.isnot(None)
        )
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaSender.channel,
        models.RasaUserMessage.timestamp,
        models.RasaUserMessage.intent
    ).order_by(models.RasaSender.channel, 'timestamp', models.RasaUserMessage.intent)

    result = await db.execute(query)
    return [
        schemas.IntentsPerChannel(
            channel=row.channel,
            timestamp=row.timestamp,
            intent=row.intent,
            count=row.count
        ) for row in result
    ]

async def get_top_intents(db: AsyncSession, filters: schemas.IntentsFilters) -> List[schemas.TopIntent]:
    """Get the most frequent intents overall"""
    query = select(
        models.RasaUserMessage.intent,
        func.count().label('count')
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            models.RasaUserMessage.intent.isnot(None)
        )
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaUserMessage.intent
    ).order_by(text('count DESC')).limit(10)

    result = await db.execute(query)
    return [
        schemas.TopIntent(
            intent=row.intent,
            count=row.count
        ) for row in result
    ]

async def get_response_time_distribution(db: AsyncSession, filters: schemas.ResponseTimeFilters) -> List[schemas.ResponseTimeDistribution]:
    # Subquery to get the next bot message after each user message
    bot_response = select(
        models.RasaBotMessage.session_id,
        models.RasaBotMessage.timestamp.label('bot_timestamp'),
        models.RasaUserMessage.timestamp.label('user_timestamp'),
        func.row_number().over(
            partition_by=models.RasaUserMessage.id,
            order_by=models.RasaBotMessage.timestamp
        ).label('rn')
    ).join(
        models.RasaUserMessage,
        and_(
            models.RasaBotMessage.session_id == models.RasaUserMessage.session_id,
            models.RasaBotMessage.timestamp > models.RasaUserMessage.timestamp
        )
    ).subquery()

    # Main query
    query = select(
        models.RasaUserMessage.timestamp,
        func.avg(
            func.datediff(
                text('millisecond'),
                bot_response.c.user_timestamp,
                bot_response.c.bot_timestamp
            )
        ).label('avg_response_time')
    ).join(
        bot_response,
        and_(
            models.RasaUserMessage.session_id == bot_response.c.session_id,
            bot_response.c.rn == 1  # Only get first bot response after each user message
        )
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            func.datediff(
                text('second'),
                bot_response.c.user_timestamp,
                bot_response.c.bot_timestamp
            ) <= 30
        )
    )

    query = filters.filter(query)

    query = query.group_by(models.RasaUserMessage.timestamp).order_by('timestamp')

    result = await db.execute(query)
    
    return [
        schemas.ResponseTimeDistribution(
            timestamp=row.timestamp,
            avg_response_time_ms=row.avg_response_time
        ) for row in result
    ]

async def get_response_time_per_channel(db: AsyncSession, filters: schemas.ResponseTimeFilters) -> List[schemas.ResponseTimePerChannel]:
    query = select(
        models.RasaSender.channel,
        models.RasaUserMessage.timestamp,
        func.avg(
            func.datediff(
                text('millisecond'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            )
        ).label('avg_response_time')
    ).select_from(
        models.RasaUserMessage
    ).join(
        models.RasaBotMessage,
        and_(
            models.RasaBotMessage.session_id == models.RasaUserMessage.session_id,
            models.RasaBotMessage.timestamp > models.RasaUserMessage.timestamp
        )
    ).join(
        models.RasaSender,
        models.RasaUserMessage.sender_id == models.RasaSender.id
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            func.datediff(
                text('second'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            ) <= 30
        )
    )

    query = filters.filter(query)
    
    query = query.group_by(
        models.RasaSender.channel,
        models.RasaUserMessage.timestamp
    ).order_by('timestamp', models.RasaSender.channel)

    result = await db.execute(query)
    return [
        schemas.ResponseTimePerChannel(
            channel=row.channel,
            timestamp=row.timestamp,
            avg_response_time_ms=row.avg_response_time
        ) for row in result
    ]

async def get_general_stats(db: AsyncSession, filters: schemas.StatsFilters) -> schemas.GeneralStats:
    
    # Total conversations
    total_conversations_query = select(func.count()).select_from(models.Conversation).where(
        models.Conversation.project_id == filters.project_id
    )
    total_conversations = await db.execute(total_conversations_query)
    
    # Filtered conversations
    filtered_conversations_query = select(func.count()).select_from(models.Conversation).where(
        models.Conversation.project_id == filters.project_id
    )
    filtered_conversations_query = filters.filter_by_model(filtered_conversations_query, models.Conversation)
    filtered_conversations = await db.execute(filtered_conversations_query)

    # Total sessions
    total_sessions_query = select(func.count()).select_from(models.RasaSession).where(
        models.RasaSession.project_id == filters.project_id
    )
    total_sessions = await db.execute(total_sessions_query)

    # Filtered sessions
    filtered_sessions_query = select(func.count()).select_from(models.RasaSession).where(
        models.RasaSession.project_id == filters.project_id
    )
    filtered_sessions_query = filters.filter_by_model(filtered_sessions_query, models.RasaSession)
    filtered_sessions = await db.execute(filtered_sessions_query)

    # Total users
    total_users_query = select(func.count()).select_from(models.RasaSender).where(
        models.RasaSender.project_id == filters.project_id
    )
    total_users = await db.execute(total_users_query)

    # Active users in filtered period
    active_users_query = select(func.count(distinct(models.RasaSender.id))).select_from(models.RasaSender).where(
        models.RasaSender.project_id == filters.project_id
    )
    active_users_query = filters.filter_by_model(active_users_query, models.RasaSender)
    active_users = await db.execute(active_users_query)

    # Global average response time
    global_avg_time_query = select(
        func.avg(
            func.datediff(
                text('millisecond'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            )
        )
    ).select_from(models.RasaUserMessage).join(
        models.RasaBotMessage,
        and_(
            models.RasaBotMessage.session_id == models.RasaUserMessage.session_id,
            models.RasaBotMessage.timestamp > models.RasaUserMessage.timestamp
        )
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            func.datediff(
                text('second'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            ) <= 30
        )
    )
    global_avg_time = await db.execute(global_avg_time_query)

    # Filtered average response time
    filtered_avg_time_query = select(
        func.avg(
            func.datediff(
                text('millisecond'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            )
        )
    ).select_from(models.RasaUserMessage).join(
        models.RasaBotMessage,
        and_(
            models.RasaBotMessage.session_id == models.RasaUserMessage.session_id,
            models.RasaBotMessage.timestamp > models.RasaUserMessage.timestamp
        )
    ).where(
        and_(
            models.RasaUserMessage.project_id == filters.project_id,
            func.datediff(
                text('second'),
                models.RasaUserMessage.timestamp,
                models.RasaBotMessage.timestamp
            ) <= 30
        )
    )
    filtered_avg_time_query = filters.filter_by_model(filtered_avg_time_query, models.RasaUserMessage)
    filtered_avg_time = await db.execute(filtered_avg_time_query)

    # --- Global confidence level
    confidence_level_query = select(
        func.avg(models.RasaUserMessage.confidence)
    ).select_from(models.RasaUserMessage).where(
        models.RasaUserMessage.project_id == filters.project_id
    )
    confidence_level = await db.execute(confidence_level_query)

    # --- Filtered confidence level
    filtered_confidence_level_query = select(
        func.avg(models.RasaUserMessage.confidence)
    ).select_from(models.RasaUserMessage).where(
        models.RasaUserMessage.project_id == filters.project_id
    )
    filtered_confidence_level_query = filters.filter_by_model(filtered_confidence_level_query, models.RasaUserMessage)
    filtered_confidence_level = await db.execute(filtered_confidence_level_query)

     # --- Users with more than one session ---

    total_users_result_for_retention_rate = await db.execute(select(func.count(models.RasaSender.id)).where(models.RasaSender.project_id == filters.project_id))
    total_users_for_retention_rate = total_users_result_for_retention_rate.scalar() or 1

    retained_users_query = (
    select(models.RasaAction.sender_id)
    .where(
        models.RasaAction.name == 'action_session_start',
        models.RasaAction.project_id == filters.project_id
    )
    .group_by(models.RasaAction.sender_id)
    .having(func.count(models.RasaAction.name) > 1)
)
    retained_users_result = await db.execute(select(func.count()).select_from(retained_users_query))
    retained_users = retained_users_result.scalar() or 0

    # --- Retention rate ---
    retention_rate = round((retained_users / total_users_for_retention_rate), 2)

    
    filtered_retained_users_query = filters.filter_by_model(retained_users_query, models.RasaAction )
    filtered_retained_users_result = await db.execute(select(func.count()).select_from(filtered_retained_users_query))
    filtered_retained_users = filtered_retained_users_result.scalar() or 0
    filtered_retention_rate = round((filtered_retained_users / total_users_for_retention_rate), 2)

    return schemas.GeneralStats(
        total_conversations=total_conversations.scalar() or 0,
        filtered_conversations=filtered_conversations.scalar() or 0,
        total_sessions=total_sessions.scalar() or 0,
        filtered_sessions=filtered_sessions.scalar() or 0,
        total_users=total_users.scalar() or 0,
        active_users=active_users.scalar() or 0,
        filtered_avg_response_time_ms=filtered_avg_time.scalar() or 0,
        global_avg_response_time_ms=global_avg_time.scalar() or 0,
        confidence_level=round(confidence_level.scalar() or 0, 4),
        filtered_confidence_level=round(filtered_confidence_level.scalar() or 0, 4),
        retention_rate=retention_rate,
        filtered_retention_rate= filtered_retention_rate
    )