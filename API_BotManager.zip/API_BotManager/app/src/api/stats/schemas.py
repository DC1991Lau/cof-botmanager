from pydantic import BaseModel
from datetime import datetime
from sqlalchemy import Select
from typing import List, Optional, Any, Type
from fastapi_filter.contrib.sqlalchemy import Filter
from src.models import RasaSession, Conversation, RasaSender, RasaAction, RasaUserMessage, RasaBotMessage


################# General Stats #######################
class BaseStatsFilter(Filter):
    """Base filter class that includes common filtering logic."""
    project_id: int

    class Constants(Filter.Constants):
        model = None

class StatsFilters(BaseStatsFilter):
    """
    Enhanced filter class that supports filtering across multiple models.
    Includes a custom filtering method that maps timestamp fields to appropriate models.
    """
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    def filter_by_model(self, query: Select, model_class: Type[Any]) -> Select:
        # Map each model to its corresponding timestamp field
        timestamp_fields = {
            RasaSession: RasaSession.timestamp,
            Conversation: Conversation.latest_event_time,
            RasaSender: RasaSender.last_seen,
            RasaUserMessage: RasaUserMessage.timestamp,
            RasaBotMessage: RasaBotMessage.timestamp,
            RasaAction: RasaAction.timestamp
        }
        
        # Get the appropriate timestamp field for the model
        timestamp_field = timestamp_fields.get(model_class)
        
        # If it's a subquery, you can't directly apply where to it
        if isinstance(query, Select):
            if timestamp_field:
                if self.timestamp__lt:
                    query = query.where(timestamp_field < self.timestamp__lt)
                if self.timestamp__gte:
                    query = query.where(timestamp_field >= self.timestamp__gte)

        return query

    class Constants(Filter.Constants):
        model = None

class GeneralStats(BaseModel):
    total_conversations: int
    filtered_conversations: int
    total_sessions: int
    filtered_sessions: int
    total_users: int
    active_users: int
    filtered_avg_response_time_ms: float
    global_avg_response_time_ms: float
    confidence_level: float
    filtered_confidence_level: float
    retention_rate: float
    filtered_retention_rate: float

################# Sessions #######################
class SessionsDistribution(BaseModel):
    timestamp: datetime
    sessions: int

class SessionsPerChannel(BaseModel):
    channel: str
    timestamp: datetime
    sessions: int

class SessionsFilters(Filter):
    project_id: int
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = RasaSession

################# Conversations #######################
class ConversationsDistribution(BaseModel):
    timestamp: datetime
    conversations: int
    total_conversations: int

class ConversationsPerChannel(BaseModel):
    channel: str
    timestamp: datetime
    conversations: int

class ConversationsFilters(Filter):
    project_id: int
    latest_event_time__lt: Optional[datetime] = None
    latest_event_time__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = Conversation

################# Users #######################
class SendersDistribution(BaseModel):
    timestamp: datetime
    new_users: int
    total_users: int

class SendersPerChannel(BaseModel):
    channel: str
    timestamp: datetime
    count: int

class SendersFilters(Filter):
    project_id: int
    last_seen__lt: Optional[datetime] = None
    last_seen__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = RasaSender

################# Actions #######################
class ActionsDistribution(BaseModel):
    action: str
    timestamp: datetime
    action: int

class ActionsPerChannel(BaseModel):
    action: str
    channel: str
    timestamp: datetime
    action: int

class TopAction(BaseModel):
    action: str
    count: int

class ActionsFilters(Filter):
    project_id: int
    name: Optional[str]
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = RasaAction

################# Intents #######################
class IntentsDistribution(BaseModel):
    intent: str
    timestamp: datetime
    intent: int

class IntentsPerChannel(BaseModel):
    channel: str
    timestamp: datetime
    intent: str
    intent: int

class TopIntent(BaseModel):
    intent: str
    count: int

class IntentsFilters(Filter):
    project_id: int
    intent: Optional[str] = None
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = RasaUserMessage

################# Response Time #######################
class ResponseTimeDistribution(BaseModel):
    timestamp: datetime
    avg_response_time_ms: float

class ResponseTimePerChannel(BaseModel):
    channel: str
    timestamp: datetime
    avg_response_time_ms: float

class ResponseTimeFilters(Filter):
    project_id: int
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = RasaBotMessage