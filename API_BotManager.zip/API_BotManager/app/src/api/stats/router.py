from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from src.api.stats import crud, schemas
from src.core.db import get_async_session
from fastapi_filter import FilterDepends

stats_router = APIRouter()

@stats_router.get("/stats/general", response_model=schemas.GeneralStats)
async def get_general_stats(
    filters: schemas.StatsFilters = FilterDepends(schemas.StatsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_general_stats(db, filters)
    return stats

@stats_router.get("/stats/sessions-distribution", response_model=List[schemas.SessionsDistribution])
async def get_sessions_distribution(
    filters: schemas.SessionsFilters = FilterDepends(schemas.SessionsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_sessions_distribution(db, filters)
    return stats

@stats_router.get("/stats/sessions-per-channel", response_model=List[schemas.SessionsPerChannel])
async def get_sessions_per_channel(
    filters: schemas.SessionsFilters = FilterDepends(schemas.SessionsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_sessions_per_channel(db, filters)
    return stats

@stats_router.get("/stats/senders-distribution", response_model=List[schemas.SendersDistribution])
async def get_senders_distribution(
    filters: schemas.SendersFilters = FilterDepends(schemas.SendersFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_senders_distribution(db, filters)
    return stats

@stats_router.get("/stats/senders-per-channel", response_model=List[schemas.SendersPerChannel])
async def get_senders_per_channel(
    filters: schemas.SendersFilters = FilterDepends(schemas.SendersFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_senders_per_channel(db, filters)
    return stats

@stats_router.get("/stats/actions-distribution", response_model=List[schemas.ActionsDistribution])
async def get_actions_distribution(
    filters: schemas.ActionsFilters = FilterDepends(schemas.ActionsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_actions_distribution(db, filters)
    return stats

@stats_router.get("/stats/actions-per-channel", response_model=List[schemas.ActionsPerChannel])
async def get_actions_per_channel(
    filters: schemas.ActionsFilters = FilterDepends(schemas.ActionsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_actions_per_channel(db, filters)
    return stats

@stats_router.get("/stats/top-actions", response_model=List[schemas.TopAction])
async def get_top_actions(
    filters: schemas.ActionsFilters = FilterDepends(schemas.ActionsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_top_actions(db, filters)
    return stats

@stats_router.get("/stats/intents-distribution", response_model=List[schemas.IntentsDistribution])
async def get_intents_distribution(
    filters: schemas.IntentsFilters = FilterDepends(schemas.IntentsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_intents_distribution(db, filters)
    return stats

@stats_router.get("/stats/intents-per-channel", response_model=List[schemas.IntentsPerChannel])
async def get_intents_per_channel(
    filters: schemas.IntentsFilters = FilterDepends(schemas.IntentsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_intents_per_channel(db, filters)
    return stats

@stats_router.get("/stats/top-intents", response_model=List[schemas.TopIntent])
async def get_top_intents(
    filters: schemas.IntentsFilters = FilterDepends(schemas.IntentsFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_top_intents(db, filters)
    return stats

@stats_router.get("/stats/avg-response-time", response_model=List[schemas.ResponseTimeDistribution])
async def get_response_time_distribution(
    filters: schemas.ResponseTimeFilters = FilterDepends(schemas.ResponseTimeFilters),
    db: AsyncSession = Depends(get_async_session)
):
    stats = await crud.get_response_time_distribution(db, filters)
    return stats