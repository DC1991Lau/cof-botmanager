from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import Optional, List, Union
from sqlalchemy import update

from src import models
from src.api.conversations import schemas


async def get_last_message(db: AsyncSession, conversation_id: int) -> Optional[Union[models.RasaBotMessage, models.RasaUserMessage]]:
    # Query last bot message
    bot_query = select(models.RasaBotMessage).filter(
        models.RasaBotMessage.conversation_id == conversation_id
    ).order_by(models.RasaBotMessage.timestamp.desc()).limit(1)
    
    # Query last user message 
    user_query = select(models.RasaUserMessage).filter(
        models.RasaUserMessage.conversation_id == conversation_id
    ).order_by(models.RasaUserMessage.timestamp.desc()).limit(1)
    
    # Execute both queries
    bot_result = await db.execute(bot_query)
    user_result = await db.execute(user_query)
    
    bot_message = bot_result.scalar_one_or_none()
    user_message = user_result.scalar_one_or_none()

    # Compare timestamps to find the most recent
    if bot_message and user_message:
        return bot_message if bot_message.timestamp > user_message.timestamp else user_message
    return bot_message or user_message

async def get_conversations(
    db: AsyncSession,
    conversation_filter: schemas.ConversationFilter,
) -> List[schemas.Conversation]:
    query = select(models.Conversation, models.RasaSender.sender_key).join(
        models.RasaSender,
        models.Conversation.sender_id == models.RasaSender.id
    )
    
    query = conversation_filter.filter(query)
    result = await db.execute(query)
    
    conversations = []
    for conversation, sender_key in result:
        last_message = await get_last_message(db, conversation.id)
        last_message_data = None
        
        if last_message:
            last_message_data = schemas.LastMessage(
                text=last_message.text,
                timestamp=last_message.timestamp,
                is_bot=isinstance(last_message, models.RasaBotMessage)
            )
            
        conversations.append(
            schemas.Conversation(
                **conversation.__dict__,
                sender_key=sender_key,
                last_message=last_message_data
            )
        )
    return conversations

async def get_conversation(db: AsyncSession, conversation_id: int) -> Optional[schemas.Conversation]:
    query = select(
        models.Conversation,
        models.RasaSender.sender_key
    ).join(
        models.RasaSender,
        models.Conversation.sender_id == models.RasaSender.id
    ).filter(models.Conversation.id == conversation_id)
    
    result = await db.execute(query)
    conversation_data = result.one_or_none()
    
    if not conversation_data:
        return None
        
    conversation, sender_key = conversation_data
    last_message = await get_last_message(db, conversation_id)
    
    return schemas.Conversation(
        **conversation.__dict__,
        sender_key=sender_key,
        last_message=last_message.text if last_message else None
    )

async def get_conversation_detail(db: AsyncSession, conversation_id: int) -> Optional[schemas.ConversationDetail]:
    query = select(models.Conversation, models.RasaSender.sender_key).join(
        models.RasaSender,
        models.Conversation.sender_id == models.RasaSender.id
    ).filter(models.Conversation.id == conversation_id)
    
    result = await db.execute(query)
    conversation, sender_key = result.one_or_none()
    
    if not conversation:
        return None
    
    user_messages_query = select(models.RasaUserMessage).filter(models.RasaUserMessage.conversation_id == conversation_id)
    bot_messages_query = select(models.RasaBotMessage).filter(models.RasaBotMessage.conversation_id == conversation_id)
    
    user_messages = await db.execute(user_messages_query)
    bot_messages = await db.execute(bot_messages_query)
    
    all_messages = []
    for msg in user_messages.scalars().all():
        all_messages.append(schemas.Message(id=msg.id, sender="user", text=msg.text, intent=msg.intent, intent_ranking=msg.intent_ranking, confidence= msg.confidence, timestamp=msg.timestamp))
    for msg in bot_messages.scalars().all():
        all_messages.append(schemas.Message(id=msg.id, sender="bot", text=msg.text, timestamp=msg.timestamp))
    
    all_messages.sort(key=lambda x: x.timestamp)
    
    return schemas.ConversationDetail(
        **conversation.__dict__,
        sender_key=sender_key,
        messages=all_messages
    )

async def update_conversation_review_status(db: AsyncSession, conversation_id: int, conversation: schemas.ConversationCreate):
    query = update(models.Conversation).where(models.Conversation.id == conversation_id)
    query = query.values(**conversation.model_dump(exclude_unset=True))
    query = query.returning(models.Conversation)
    result = await db.execute(query)
    await db.commit()
    return result.scalar_one_or_none()