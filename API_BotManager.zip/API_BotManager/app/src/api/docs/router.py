from fastapi import APIRouter

from fastapi.responses import RedirectResponse

docs_router = APIRouter()

# Redirect / -> Swagger-UI documentation
@docs_router.get("/")
def main_function():
    """
    # Redirect
    to documentation (`/docs/`).
    """
    return RedirectResponse(url="/docs")