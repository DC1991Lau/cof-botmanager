from pydantic import BaseModel
from typing import Optional, List

from src.models import Project as ProjectModel
from fastapi_filter.contrib.sqlalchemy import Filter

class ProjectBase(BaseModel):
    name: str
    description: Optional[str] = None
    url_connection: str
    port: int
    queue_name: str
    active: bool = True

class ProjectCreate(ProjectBase):
    pass

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    url_connection: Optional[str] = None
    port: Optional[int] = None
    queue_name: Optional[str] = None
    active: Optional[bool] = None

class Project(ProjectBase):
    id: int

    class Config:
        from_attributes = True

class UserBase(BaseModel):
    email: str

class User(UserBase):
    id: int

    class Config:
        from_attributes = True

class ProjectRoleCreate(BaseModel):
    user_id: int
    role: str

class ProjectRole(ProjectRoleCreate):
    id: int
    project_id: int

    class Config:
        from_attributes = True

class ProjectWithRoles(Project):
    roles: List[ProjectRole]

class UserInProject(BaseModel):
    id: int
    email: str
    role: str

    class Config:
        from_attributes = True

class ProjectUsers(BaseModel):
    id: int
    name: str
    users: List[UserInProject]

    class Config:
        from_attributes = True

class ProjectFilter(Filter):
    name: Optional[str] = None
    description: Optional[str] = None
    url_connection: Optional[str] = None
    port: Optional[int] = None
    queue_name: Optional[str] = None
    active: Optional[bool] = None

    class Constants(Filter.Constants):
        model = ProjectModel