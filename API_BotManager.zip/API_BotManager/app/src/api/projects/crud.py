from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, and_
from sqlalchemy.orm import joinedload
import aiohttp 
import logging

from src import models
from src.api.projects import schemas
from src.core.config import APPSettings


async def get_project(db: AsyncSession, project_id: int):
    query = select(models.Project).where(models.Project.id == project_id)
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def get_projects(db: AsyncSession,  project_filter: schemas.ProjectFilter):
    query = select(models.Project).order_by(models.Project.id)
    query = project_filter.filter(query)
    result = await db.execute(query)
    return result.scalars().all()

async def get_users(db: AsyncSession):
    query = select(models.User)
    result = await db.execute(query)
    return result.scalars().all()

async def create_project(
    db: AsyncSession, 
    project: schemas.ProjectCreate, 
    api_url: str = APPSettings.wrkrsrv_botmanager_api
) -> models.Project:
   
    try:
        # Create project in database
        db_project = models.Project(**project.model_dump())
        db.add(db_project)
        await db.flush()
        
        # Add admin project role
        db_project_role = models.ProjectRole(
            project_id=db_project.id,
            user_id=1,
            role="admin"
        )
        db.add(db_project_role)
        
        
        # Commit database transaction
        await db.commit()
        await db.refresh(db_project)

        # Make API GET call
        async with aiohttp.ClientSession() as session:
            async with session.get("http://127.0.0.1:8001/new-project") as response:
                if response.status not in (200, 201):
                    # Log API call failure but don't block project creation
                    error_text = await response.text()
                    logging.error(
                        f"API call failed for project {db_project.id}. "
                        f"Status: {response.status}, Response: {error_text}"
                    )
        
        # Refresh and return project
        return db_project
    
    except Exception as e:
        # Rollback in case of any error
        await db.rollback()
        logging.error(f"Project creation failed: {str(e)}")
        raise

async def update_project(db: AsyncSession, project_id: int, project: schemas.ProjectUpdate):
    query = update(models.Project).where(models.Project.id == project_id)
    query = query.values(**project.model_dump(exclude_unset=True))
    query = query.returning(models.Project)
    result = await db.execute(query)
    await db.commit()
    return result.scalar_one_or_none()

async def delete_project(db: AsyncSession, project_id: int):
    query = delete(models.Project).where(models.Project.id == project_id)
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0

async def get_project_users_with_roles(db: AsyncSession, project_id: int):
    query = select(models.ProjectRole).options(joinedload(models.ProjectRole.user)).where(models.ProjectRole.project_id == project_id)
    result = await db.execute(query)
    return result.unique().scalars().all()

async def add_user_to_project(db: AsyncSession, project_id: int, project_role: schemas.ProjectRoleCreate):
    db_project_role = models.ProjectRole(
        project_id=project_id,
        user_id=project_role.user_id,
        role=project_role.role
    )
    db.add(db_project_role)
    await db.commit()
    await db.refresh(db_project_role)
    return db_project_role

async def remove_user_from_project(db: AsyncSession, project_id: int, user_id: int):
    query = delete(models.ProjectRole).where(
        and_(
             models.ProjectRole.project_id == project_id,
            models.ProjectRole.user_id == user_id
        )
    )
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0

async def update_user_role_in_project(db: AsyncSession, project_id: int, user_id: int, new_role: str):
    query = update(models.ProjectRole).where(
        and_(
            models.ProjectRole.project_id == project_id,
            models.ProjectRole.user_id == user_id
        )
    ).values(role=new_role)
    result = await db.execute(query)
    await db.commit()

    query = select(models.ProjectRole).where(
        and_(
            models.ProjectRole.project_id == project_id,
            models.ProjectRole.user_id == user_id
        )
    )
    result = await db.execute(query)
    return result.scalar_one_or_none()