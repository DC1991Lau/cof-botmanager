from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from src.core.db import get_async_session
from src.api.auth.users import current_super_user, current_active_user
from src.api.auth.guards import check_project_access
from src.api.projects import crud
from src.api.projects import schemas

from fastapi_filter import FilterDepends

projects_router = APIRouter()

@projects_router.post("/projects/", response_model=schemas.Project, dependencies=[Depends(current_super_user)])
async def create_project(project: schemas.ProjectCreate, db: AsyncSession = Depends(get_async_session)):
    project_db = await crud.create_project(db=db, project=project)
    return project_db

@projects_router.get("/projects/", response_model=List[schemas.Project])
async def read_projects(
    db: AsyncSession = Depends(get_async_session), 
    project_filter: schemas.ProjectFilter = FilterDepends(schemas.ProjectFilter)):
    projects = await crud.get_projects(db, project_filter)
    return projects

@projects_router.get("/users/", response_model=List[schemas.User])
async def read_projects(
    db: AsyncSession = Depends(get_async_session), ):
    users = await crud.get_users(db)
    return users

@projects_router.get("/projects/{project_id}", response_model=schemas.Project)
async def read_project(project_id: int, db: AsyncSession = Depends(get_async_session)):
    db_project = await crud.get_project(db, project_id=project_id)
    if db_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return db_project

@projects_router.put("/projects/{project_id}", response_model=schemas.Project, dependencies=[Depends(current_super_user)])
async def update_project(project_id: int, project: schemas.ProjectUpdate, db: AsyncSession = Depends(get_async_session)):
    db_project = await crud.update_project(db, project_id=project_id, project=project)
    if db_project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return db_project

@projects_router.delete("/projects/{project_id}", response_model=bool, dependencies=[Depends(current_super_user)])
async def delete_project(project_id: int, db: AsyncSession = Depends(get_async_session)):
    success = await crud.delete_project(db, project_id=project_id)
    if not success:
        raise HTTPException(status_code=404, detail="Project not found")
    return True


@projects_router.get("/projects/{project_id}/users", response_model=schemas.ProjectUsers)
async def read_project_users(project_id: int, db: AsyncSession = Depends(get_async_session)):
    project = await crud.get_project(db, project_id=project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project_roles = await crud.get_project_users_with_roles(db, project_id=project_id)
    
    return schemas.ProjectUsers(
        id=project.id,
        name=project.name,
        users=[
            schemas.UserInProject(
                id=role.user.id,
                email=role.user.email,
                role=role.role
            ) for role in project_roles
        ]
    )

@projects_router.post("/projects/{project_id}/users", response_model=schemas.ProjectRole, dependencies=[Depends(current_super_user)])
async def add_user_to_project(project_id: int, project_role: schemas.ProjectRoleCreate, db: AsyncSession = Depends(get_async_session)):
    return await crud.add_user_to_project(db, project_id, project_role)

@projects_router.delete("/projects/{project_id}/users/{user_id}", response_model=bool, dependencies=[Depends(current_super_user)])
async def remove_user_from_project(project_id: int,user_id: int,db: AsyncSession = Depends(get_async_session)):
    success = await crud.remove_user_from_project(db, project_id, user_id)
    if not success:
        raise HTTPException(status_code=404, detail="User not found in project")
    return True

@projects_router.put("/projects/{project_id}/users/{user_id}", response_model=schemas.ProjectRole, dependencies=[Depends(current_super_user)])
async def update_user_role_in_project(project_id: int,user_id: int,new_role: str,db: AsyncSession = Depends(get_async_session)):
    updated_role = await crud.update_user_role_in_project(db, project_id, user_id, new_role)
    if updated_role is None:
        raise HTTPException(status_code=404, detail="User not found in project")
    return updated_role
