from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from src.models import NLUInboxItem as NLUInboxItemModel, AnnotationsData as AnnotationsDataModel
from fastapi_filter.contrib.sqlalchemy import Filter

class NLUInboxItemBase(BaseModel):
    project_id: int
    conversation_id: int
    message_id: str
    text: str
    predicted_intent: str
    intent_ranking: str
    confidence: float
    is_correct: bool = False
    is_deleted: bool = False

class NLUInboxItemCreate(NLUInboxItemBase):
    pass

class NLUInboxItemUpdate(BaseModel):
    annotated_intent: Optional[str] = None
    is_correct: Optional[bool] = None

class NLUInboxItem(NLUInboxItemBase):
    id: int
    message_id: str
    annotated_intent: Optional[str] = None
    timestamp: datetime
    annotated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class NLUInboxItemBulkUpdate(BaseModel):
    ids: List[int]
    action: str  # 'mark_correct' or 'delete'
    annotated_intent: Optional[str] = None  # Only for 'mark_correct' action


class NluInboxFilter(Filter):
    project_id: Optional[int] = None
    conversation_id: Optional[int] = None
    message_id: Optional[str] = None
    text: Optional[str] = None
    predicted_intent: Optional[str] = None
    confidence: Optional[int] = None
    confidence__gte: Optional[float] = None
    confidence__lte: Optional[float] = None
    is_correct: Optional[bool] = None # manter
    annotated_intent: Optional[str] = None
    annotated_intent__isnull: Optional[bool] = None

    class Constants(Filter.Constants):
        model = NLUInboxItemModel


class AnnotationsDataBase(BaseModel):
    project_id: int
    text: str
    annotated_intent: Optional[str] = None

class AnnotationsDataCreate(AnnotationsDataBase):
    pass

class AnnotationsData(AnnotationsDataBase):
    timestamp: datetime
    class Config:
        from_attributes = True

class AnnotationsDataUpdate(BaseModel):
    text: str
    annotated_intent: Optional[bool] = None

class AnnotationsDataFilter(Filter):
    project_id: Optional[int] = None
    text: Optional[str] = None
    annotated_intent: Optional[str] = None
    annotated_intent__isnull: Optional[bool] = None
    timestamp__lt: Optional[datetime] = None
    timestamp__gte: Optional[datetime] = None

    class Constants(Filter.Constants):
        model = AnnotationsDataModel