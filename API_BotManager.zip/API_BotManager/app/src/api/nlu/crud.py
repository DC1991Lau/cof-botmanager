from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, and_, func
from sqlalchemy.orm import joinedload
from src import models
from src.api.nlu import schemas
from typing import Optional
from datetime import datetime

async def get_nlu_inbox_item(db: AsyncSession, item_id: int):
    query = select(models.NLUInboxItem).where(models.NLUInboxItem.id == item_id)
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def get_nlu_inbox_items(db: AsyncSession, nlu_inbox_filter: schemas.NluInboxFilter):
    query = select(models.NLUInboxItem)
    query = nlu_inbox_filter.filter(query)
    # query = query.filter(models.NLUInboxItem.annotated_intent == None)
    result = await db.execute(query)
    return result.scalars().all()


async def create_nlu_inbox_item(db: AsyncSession, item: schemas.NLUInboxItemCreate):
    db_item = models.NLUInboxItem(**item.model_dump())
    db.add(db_item)
    await db.commit()
    await db.refresh(db_item)
    return db_item

async def update_nlu_inbox_item(db: AsyncSession, item_id: int, item: schemas.NLUInboxItemUpdate):
    query = update(models.NLUInboxItem).where(models.NLUInboxItem.id == item_id)
    update_data = item.model_dump(exclude_unset=True)
    if 'annotated_intent' in update_data:
        update_data['annotated_at'] = datetime.utcnow()
    query = query.values(**update_data)
    query = query.returning(models.NLUInboxItem)
    result = await db.execute(query)
    await db.commit()
    return result.scalar_one_or_none()

async def delete_nlu_inbox_item(db: AsyncSession, item_id: int):
    query = update(models.NLUInboxItem).where(models.NLUInboxItem.id == item_id).values(is_deleted=True)
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0

async def bulk_update_nlu_inbox_items(db: AsyncSession, update: schemas.NLUInboxItemBulkUpdate):
    if update.action == 'mark_correct':
        query = update(models.NLUInboxItem).where(models.NLUInboxItem.id.in_(update.ids)).values(
            is_correct=True,
            annotated_intent=update.annotated_intent,
            annotated_at=datetime.utcnow()
        )
    elif update.action == 'delete':
        query = update(models.NLUInboxItem).where(models.NLUInboxItem.id.in_(update.ids)).values(is_deleted=True)
    
    result = await db.execute(query)
    await db.commit()
    
    query = select(models.NLUInboxItem).where(models.NLUInboxItem.id.in_(update.ids))
    result = await db.execute(query)
    return result.scalars().all()

async def get_new_items_count(db: AsyncSession, project_id: int, filters: Optional[dict] = None):
    query = select(func.count(models.NLUInboxItem.id)).where(
        and_(
            models.NLUInboxItem.project_id == project_id,
            models.NLUInboxItem.is_correct == False,
            models.NLUInboxItem.is_deleted == False
        )
    )
    
    if filters:
        query = apply_filters(query, filters)
    
    result = await db.execute(query)
    return result.scalar_one()

def apply_filters(query, filters):
    if filters.get("conversation_id"):
        query = query.where(models.NLUInboxItem.conversation_id == filters["conversation_id"])
    if filters.get("message_id"):
        query = query.where(models.NLUInboxItem.message_id == filters["message_id"])
    if filters.get("text"):
        query = query.where(models.NLUInboxItem.text.ilike(f"%{filters['text']}%"))
    if filters.get("predicted_intent"):
        query = query.where(models.NLUInboxItem.predicted_intent == filters["predicted_intent"])
    if filters.get("annotated_intent"):
        query = query.where(models.NLUInboxItem.annotated_intent == filters["annotated_intent"])
    if filters.get("confidence_min") is not None:
        query = query.where(models.NLUInboxItem.confidence >= filters["confidence_min"])
    if filters.get("confidence_max") is not None:
        query = query.where(models.NLUInboxItem.confidence <= filters["confidence_max"])
    if filters.get("is_correct") is not None:
        query = query.where(models.NLUInboxItem.is_correct == filters["is_correct"])
    if filters.get("is_deleted") is not None:
        query = query.where(models.NLUInboxItem.is_deleted == filters["is_deleted"])
    if filters.get("timestamp_from"):
        query = query.where(models.NLUInboxItem.timestamp >= filters["timestamp_from"])
    if filters.get("timestamp_to"):
        query = query.where(models.NLUInboxItem.timestamp <= filters["timestamp_to"])
    if filters.get("annotated_at_from"):
        query = query.where(models.NLUInboxItem.annotated_at >= filters["annotated_at_from"])
    if filters.get("annotated_at_to"):
        query = query.where(models.NLUInboxItem.annotated_at <= filters["annotated_at_to"])
    return query

async def get_annotations_data(db: AsyncSession, annotation_data_filter: schemas.AnnotationsDataFilter):
    query = select(models.AnnotationsData)
    query = annotation_data_filter.filter(query)
    result = await db.execute(query)
    return result.scalars().all()

async def create_annotation_data_item(db: AsyncSession, item: schemas.AnnotationsDataCreate):
    db_item = models.AnnotationsData(**item.model_dump())
    db.add(db_item)
    await db.commit()
    await db.refresh(db_item)
    return db_item

async def update_annotation_data_item(db: AsyncSession, item_id: int, item: schemas.AnnotationsDataUpdate):
    query = update(models.AnnotationsData).where(models.AnnotationsData.id == item_id)
    update_data = item.model_dump(exclude_unset=True)
    query = query.values(**update_data)
    query = query.returning(models.AnnotationsData)
    result = await db.execute(query)
    await db.commit()
    return result.scalar_one_or_none()

async def delete_annotation_data_item(db: AsyncSession, item_id: int):
    query = update(models.AnnotationsData).where(models.AnnotationsData.id == item_id).values(is_deleted=True)
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0