from fastapi import APIRouter, HTTPException, Depends, Query
from src.core.db import get_async_session
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi_filter import FilterDepends

from typing import List

from src.api.nlu import schemas, crud

nlu_router = APIRouter()

        
@nlu_router.get("/nlu-inbox/", response_model=List[schemas.NLUInboxItem])
async def read_nlu_inbox_items(
    nlu_inbox_filter: schemas.NluInboxFilter = FilterDepends(schemas.NluInboxFilter),
    db: AsyncSession = Depends(get_async_session)
):
    items = await crud.get_nlu_inbox_items(db, nlu_inbox_filter)
    return items

@nlu_router.post("/nlu-inbox", response_model=schemas.NLUInboxItem)
async def create_nlu_inbox_item(item: schemas.NLUInboxItemCreate, db: AsyncSession = Depends(get_async_session)):
    return await crud.create_nlu_inbox_item(db=db, item=item)

@nlu_router.get("/nlu-inbox/{item_id}", response_model=schemas.NLUInboxItem)
async def read_nlu_inbox_item(item_id: int, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.get_nlu_inbox_item(db, item_id=item_id)
    if db_item is None:
        raise HTTPException(status_code=404, detail="NLU Inbox item not found")
    return db_item

@nlu_router.put("/nlu-inbox/{item_id}", response_model=schemas.NLUInboxItem)
async def update_nlu_inbox_item(item_id: int, item: schemas.NLUInboxItemUpdate, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.update_nlu_inbox_item(db, item_id=item_id, item=item)
    if db_item is None:
        raise HTTPException(status_code=404, detail="NLU Inbox item not found")
    return db_item

@nlu_router.delete("/nlu-inbox/{item_id}", response_model=schemas.NLUInboxItem)
async def delete_nlu_inbox_item(item_id: int, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.delete_nlu_inbox_item(db, item_id=item_id)
    if db_item is None:
        raise HTTPException(status_code=404, detail="NLU Inbox item not found")
    return db_item

@nlu_router.post("/nlu-inbox/bulk-update", response_model=List[schemas.NLUInboxItem])
async def bulk_update_nlu_inbox_items(update: schemas.NLUInboxItemBulkUpdate, db: AsyncSession = Depends(get_async_session)):
    return await crud.bulk_update_nlu_inbox_items(db, update=update)


##################################

@nlu_router.get("/annotations-data/", response_model=List[schemas.AnnotationsData])
async def read_annotations_data(
    nlu_inbox_filter: schemas.AnnotationsDataFilter = FilterDepends(schemas.AnnotationsDataFilter),
    db: AsyncSession = Depends(get_async_session)
):
    items = await crud.get_annotations_data(db, nlu_inbox_filter)
    return items

@nlu_router.post("/annotations-data", response_model=schemas.AnnotationsData)
async def create_annotations_data(item: schemas.AnnotationsDataCreate, db: AsyncSession = Depends(get_async_session)):
    return await crud.create_annotation_data_item(db=db, item=item)

@nlu_router.put("/annotations-data/{item_id}", response_model=schemas.AnnotationsData)
async def update_annotations_data(item_id: int, item: schemas.AnnotationsDataUpdate, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.update_annotation_data_item(db, item_id=item_id, item=item)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Annotation item not found")
    return db_item

@nlu_router.delete("/annotations-data/{item_id}", response_model=schemas.AnnotationsData)
async def delete_annotations_data(item_id: int, db: AsyncSession = Depends(get_async_session)):
    db_item = await crud.delete_annotation_data_item(db, item_id=item_id)
    if db_item is None:
        raise HTTPException(status_code=404, detail="Annotation item not found")
    return db_item