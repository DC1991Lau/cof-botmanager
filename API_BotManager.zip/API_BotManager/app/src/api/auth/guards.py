from typing import Callable

from fastapi import Depends, HTTPException, status
from fastapi.requests import Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from src import models

from src.core.db import get_async_session

from src.api.auth.users import current_active_user
from src.api.auth.schemas import UserRead

async def get_user_in_project(
    project_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(current_active_user)
):
    stmt = select(models.ProjectRole).where(
        models.ProjectRole.project_id == project_id,
        models.ProjectRole.user_id == current_user["id"]
    )
    result = await db.execute(stmt)
    user_role = result.scalar_one_or_none()
    if user_role is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is not part of this project"
        )
    return current_user

async def check_user_project_access(
    project_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user: UserRead = Depends(current_active_user)
):
  
    stmt = select(models.User).where(
        models.User.id == current_user.id
    )

    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if user.is_superuser:
        return current_user

    stmt = select(models.ProjectRole).where(
        models.ProjectRole.project_id == project_id,
        models.ProjectRole.user_id == current_user["id"]
    )
    result = await db.execute(stmt)
    user_role = result.scalar_one_or_none()
    
    if user_role is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User does not have access to this project"
        )
    return current_user

def user_has_project_access():
    async def dependency(
        project_id: int,
        db: AsyncSession = Depends(get_async_session),
        current_user: dict = Depends(current_active_user)
    ):
        return await check_user_project_access(project_id, db, current_user)
    return dependency

async def check_project_access(
    request: Request,
    current_user: UserRead = Depends(current_active_user),
    db: AsyncSession = Depends(get_async_session)
):
    project_id = int(request.path_params['project_id'])
    
    if current_user.is_superuser:
        return current_user

    query = select(models.ProjectRole).where(
        models.ProjectRole.user_id == current_user.id,
        models.ProjectRole.project_id == project_id
    )
    result = await db.execute(query)
    project_role = result.scalar_one_or_none()

    if project_role is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You don't have access to this project."
        )

    return current_user