from fastapi import APIRouter, Depends

from src.api.auth.users import auth_backend, fastapi_users, current_active_user
from src.api.auth.schemas import UserCreate, UserRead, UserUpdate

from src.api.projects.router import projects_router
from src.api.conversations.router import conversations_router
from src.api.stats.router import stats_router
from src.api.nlu.router import nlu_router

api_router = APIRouter()

api_router.include_router(
    fastapi_users.get_auth_router(auth_backend), prefix="/auth/jwt", tags=["auth"]
)
api_router.include_router(
    fastapi_users.get_register_router(UserRead, UserCreate),
    prefix="/auth",
    tags=["auth"],
)
api_router.include_router(
    fastapi_users.get_reset_password_router(),
    prefix="/auth",
    tags=["auth"],
)
api_router.include_router(
    fastapi_users.get_verify_router(UserRead),
    prefix="/auth",
    tags=["auth"],
)
api_router.include_router(
    fastapi_users.get_users_router(UserRead, UserUpdate),
    prefix="/users",
    tags=["users"],
)

api_router.include_router(projects_router, tags=["projects"], dependencies=[Depends(current_active_user)])
api_router.include_router(conversations_router, tags=["conversations"], dependencies=[Depends(current_active_user)])
api_router.include_router(nlu_router, tags=["nlu"], dependencies=[Depends(current_active_user)])
api_router.include_router(stats_router, tags=["stats"], dependencies=[Depends(current_active_user)])