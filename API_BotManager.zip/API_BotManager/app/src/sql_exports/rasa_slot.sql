
CREATE TABLE [BotManager].rasa_slot (
	id INTEGER NOT NULL IDENTITY, 
	event_id INTEGER NULL, 
	project_id INTEGER NOT NULL, 
	sender_id INTEGER NOT NULL, 
	session_id INTEGER NULL, 
	conversation_id INTEGER NOT NULL, 
	slot_path VARCHAR(255) NULL, 
	name VARCHAR(255) NULL, 
	value VARCHAR(max) NULL, 
	timestamp DATETIME NULL, 
	sequence_number INTEGER NULL, 
	PRIMARY KEY (id), 
	UNIQUE (event_id), 
	FOREIGN KEY(event_id) REFERENCES [BotManager].rasa_event (id), 
	FOREIGN KEY(project_id) REFERENCES [BotManager].projects (id), 
	FOREIGN KEY(sender_id) REFERENCES [BotManager].rasa_sender (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES [BotManager].rasa_session (id), 
	FOREIGN KEY(conversation_id) REFERENCES [BotManager].conversations (id)
)


GO
CREATE INDEX [ix_BotManager_rasa_slot_name] ON [BotManager].[rasa_slot] (name)
GO
CREATE INDEX [ix_BotManager_rasa_slot_timestamp] ON [BotManager].[rasa_slot] (timestamp)
GO
