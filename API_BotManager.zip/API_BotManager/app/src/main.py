from contextlib import asynccontextmanager

import urllib3
import uvicorn
from elasticapm.contrib.starlette import make_apm_client, ElasticAPM
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import aiohttp

from src.core.config import settings
from src.core.db import shutdown_async_session, create_db_and_tables
from src.api.auth.users import create_super_user
from src.api.router import api_router
from src.lib.apscheduler import scheduler, trigger

from src.core.config import APM


@asynccontextmanager
async def lifespan(app: FastAPI):
    await create_db_and_tables()
    await create_super_user()
    scheduler.start()

    yield

    scheduler.shutdown()
    await shutdown_async_session()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
app = FastAPI(title=settings.appname, version=settings.version, lifespan=lifespan)
# apm = make_apm_client(APM)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Set-Cookie"]
)
# app.add_middleware(ElasticAPM, client=apm)

app.include_router(api_router)


@app.get("/health")
async def health() -> dict:
    return {"message": 'A API_BotManager está online: v.{}'.format(settings.version)}


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=8000, reload=True)