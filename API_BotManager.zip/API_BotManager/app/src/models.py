from datetime import datetime

from fastapi_users_db_sqlalchemy import SQLAlchemyBaseUserTable
from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Boolean, UniqueConstraint, Index
from sqlalchemy.orm import relationship

from core.db import Base

class User(SQLAlchemyBaseUserTable[int], Base):
    __tablename__ = "user"

    id = Column(Integer, primary_key=True, autoincrement=True)
    projects = relationship("ProjectRole", back_populates="user")

class ProjectRole(Base):
    __tablename__ = "project_roles"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("user.id"))
    project_id = Column(Integer, ForeignKey("projects.id"))
    role = Column(String(255))

    user = relationship("User", back_populates="projects")
    project = relationship("Project", back_populates="roles")

class Project(Base):
    """Modelo para projetos Rasa"""
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True, index=True, nullable=False)
    description = Column(String(255))
    url_connection = Column(String(255), nullable=False)
    port = Column(Integer, nullable=False)
    queue_name = Column(String(255), nullable=False, index=True)
    active_model = Column(String(255))
    active = Column(Boolean, nullable=False, default=True, index=True)

    # Relações
    conversations = relationship("Conversation", back_populates="project", cascade="all, delete-orphan")
    senders = relationship("RasaSender", back_populates="project", cascade="all, delete-orphan")
    sessions = relationship("RasaSession", back_populates="project", cascade="all, delete-orphan")
    events = relationship("RasaEvent", back_populates="project", cascade="all, delete-orphan")
    nlu_inbox_items = relationship("NLUInboxItem", back_populates="project", cascade="all, delete-orphan")


class RasaSender(Base):
    """Modelo para remetentes/utilizadores"""
    __tablename__ = "rasa_sender"
    __table_args__ = (
        UniqueConstraint('project_id', 'sender_key', name='uix_project_sender'),
        Index('ix_sender_last_seen', 'last_seen'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_key = Column(String(255), nullable=False, index=True)
    channel = Column(String(255))
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False)

    # Relações
    project = relationship("Project", back_populates="senders")
    conversations = relationship("Conversation", back_populates="sender", cascade="all, delete-orphan")
    sessions = relationship("RasaSession", back_populates="sender", cascade="all, delete-orphan")
    events = relationship("RasaEvent", back_populates="sender", cascade="all, delete-orphan")


class Conversation(Base):
    """Modelo para conversas"""
    __tablename__ = "conversations"
    __table_args__ = (
        Index('ix_conv_project_sender', 'project_id', 'sender_id'),
        Index('ix_conv_latest_event', 'latest_event_time'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    number_user_messages = Column(Integer, default=0)
    latest_input_channel = Column(String(255))
    latest_event_time = Column(DateTime, index=True)

    # Métricas de confiança
    minimum_action_confidence = Column(Float)
    maximum_action_confidence = Column(Float)
    minimum_intent_confidence = Column(Float)
    maximum_intent_confidence = Column(Float)

    # Estado
    review_status = Column(String(50), default="unread", index=True)
    flagged = Column(Boolean, default=False, index=True)

    # Relações
    project = relationship("Project", back_populates="conversations")
    sender = relationship("RasaSender", back_populates="conversations")
    sessions = relationship("RasaSession", back_populates="conversation", cascade="all, delete-orphan")
    events = relationship("RasaEvent", back_populates="conversation", cascade="all, delete-orphan")


class RasaSession(Base):
    """Modelo para sessões"""
    __tablename__ = "rasa_session"
    __table_args__ = (
        Index('ix_session_sender_time', 'sender_id', 'timestamp'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False)
    start_sequence_number = Column(Integer, nullable=False)
    end_sequence_number = Column(Integer, nullable=False)

    # Relações
    project = relationship("Project", back_populates="sessions")
    sender = relationship("RasaSender", back_populates="sessions")
    conversation = relationship("Conversation", back_populates="sessions")
    events = relationship("RasaEvent", back_populates="session", cascade="all, delete-orphan")
    turns = relationship("RasaTurn", back_populates="session", cascade="all, delete-orphan")


class RasaEvent(Base):
    """Modelo base para todos os eventos"""
    __tablename__ = "rasa_event"
    __table_args__ = (
        Index('ix_event_conv_seq', 'conversation_id', 'sequence_number'),
        Index('ix_event_type_time', 'event_type', 'timestamp'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False)
    event_type = Column(String(255), nullable=False)
    model_id = Column(String(255))
    environment = Column(String(255))
    sequence_number = Column(Integer, nullable=False)

    # Relações
    project = relationship("Project", back_populates="events")
    sender = relationship("RasaSender", back_populates="events")
    session = relationship("RasaSession", back_populates="events")
    conversation = relationship("Conversation", back_populates="events")

    # Relações para eventos específicos (1-1)
    bot_message = relationship("RasaBotMessage", back_populates="event", uselist=False, cascade="all, delete-orphan")
    user_message = relationship("RasaUserMessage", back_populates="event", uselist=False, cascade="all, delete-orphan")
    action = relationship("RasaAction", back_populates="event", uselist=False, cascade="all, delete-orphan")
    slot = relationship("RasaSlot", back_populates="event", uselist=False, cascade="all, delete-orphan")


class RasaTurn(Base):
    """Modelo para turnos de conversa"""
    __tablename__ = "rasa_turn"
    __table_args__ = (
        Index('ix_turn_session_seq', 'session_id', 'start_sequence_number'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)
    start_sequence_number = Column(Integer, nullable=False)
    end_sequence_number = Column(Integer, nullable=False)

    # Relações
    session = relationship("RasaSession", back_populates="turns")


class RasaUserMessage(Base):
    """Modelo para mensagens do utilizador"""
    __tablename__ = "rasa_user_message"
    __table_args__ = (
        Index('ix_user_msg_intent', 'intent'),
        Index('ix_user_msg_confidence', 'confidence'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("rasa_event.id"), unique=True, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)

    # Dados da mensagem
    text = Column(String, nullable=False)
    intent = Column(String(255), index=True)
    intent_ranking = Column(String)  # JSON string
    confidence = Column(Float)
    message_id = Column(String(255))

    # Metadados
    timestamp = Column(DateTime, nullable=False)
    model_id = Column(String(255))
    sequence_number = Column(Integer, nullable=False)

    # Relações
    event = relationship("RasaEvent", back_populates="user_message")


class RasaBotMessage(Base):
    """Modelo para mensagens do bot"""
    __tablename__ = "rasa_bot_message"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("rasa_event.id"), unique=True, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)

    # Dados da mensagem
    text = Column(String, nullable=False)
    template_name = Column(String(255))

    # Metadados
    timestamp = Column(DateTime, nullable=False)
    model_id = Column(String(255))
    sequence_number = Column(Integer, nullable=False)

    # Relações
    event = relationship("RasaEvent", back_populates="bot_message")


class RasaAction(Base):
    """Modelo para ações executadas"""
    __tablename__ = "rasa_action"
    __table_args__ = (
        Index('ix_action_name', 'name'),
        Index('ix_action_confidence', 'confidence'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("rasa_event.id"), unique=True, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)

    # Dados da ação
    name = Column(String(255), nullable=False)
    confidence = Column(Float)
    policy = Column(String(255))

    # Metadados
    timestamp = Column(DateTime, nullable=False)
    model_id = Column(String(255))
    sequence_number = Column(Integer, nullable=False)

    # Relações
    event = relationship("RasaEvent", back_populates="action")


class RasaSlot(Base):
    """Modelo para eventos de slots"""
    __tablename__ = "rasa_slot"
    __table_args__ = (
        Index('ix_slot_name', 'name'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("rasa_event.id"), unique=True, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)

    # Dados do slot
    name = Column(String(255), nullable=False)
    value = Column(String)
    slot_path = Column(String(255))

    # Metadados
    timestamp = Column(DateTime, nullable=False)
    sequence_number = Column(Integer, nullable=False)

    # Relações
    event = relationship("RasaEvent", back_populates="slot")


class RasaSessionSlotState(Base):
    """Modelo para estado atual dos slots numa sessão"""
    __tablename__ = "rasa_session_slot_state"
    __table_args__ = (
        UniqueConstraint('session_id', 'name', name='uix_session_slot'),
        Index('ix_slot_state_session', 'session_id'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("rasa_sender.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(Integer, ForeignKey("rasa_session.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)

    # Estado do slot
    name = Column(String(255), nullable=False)
    value = Column(String)
    timestamp = Column(DateTime, nullable=False)


class NLUInboxItem(Base):
    """Modelo para items da inbox NLU para revisão"""
    __tablename__ = "nlu_inbox_items"
    __table_args__ = (
        Index('ix_nlu_inbox_project_timestamp', 'project_id', 'timestamp'),
        Index('ix_nlu_inbox_intent', 'predicted_intent'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), nullable=False)
    message_id = Column(String(255), nullable=False)

    # Dados NLU
    text = Column(String, nullable=False)
    predicted_intent = Column(String(255))
    intent_ranking = Column(String)  # JSON string
    confidence = Column(Float)

    # Anotações
    is_correct = Column(Boolean, default=False)
    annotated_intent = Column(String(255))
    annotated_at = Column(DateTime)

    # Metadados
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relações
    project = relationship("Project", back_populates="nlu_inbox_items")

class AnnotationsData(Base):
    __tablename__ = "annotations_data"

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    text = Column(String, nullable=False)
    annotated_intent = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="annotations_data")