# Worker ETL para Eventos Rasa

Worker assíncrono que consome eventos do Rasa a partir do RabbitMQ e processa-os para uma base de dados SQL Server.

## 🚀 Funcionalidades

- **Consumo dinâmico de filas**: Cria automaticamente subscritores para projetos ativos
- **Processamento de eventos**: Suporta todos os tipos de eventos Rasa (user, bot, action, slot, session_started)
- **Gestão de conversas**: Rastreia sessões, turnos e métricas de confiança
- **NLU Inbox**: Sistema de revisão para melhorar a precisão do NLU
- **Alta disponibilidade**: Usa filas quorum do RabbitMQ para resiliência

## 📋 Pré-requisitos

- Python 3.9+
- RabbitMQ 3.8+
- SQL Server 2016+
- Driver ODBC para SQL Server

## 🔧 Instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd rasa-etl-worker
```

2. Crie um ambiente virtual:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows
```

3. Instale as dependências:
```bash
pip install -r requirements.txt
```

4. Configure as variáveis de ambiente:
```bash
cp .env.example .env
# Edite o ficheiro .env com as suas configurações
```

## ⚙️ Configuração

Crie um ficheiro `.env` com as seguintes variáveis:

```env
# RabbitMQ
RABBITMQ_HOST=localhost
RABBITMQ_PORT=5672
RABBITMQ_USERNAME=guest
RABBITMQ_PASSWORD=guest
RABBITMQ_VHOST=/

# Base de dados
DB_DRIVER={ODBC Driver 17 for SQL Server}
DB_SERVER=localhost
DB_DATABASE=RasaDB
DB_USERNAME=sa
DB_PASSWORD=sua_password

# Logging
LOG_LEVEL=INFO
```

## 🏃 Execução

Para iniciar o worker:

```bash
python main.py
```

O worker irá:
1. Conectar ao RabbitMQ e SQL Server
2. Criar as tabelas se não existirem
3. Inicializar subscritores para todos os projetos ativos
4. Começar a consumir mensagens

## 📊 Estrutura da Base de Dados

### Tabelas Principais

- **projects**: Projetos/assistentes Rasa
- **rasa_sender**: Utilizadores/remetentes únicos
- **conversations**: Conversas agrupadas por remetente
- **rasa_session**: Sessões de conversa
- **rasa_event**: Todos os eventos recebidos
- **rasa_user_message**: Mensagens dos utilizadores
- **rasa_bot_message**: Respostas do bot
- **rasa_action**: Ações executadas
- **rasa_slot**: Valores de slots
- **nlu_inbox_items**: Items para revisão NLU

## 🔍 Monitorização

### Logs

O worker regista informações importantes:
- Conexões estabelecidas
- Subscritores criados/removidos
- Eventos processados
- Erros e exceções

### Métricas

Cada conversa rastreia:
- Número de mensagens do utilizador
- Confiança mínima/máxima das intenções
- Confiança mínima/máxima das ações
- Estado de revisão

## 🛠️ Desenvolvimento

### Estrutura do Projeto

```
├── main.py                 # Ponto de entrada
├── config.py              # Configurações
├── schemas.py             # Modelos Pydantic
├── database/
│   ├── connection.py      # Gestão de conexão
│   ├── models.py          # Modelos SQLAlchemy
│   └── crud.py            # Operações CRUD
└── services/
    ├── subscribers_manager.py  # Gestão de subscritores
    └── message_handler.py      # Processamento de mensagens
```

### Adicionar Novo Tipo de Evento

Para adicionar suporte a um novo tipo de evento:

1. Adicione o schema em `schemas.py`
2. Crie o modelo em `models.py`
3. Adicione o handler em `crud.py`:

```python
def _insert_novo_evento(self, event: RabbitEventMsgSchema, ...):
    # Implementar lógica do novo evento
    pass
```

4. Registe o handler no dicionário `event_handlers`

### Testes

Execute os testes com:

```bash
pytest tests/
```

## 🚨 Resolução de Problemas

### Worker não conecta ao RabbitMQ

1. Verifique se o RabbitMQ está a correr:
```bash
sudo systemctl status rabbitmq-server
```

2. Confirme as credenciais e permissões
3. Verifique se a porta 5672 está acessível

### Erros de Base de Dados

1. Confirme que o SQL Server está a correr
2. Verifique o driver ODBC instalado:
```bash
odbcinst -q -d
```

3. Teste a conexão:
```python
import pyodbc
conn = pyodbc.connect(connection_string)
```

### Mensagens não processadas

1. Verifique os logs para erros
2. Confirme que o projeto está ativo na base de dados
3. Verifique que o `queue_name` corresponde ao configurado no Rasa

## 📝 Notas Importantes

- **Remoção de subscritores**: O FastStream não suporta remoção dinâmica. Para remover subscritores, é necessário reiniciar o worker
- **Ordem dos eventos**: Os eventos são processados sequencialmente por conversa
- **Transações**: Cada evento é processado numa transação. Se falhar, faz rollback automático
- **Performance**: Para alto volume, considere múltiplas instâncias do worker

## 🤝 Contribuir

1. Fork o projeto
2. Crie uma branch para a funcionalidade (`git checkout -b feature/nova-funcionalidade`)
3. Commit as alterações (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a licença MIT - veja o ficheiro LICENSE para detalhes.