from sqlalchemy import URL, MetaData, create_engine
from sqlalchemy.orm import DeclarativeMeta, declarative_base, sessionmaker, Session
from contextlib import contextmanager
from typing import Generator
import logging

from config import settings

logger = logging.getLogger(__name__)


# Construir string de conexão
def _build_connection_string() -> str:
    """Constrói a string de conexão com base nas configurações"""
    if not settings.db_username:
        return (
            f"DRIVER={settings.db_driver};"
            f"SERVER={settings.db_server};"
            f"DATABASE={settings.db_database};"
            f"Trusted_Connection=YES;"
        )

    return (
        f"DRIVER={settings.db_driver};"
        f"SERVER={settings.db_server};"
        f"DATABASE={settings.db_database};"
        f"UID={settings.db_username};"
        f"PWD={settings.db_password}"
    )


# Criar URL de conexão
connection_url = URL.create(
    "mssql+pyodbc",
    query={"odbc_connect": _build_connection_string()}
)

# Metadata e base para modelos
metadata = MetaData(schema='BotManager')
Base: DeclarativeMeta = declarative_base(metadata=metadata)


class DBConnection:
    """
    Gestor de conexão à base de dados com SQLAlchemy
    """

    def __init__(self):
        """Inicializa a conexão e cria a fábrica de sessões"""
        self.engine = create_engine(
            connection_url,
            pool_pre_ping=True,  # Verifica conexões antes de usar
            pool_recycle=3600  # Recicla conexões a cada hora
        )

        self.SessionLocal = sessionmaker(
            bind=self.engine,
            class_=Session,
            expire_on_commit=False
        )

        logger.info("Conexão à base de dados inicializada")

    def get_session(self) -> Session:
        """Obtém uma nova sessão da base de dados"""
        return self.SessionLocal()

    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """
        Gestor de contexto para sessões com commit/rollback automático

        Exemplo:
            with db_connection.session_scope() as session:
                # fazer operações com a sessão
                pass
        """
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception as e:
            logger.error(f"Erro na transação: {e}")
            session.rollback()
            raise
        finally:
            session.close()

    def create_tables(self):
        """Cria todas as tabelas definidas nos modelos"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Tabelas criadas com sucesso")
        except Exception as e:
            logger.error(f"Erro ao criar tabelas: {e}")
            raise

    def close(self):
        """Fecha o motor da base de dados"""
        self.engine.dispose()
        logger.info("Conexão à base de dados fechada")


# Instância global da conexão
db_connection = DBConnection()