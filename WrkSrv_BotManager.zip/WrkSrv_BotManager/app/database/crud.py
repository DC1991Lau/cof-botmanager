import logging
from typing import Optional, List

from sqlalchemy import select, func
from sqlalchemy.orm import Session

from database.models import (
    Project, RasaSender, RasaSession, RasaEvent, RasaTurn,
    RasaBotMessage, RasaUserMessage, RasaAction, RasaSlot,
    RasaSessionSlotState, Conversation, NLUInboxItem
)
from schemas import RabbitEventMsgSchema

logger = logging.getLogger(__name__)


class RasaEventProcessor:
    """Processador de eventos Rasa"""

    def __init__(self, session: Session):
        self.session = session

    def process_event(self, event: RabbitEventMsgSchema, project_name: str):
        """Processa um evento Rasa completo"""
        try:
            # Obter projeto
            project = self._get_project(project_name)
            if not project:
                raise ValueError(f"Projeto {project_name} não encontrado")

            # Obter ou criar entidades principais
            sender = self._get_or_create_sender(event, project.id)
            conversation = self._get_or_create_conversation(sender, event, project.id)
            session = self._get_or_create_session(sender, conversation, event, project.id)
            turn = self._get_or_create_turn(session, conversation, event, project.id)

            # Inserir evento
            rasa_event = self._insert_event(event, session, conversation, project.id)

            # Atualizar métricas da conversa
            self._update_conversation_metrics(conversation, event)

            # Processar evento específico
            self._process_specific_event(event, rasa_event, conversation.id, project.id)

            # Atualizar números de sequência
            session.end_sequence_number = rasa_event.sequence_number
            turn.end_sequence_number = rasa_event.sequence_number

            self.session.commit()
            logger.info(f"Evento processado com sucesso: {project_name}, sender {event.sender_id}")

        except Exception as e:
            self.session.rollback()
            logger.error(f"Erro ao processar evento: {str(e)}")
            raise

    def _get_project(self, project_name: str) -> Optional[Project]:
        """Obtém projeto pelo nome"""
        return self.session.execute(
            select(Project).where(Project.name == project_name)
        ).scalars().first()

    def _get_or_create_sender(self, event: RabbitEventMsgSchema, project_id: int) -> RasaSender:
        """Obtém ou cria remetente"""
        sender = self.session.execute(
            select(RasaSender).where(
                RasaSender.sender_key == event.sender_id,
                RasaSender.project_id == project_id,
            )
        ).scalars().one_or_none()

        if sender:
            sender.last_seen = event.timestamp
            if event.event == 'user' and event.input_channel:
                sender.channel = event.input_channel
            return sender

        # Criar novo remetente
        new_sender = RasaSender(
            project_id=project_id,
            sender_key=event.sender_id,
            channel=event.input_channel or 'default',
            first_seen=event.timestamp,
            last_seen=event.timestamp
        )
        self.session.add(new_sender)
        self.session.flush()
        return new_sender

    def _get_or_create_conversation(self, sender: RasaSender, event: RabbitEventMsgSchema,
                                    project_id: int) -> Conversation:
        """Obtém ou cria conversa"""
        conversation = self.session.execute(
            select(Conversation).where(
                Conversation.sender_id == sender.id,
                Conversation.project_id == project_id
            ).order_by(Conversation.latest_event_time.desc())
        ).scalars().first()

        if conversation:
            conversation.latest_event_time = event.timestamp
            if event.event == 'user' and event.input_channel:
                conversation.latest_input_channel = event.input_channel
            return conversation

        # Criar nova conversa
        conversation = Conversation(
            project_id=project_id,
            sender_id=sender.id,
            number_user_messages=0,
            latest_input_channel=event.input_channel or sender.channel,
            latest_event_time=event.timestamp,
        )
        self.session.add(conversation)
        self.session.flush()
        return conversation

    def _get_or_create_session(self, sender: RasaSender, conversation: Conversation,
                               event: RabbitEventMsgSchema, project_id: int) -> RasaSession:
        """Obtém ou cria sessão"""
        if event.event == 'session_started':
            # Nova sessão
            return self._create_new_session(sender, conversation, event, project_id)

        # Tentar obter sessão existente
        latest_session = self.session.execute(
            select(RasaSession)
            .where(RasaSession.sender_id == sender.id)
            .order_by(RasaSession.timestamp.desc())
        ).scalars().first()

        if latest_session:
            latest_session.end_sequence_number += 1
            return latest_session

        # Criar nova sessão se não existir
        return self._create_new_session(sender, conversation, event, project_id)

    def _create_new_session(self, sender: RasaSender, conversation: Conversation,
                            event: RabbitEventMsgSchema, project_id: int) -> RasaSession:
        """Cria nova sessão"""
        max_seq = self.session.execute(
            select(func.max(RasaSession.end_sequence_number))
            .where(RasaSession.sender_id == sender.id)
        ).scalar() or 0

        new_session = RasaSession(
            project_id=project_id,
            sender_id=sender.id,
            conversation_id=conversation.id,
            timestamp=event.timestamp,
            start_sequence_number=max_seq + 1,
            end_sequence_number=max_seq + 1
        )
        self.session.add(new_session)
        self.session.flush()
        return new_session

    def _get_or_create_turn(self, session: RasaSession, conversation: Conversation,
                            event: RabbitEventMsgSchema, project_id: int) -> RasaTurn:
        """Obtém ou cria turno"""
        if event.event == 'user':
            # Novo turno para mensagem do utilizador
            new_turn = RasaTurn(
                project_id=project_id,
                sender_id=session.sender_id,
                session_id=session.id,
                conversation_id=conversation.id,
                start_sequence_number=session.end_sequence_number,
                end_sequence_number=session.end_sequence_number
            )
            self.session.add(new_turn)
            self.session.flush()
            return new_turn

        # Obter turno existente
        latest_turn = self.session.execute(
            select(RasaTurn)
            .where(RasaTurn.session_id == session.id)
            .order_by(RasaTurn.start_sequence_number.desc())
        ).scalars().first()

        if latest_turn:
            latest_turn.end_sequence_number = session.end_sequence_number
            return latest_turn

        # Criar novo turno se não existir
        new_turn = RasaTurn(
            project_id=project_id,
            sender_id=session.sender_id,
            session_id=session.id,
            conversation_id=conversation.id,
            start_sequence_number=session.end_sequence_number,
            end_sequence_number=session.end_sequence_number
        )
        self.session.add(new_turn)
        self.session.flush()
        return new_turn

    def _insert_event(self, event: RabbitEventMsgSchema, session: RasaSession,
                      conversation: Conversation, project_id: int) -> RasaEvent:
        """Insere evento na base de dados"""
        new_event = RasaEvent(
            project_id=project_id,
            sender_id=session.sender_id,
            session_id=session.id,
            conversation_id=conversation.id,
            timestamp=event.timestamp,
            event_type=event.event,
            model_id=event.metadata.get('model_id') if event.metadata else None,
            environment=event.metadata.get('assistant_id') if event.metadata else None,
            sequence_number=session.end_sequence_number
        )
        self.session.add(new_event)
        self.session.flush()
        return new_event

    def _update_conversation_metrics(self, conversation: Conversation, event: RabbitEventMsgSchema):
        """Atualiza métricas da conversa"""
        # Incrementar contador de mensagens do utilizador
        if event.event == 'user':
            conversation.number_user_messages += 1
            conversation.review_status = 'unread'

        # Atualizar métricas de confiança para ações
        if event.event == 'action' and event.confidence is not None:
            if conversation.minimum_action_confidence is None or event.confidence < conversation.minimum_action_confidence:
                conversation.minimum_action_confidence = event.confidence
            if conversation.maximum_action_confidence is None or event.confidence > conversation.maximum_action_confidence:
                conversation.maximum_action_confidence = event.confidence

        # Atualizar métricas de confiança para intenções
        if event.parse_data and event.parse_data.intent.confidence is not None:
            intent_confidence = event.parse_data.intent.confidence
            if conversation.minimum_intent_confidence is None or intent_confidence < conversation.minimum_intent_confidence:
                conversation.minimum_intent_confidence = intent_confidence
            if conversation.maximum_intent_confidence is None or intent_confidence > conversation.maximum_intent_confidence:
                conversation.maximum_intent_confidence = intent_confidence

    def _process_specific_event(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                                conversation_id: int, project_id: int):
        """Processa evento específico baseado no tipo"""
        event_handlers = {
            'user': self._insert_user_message,
            'bot': self._insert_bot_message,
            'action': self._insert_action,
            'slot': self._insert_slot
        }

        handler = event_handlers.get(event.event)
        if handler:
            handler(event, rasa_event, conversation_id, project_id)

    def _insert_user_message(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                             conversation_id: int, project_id: int):
        """Insere mensagem do utilizador"""
        # Processar ranking de intenções
        intent_ranking = []
        if event.parse_data and event.parse_data.intent_ranking:
            intent_ranking = [intent.model_dump() for intent in event.parse_data.intent_ranking]

        # Inserir mensagem
        user_message = RasaUserMessage(
            event_id=rasa_event.id,
            project_id=project_id,
            sender_id=rasa_event.sender_id,
            session_id=rasa_event.session_id,
            conversation_id=conversation_id,
            intent=event.parse_data.intent.name if event.parse_data else None,
            intent_ranking=str(intent_ranking) if intent_ranking else None,
            confidence=event.parse_data.intent.confidence if event.parse_data else None,
            text=event.text or "",
            timestamp=event.timestamp,
            model_id=rasa_event.model_id,
            sequence_number=rasa_event.sequence_number,
            message_id=event.message_id,
        )
        self.session.add(user_message)

        # Adicionar ao NLU Inbox
        self._add_to_nlu_inbox(event, conversation_id, project_id, intent_ranking)

    def _add_to_nlu_inbox(self, event: RabbitEventMsgSchema, conversation_id: int,
                          project_id: int, intent_ranking: List):
        """Adiciona item ao NLU Inbox"""
        if not event.text:
            return

        # Verificar se já existe texto anotado
        existing_annotation = self.session.execute(
            select(NLUInboxItem).where(
                NLUInboxItem.text == event.text,
                NLUInboxItem.annotated_intent.isnot(None)
            )
        ).scalars().first()

        nlu_inbox_item = NLUInboxItem(
            project_id=project_id,
            conversation_id=conversation_id,
            message_id=event.message_id or "",
            text=event.text,
            annotated_intent=existing_annotation.annotated_intent if existing_annotation else None,
            predicted_intent=event.parse_data.intent.name if event.parse_data else None,
            intent_ranking=str(intent_ranking),
            confidence=event.parse_data.intent.confidence if event.parse_data else None,
            is_correct=bool(existing_annotation and
                            existing_annotation.annotated_intent == event.parse_data.intent.name)
        )
        self.session.add(nlu_inbox_item)

    def _insert_bot_message(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                            conversation_id: int, project_id: int):
        """Insere mensagem do bot"""
        bot_message = RasaBotMessage(
            event_id=rasa_event.id,
            project_id=project_id,
            sender_id=rasa_event.sender_id,
            session_id=rasa_event.session_id,
            conversation_id=conversation_id,
            timestamp=event.timestamp,
            template_name=event.metadata.get('utter_action') if event.metadata else None,
            text=event.text or "",
            model_id=rasa_event.model_id,
            sequence_number=rasa_event.sequence_number
        )
        self.session.add(bot_message)

    def _insert_action(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                       conversation_id: int, project_id: int):
        """Insere ação"""
        action = RasaAction(
            event_id=rasa_event.id,
            project_id=project_id,
            sender_id=rasa_event.sender_id,
            session_id=rasa_event.session_id,
            conversation_id=conversation_id,
            name=event.name or "",
            confidence=event.confidence,
            policy=event.policy,
            timestamp=event.timestamp,
            model_id=rasa_event.model_id,
            sequence_number=rasa_event.sequence_number
        )
        self.session.add(action)

    def _insert_slot(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                     conversation_id: int, project_id: int):
        """Insere slot e atualiza estado"""
        # Inserir evento de slot
        slot = RasaSlot(
            event_id=rasa_event.id,
            project_id=project_id,
            sender_id=rasa_event.sender_id,
            session_id=rasa_event.session_id,
            conversation_id=conversation_id,
            name=event.name or "",
            value=str(event.value) if event.value is not None else None,
            timestamp=event.timestamp,
            sequence_number=rasa_event.sequence_number,
            slot_path=f"{rasa_event.sender_id}/{rasa_event.session_id}/{event.name}"
        )
        self.session.add(slot)

        # Atualizar estado do slot
        self._update_slot_state(event, rasa_event, conversation_id, project_id)

    def _update_slot_state(self, event: RabbitEventMsgSchema, rasa_event: RasaEvent,
                           conversation_id: int, project_id: int):
        """Atualiza estado do slot na sessão"""
        slot_state = self.session.execute(
            select(RasaSessionSlotState).where(
                RasaSessionSlotState.project_id == project_id,
                RasaSessionSlotState.sender_id == rasa_event.sender_id,
                RasaSessionSlotState.session_id == rasa_event.session_id,
                RasaSessionSlotState.conversation_id == conversation_id,
                RasaSessionSlotState.name == event.name
            )
        ).scalars().first()

        if slot_state:
            slot_state.value = str(event.value) if event.value is not None else None
            slot_state.timestamp = event.timestamp
        else:
            new_slot_state = RasaSessionSlotState(
                project_id=project_id,
                sender_id=rasa_event.sender_id,
                session_id=rasa_event.session_id,
                conversation_id=conversation_id,
                name=event.name or "",
                value=str(event.value) if event.value is not None else None,
                timestamp=event.timestamp
            )
            self.session.add(new_slot_state)


# Funções auxiliares
def get_all_projects() -> List[Project]:
    """Obtém todos os projetos da base de dados"""
    from database.connection import db_connection

    with db_connection.session_scope() as session:
        return session.query(Project).all()


def handle_rasa_event(event: RabbitEventMsgSchema, session: Session, project_name: str):
    """Processa um evento Rasa"""

    processor = RasaEventProcessor(session)
    processor.process_event(event, project_name)