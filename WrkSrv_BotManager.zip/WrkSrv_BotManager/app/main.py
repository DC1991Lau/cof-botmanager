import asyncio
import logging

from faststream.asgi import AsgiFastStream, make_ping_asgi
from faststream.rabbit import RabbitBroker

from config import settings
from database.connection import db_connection
from services.rest import new_project_request
from services.subscribers_manager import SubscribersManager

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Criar broker
broker = RabbitBroker(settings.rabbitmq_url)

# Criar gestor de subscritores
subscribers_manager = SubscribersManager(broker, db_connection)

# Criar aplicação FastStream
app = AsgiFastStream(broker)

# Cria rotas REST

app.mount("/health", make_ping_asgi(broker, timeout=5.0))
app.mount("/new-project", new_project_request(subscribers_manager))

@app.on_startup
async def on_startup():
    """Executado quando o worker inicia"""
    logger.info("Worker FastStream iniciado")
    logger.info(f"Ligado ao RabbitMQ em {settings.rabbitmq_host}:{settings.rabbitmq_port}")

    # Criar tabelas se não existirem
    db_connection.create_tables()

    # Inicializar subscritores existentes
    await subscribers_manager.initialize_existing_projects()
    logger.info("Gestor de subscritores inicializado")


@app.on_shutdown
async def on_shutdown():
    """Executado quando o worker para"""
    logger.info("Worker FastStream a encerrar")
    db_connection.close()


if __name__ == "__main__":
    asyncio.run(app.run(run_extra_options={"port": "8001"}))