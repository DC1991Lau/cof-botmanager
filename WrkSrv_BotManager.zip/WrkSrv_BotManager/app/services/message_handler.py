import logging
from typing import Dict, Any

from sqlalchemy.orm import Session

from database.crud import handle_rasa_event
from schemas import RabbitEventMsgSchema

logger = logging.getLogger(__name__)


async def handle_message(
        msg: RabbitEventMsgSchema,
        queue_name: str,
        project_id: int,
        session: Session
) -> Dict[str, Any]:
    """
    Processa mensagem recebida do RabbitMQ

    Args:
        msg: Mensagem do evento Rasa
        queue_name: Nome da fila
        project_id: ID do projeto
        session: Sessão da base de dados

    Returns:
        Dict com status do processamento
    """
    try:
        logger.info(f"A processar mensagem do projeto {project_id} (fila: {queue_name})")

        # Processar evento usando a função CRUD
        handle_rasa_event(msg, session, project_id)

        logger.debug(f"Mensagem processada com sucesso: {msg.event} de {msg.sender_id}")

        return {
            "status": "success",
            "project_id": project_id,
            "queue": queue_name,
            "event_type": msg.event,
            "sender_id": msg.sender_id
        }

    except Exception as e:
        logger.error(f"Erro ao processar mensagem: {e}", exc_info=True)

        return {
            "status": "error",
            "project_id": project_id,
            "queue": queue_name,
            "error": str(e)
        }