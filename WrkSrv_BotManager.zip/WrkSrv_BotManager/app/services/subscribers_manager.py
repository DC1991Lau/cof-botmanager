import asyncio
import logging
from typing import Set
from faststream.rabbit import RabbitBroker, RabbitQueue

from database.connection import DBConnection
from database.models import Project
from database.crud import get_all_projects, handle_rasa_event
from schemas import RabbitEventMsgSchema

logger = logging.getLogger(__name__)


class SubscribersManager:
    """
    Gestor de subscritores dinâmicos para filas RabbitMQ baseado em projetos
    """

    def __init__(self, broker: RabbitBroker, db_connection: DBConnection):
        """
        Inicializa o gestor de subscritores

        Args:
            broker: Instância do RabbitBroker do FastStream
            db_connection: Conexão à base de dados
        """
        self.broker = broker
        self.db_connection = db_connection
        self.active_subscribers: Set[str] = set()
        logger.info("Gestor de subscritores inicializado")

    async def initialize_existing_projects(self):
        """
        Inicializa subscritores para todos os projetos ativos existentes
        """
        try:
            projects = get_all_projects()
            active_count = 0

            for project in projects:
                if project.active and project.queue_name:
                    await self._create_subscriber_for_project(project)
                    active_count += 1

            logger.info(f"Inicializados {active_count} subscritores para projetos existentes")

        except Exception as e:
            logger.error(f"Erro ao inicializar projetos existentes: {e}")
            raise

    async def _create_subscriber_for_project(self, project: Project):
        """
        Cria um subscritor para um projeto específico

        Args:
            project: Projeto para criar subscritor
        """
        if not project.queue_name:
            logger.warning(f"Projeto '{project.name}' sem nome de fila definido")
            return

        if project.queue_name in self.active_subscribers:
            logger.info(f"Subscritor já existe para fila '{project.queue_name}'")
            return

        try:
            # Criar função handler específica para este projeto
            async def project_message_handler(message: RabbitEventMsgSchema):
                """Handler de mensagens para o projeto"""
                logger.info(f"Mensagem recebida na fila '{project.queue_name}' do projeto '{project.name}'")

                # Processar mensagem usando sessão da base de dados
                with self.db_connection.session_scope() as session:
                    handle_rasa_event(message, session, project.name)

                return {"status": "processed", "project": project.name}

            # Configurar fila durável com tipo quorum para alta disponibilidade
            queue = RabbitQueue(
                name=project.queue_name,
                durable=True,
                arguments={"x-queue-type": "quorum"}
            )

            # Registar subscritor no broker
            subscriber = self.broker.subscriber(queue)
            subscriber(project_message_handler)

            # Adicionar à lista de subscritores ativos
            self.active_subscribers.add(project.queue_name)

            logger.info(f"Subscritor criado para projeto '{project.name}' na fila '{project.queue_name}'")

        except Exception as e:
            logger.error(f"Erro ao criar subscritor para projeto '{project.name}': {e}")
            raise

    async def refresh_subscribers(self):
        """
        Atualiza todos os subscritores baseado no estado atual da base de dados
        Pode ser chamado periodicamente ou quando necessário
        """
        logger.info("AQUI")
        try:
            current_projects = get_all_projects()
            current_active_queues = {
                p.queue_name for p in current_projects
                if p.active and p.queue_name
            }

            # Identificar filas para remover
            to_remove = self.active_subscribers - current_active_queues
            if to_remove:
                logger.warning(f"Filas para remover: {to_remove}")
                # Nota: FastStream não suporta remoção dinâmica de subscritores
                # Seria necessário reiniciar o worker para remover subscritores
                for queue_name in to_remove:
                    self.active_subscribers.remove(queue_name)

            # Adicionar novos subscritores
            added_count = 0
            for project in current_projects:
                if (project.active and project.queue_name and
                        project.queue_name not in self.active_subscribers):
                    await self._create_subscriber_for_project(project)
                    added_count += 1

            await self.broker.start()

            logger.info(f"Subscritores atualizados. Ativos: {len(self.active_subscribers)}, Novos: {added_count}")

        except Exception as e:
            logger.error(f"Erro ao atualizar subscritores: {e}")

    def get_active_subscribers(self) -> Set[str]:
        """
        Obtém lista de nomes de filas com subscritores ativos

        Returns:
            Set[str]: Conjunto de nomes de filas ativas
        """
        return self.active_subscribers.copy()