import logging

from faststream.asgi import get, AsgiResponse
from faststream.asgi.types import Scope, ASGIApp

from services.subscribers_manager import SubscribersManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def new_project_request(
    subscriber_manager: SubscribersManager,
) -> "ASGIApp":
    healthy_response = AsgiResponse(b"", 200)
    unhealthy_response = AsgiResponse(b"", 500)

    @get
    async def restart_subscribers(scope: "Scope") -> AsgiResponse:
        try:
            await subscriber_manager.refresh_subscribers()
            return healthy_response
        except Exception as e:
            logger.error(e)
            return unhealthy_response

    return restart_subscribers