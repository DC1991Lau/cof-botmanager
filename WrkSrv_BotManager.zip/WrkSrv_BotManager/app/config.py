import os

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Configurações da aplicação"""

    # RabbitMQ
    # Rabbit settings
    rabbitmq_host: str = os.getenv("RABBITMQ_HOST", "devdocker.cofidis.pt")
    rabbitmq_port: int = int(os.getenv("RABBITMQ_PORT", "5672"))
    rabbitmq_user: str = os.getenv("RABBITMQ_USER", "dev")
    rabbitmq_password: str = os.getenv("RABBITMQ_PASSWORD", "R@bdevbit")
    rabbitmq_vhost: str = os.getenv("RABBITMQ_VHOST", "BotFactories")

    # DB Settings
    db_driver: str = os.getenv('DB_DRIVER') or 'ODBC Driver 17 for SQL Server'
    db_server: str = os.getenv('DB_SERVER') or 'PF26P05S'
    db_database: str = os.getenv('DB_DATABASE') or 'ServiceGate'
    db_username: str | None = os.getenv('DB_USERNAME') or None
    db_password: str | None = os.getenv('DB_PASSWORD') or None

    @property
    def rabbitmq_url(self) -> str:
        """Constrói URL de conexão do RabbitMQ"""
        return f"amqp://{self.rabbitmq_user}:{self.rabbitmq_password}@{self.rabbitmq_host}:{self.rabbitmq_port}/{self.rabbitmq_vhost}"

    # Logging
    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Instância global das configurações
settings = Settings()