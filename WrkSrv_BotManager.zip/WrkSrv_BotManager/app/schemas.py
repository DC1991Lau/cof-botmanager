from pydantic import BaseModel, Field, field_validator
from typing import Optional, Dict, Any, List, Union
from datetime import datetime


class BaseORMModel(BaseModel):
    """Modelo base com configuração ORM"""

    class Config:
        from_attributes = True


class Intent(BaseModel):
    """Intenção detectada pelo Rasa"""
    name: str
    confidence: float


class Entity(BaseModel):
    """Entidade detectada pelo Rasa"""
    name: str
    value: Any
    confidence: Optional[float] = None


class Button(BaseModel):
    """Botão de resposta rápida"""
    payload: str
    title: str

    @field_validator('payload', mode='before')
    @classmethod
    def convert_payload_to_string(cls, v):
        """Converte payload para string se necessário"""
        return str(v) if v is not None else ''


class UserParseData(BaseModel):
    """Dados de parsing da mensagem do utilizador"""
    intent: Intent
    entities: List[Entity] = []
    text: str
    message_id: str
    metadata: Dict = {}
    intent_ranking: List[Intent] = []


class BotParseData(BaseModel):
    """Dados de resposta do bot"""
    text: Optional[str] = None
    buttons: Optional[List[Button]] = None
    image: Optional[str] = None
    custom: Optional[Dict[str, Any]] = None


class RabbitEventMsgSchema(BaseModel):
    """Schema principal para eventos do RabbitMQ"""
    sender_id: str
    event: str
    timestamp: datetime
    text: Optional[str] = None
    metadata: Optional[Dict] = None
    parse_data: Optional[UserParseData] = None
    input_channel: Optional[str] = None
    message_id: Optional[str] = None
    data: Optional[BotParseData] = None

    # Campos para eventos específicos
    name: Optional[str] = None  # Para slots e actions
    value: Optional[Any] = None  # Para slots
    policy: Optional[str] = None  # Para actions
    confidence: Optional[float] = None  # Para actions


# Schemas de Base de Dados
class ProjectBase(BaseModel):
    """Base para projetos"""
    name: str
    description: Optional[str] = None
    url_connection: str
    port: int
    queue_name: str
    active: bool = True


class ProjectCreate(ProjectBase):
    """Schema para criar projeto"""
    pass


class Project(ProjectBase, BaseORMModel):
    """Schema completo do projeto"""
    id: int


class ConversationBase(BaseModel):
    """Base para conversas"""
    project_id: int
    sender_id: int
    number_user_messages: int = 0
    latest_input_channel: Optional[str] = None
    latest_event_time: Optional[datetime] = None
    review_status: str = "unread"

    # Métricas de confiança
    minimum_action_confidence: Optional[float] = None
    maximum_action_confidence: Optional[float] = None
    minimum_intent_confidence: Optional[float] = None
    maximum_intent_confidence: Optional[float] = None


class Conversation(ConversationBase, BaseORMModel):
    """Schema completo da conversa"""
    id: int


class RasaSenderBase(BaseModel):
    """Base para remetentes"""
    project_id: int
    sender_key: str
    channel: Optional[str] = None
    first_seen: datetime
    last_seen: datetime


class RasaSender(RasaSenderBase, BaseORMModel):
    """Schema completo do remetente"""
    id: int


class RasaSessionBase(BaseModel):
    """Base para sessões"""
    sender_id: int
    conversation_id: int
    timestamp: datetime
    start_sequence_number: int
    end_sequence_number: int


class RasaSession(RasaSessionBase, BaseORMModel):
    """Schema completo da sessão"""
    id: int
    project_id: int


class RasaEventBase(BaseModel):
    """Base para eventos"""
    sender_id: int
    session_id: int
    conversation_id: int
    timestamp: datetime
    event_type: str
    model_id: Optional[str] = None
    environment: Optional[str] = None
    sequence_number: int


class RasaEvent(RasaEventBase, BaseORMModel):
    """Schema completo do evento"""
    id: int
    project_id: int


class NLUInboxItemBase(BaseModel):
    """Base para items da inbox NLU"""
    project_id: int
    conversation_id: int
    message_id: str
    text: str
    predicted_intent: Optional[str] = None
    intent_ranking: str
    confidence: Optional[float] = None
    is_correct: bool = False
    annotated_intent: Optional[str] = None


class NLUInboxItem(NLUInboxItemBase, BaseORMModel):
    """Schema completo do item inbox NLU"""
    id: int
    timestamp: datetime
    annotated_at: Optional[datetime] = None