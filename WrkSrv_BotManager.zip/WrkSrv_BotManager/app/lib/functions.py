import json
from typing import Union, Dict, List


def transform_payload_to_string(payload: Union[str, Dict, List]) -> str:
    """
    Transform a payload into a string representation.

    Args:
        payload: Input payload that could be a string, dictionary, or list

    Returns:
        str: String representation of the payload

    Raises:
        TypeError: If payload type is not supported
    """
    if isinstance(payload, str):
        return payload

    if isinstance(payload, (dict, list)):
        try:
            return json.dumps(payload)
        except (TypeError, ValueError) as e:
            raise TypeError(f"Could not convert payload to string: {str(e)}")

    raise TypeError(f"Unsupported payload type: {type(payload)}")