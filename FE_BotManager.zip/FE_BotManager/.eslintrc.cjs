module.exports = {
  extends: ['@cofidis/eslint-config'],
  parserOptions: {
    project: ['tsconfig.src.json'],
    tsconfigRootDir: __dirname,
  },
  rules: {
    'react/prop-types': 'off',
    'max-len': 'off',
    'sonarjs/no-duplicate-string': 'off',
    'react/no-unknown-property': 'off',
    'react/jsx-no-constructed-context-values': 'off',
    'sonarjs/no-collapsible-if': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    'no-prototype-builtins': 'off',
    'react-refresh/only-export-components': 'off',
  },
  overrides: [
    {
      extends: ['@cofidis/eslint-config/test'],
      files: ['**/**/*.test.{ts,tsx}'],
      parserOptions: {
        project: ['tsconfig.test.json'],
        tsconfigRootDir: __dirname,
      },
    },
    {
      files: ['testing/**/**/*.{ts,tsx}', 'vite.config.ts', 'vitest.config.ts'],
      parserOptions: {
        project: ['tsconfig.node.json'],
        tsconfigRootDir: __dirname,
      },
    },
  ],
};
