#!/bin/sh

if [ "${AUTH_BASIC_CREDENTIALS}" != "" ]; then
#   sed -i "s/#auth_basic/auth_basic/g;" /etc/nginx/nginx.conf
  rm -rf /etc/nginx/.htpasswd
  echo $AUTH_BASIC_CREDENTIALS >> /etc/nginx/.htpasswd
  echo "Basic auth is on "
else
  echo "Basic auth is off (AUTH_BASIC_CREDENTIALS not provided)"
fi
