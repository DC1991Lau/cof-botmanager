import { defineConfig } from 'vite';
import { common } from './vite.common';

export default defineConfig({
  ...common,
  server: {
    ...common.preview,
  },
  build: {
    modulePreload: false,
    cssCodeSplit: false,
    // set reportCompressedSize: false to improve performance due large files/codebase
  },
});
