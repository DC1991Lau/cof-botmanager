import { defineConfig } from 'vitest/config';
import { test } from './testing/vitest.config.common';
import react from '@vitejs/plugin-react';
import checker from 'vite-plugin-checker';

export default defineConfig({
  plugins: [
    react(),
    //remove "checker" if you see performance issues. You will rely only on your editor configuration for static typing
    checker({
      typescript: { tsconfigPath: 'tsconfig.test.json' },
    }),
  ],
  test,
});
