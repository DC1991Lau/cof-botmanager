import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ProjectForm } from '@/components/forms/project-form';

import { CirclePlus, Plus } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';

export default function NewProjectButton() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="self-end">
          <Plus />
          Novo Chatbot
        </Button>
      </DialogTrigger>
      <DialogContent className="w-max-fit p-0 h-[32rem]">
        <ScrollArea className="p-4">
          <DialogHeader className="mb-4">
            <DialogTitle>
              <div className="flex justify-between">
                <div className="text-xs flex gap-1 items-center uppercase text-foreground">
                  <div className="w-6 h-6 bg-sidebar-accent rounded flex items-center justify-center">
                    <CirclePlus className="h-4 w-4 text-sidebar-accent-foreground" />
                  </div>
                  Novo Chatbot
                </div>
              </div>
            </DialogTitle>
          </DialogHeader>

          <ProjectForm />
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
