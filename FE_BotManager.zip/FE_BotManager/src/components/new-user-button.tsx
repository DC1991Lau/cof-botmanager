import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';

import { Plus, User } from 'lucide-react';
import { UserForm } from './forms/user-form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function CreateUserButton() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="self-end">
          <Plus />
          Novo Utilizador
        </Button>
      </DialogTrigger>
      <DialogContent asChild>
        <Card className="w-full max-w-md mx-auto">
          <CardHeader className="p-4">
            <CardTitle>
              <div className="flex justify-between">
                <div className="text-xs flex gap-1 items-center uppercase text-foreground">
                  <div className="w-6 h-6 bg-sidebar-accent rounded flex items-center justify-center">
                    <User className="h-4 w-4 text-sidebar-accent-foreground" />
                  </div>
                  Novo Utilizador
                </div>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <UserForm />
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}
