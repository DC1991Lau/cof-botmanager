import { Bot } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SidebarMenuButton } from './ui/sidebar';

export default function AppLogo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-medium">
      <SidebarMenuButton size="lg" className="flex items-center gap-2 font-medium hover:bg-transparent hover:text-foreground">
        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Bot className="size-4" />
        </div>
        <div className="grid flex-1 text-left text-sm leading-tight">
          <span className="truncate font-semibold">botManager</span>
        </div>
      </SidebarMenuButton>
    </Link>
  );
}
