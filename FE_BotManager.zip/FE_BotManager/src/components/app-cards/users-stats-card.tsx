import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { GeneralStats } from '@/services/api/requests';
import { MessagesSquare, Plus } from 'lucide-react';

export default function UsersStatsCard({ data }: { data: GeneralStats | undefined }) {
  let percentageDifference = 0;

  if (data) {
    percentageDifference = (data.active_users / data.total_users) * 100;
  }
  return (
    <Card className="gap-4 flex flex-col">
      <CardHeader>
        <CardTitle>
          <div className="w-6 h-6 bg-sidebar-accent rounded flex items-center justify-center">
            <MessagesSquare className="h-4 w-4 text-sidebar-accent-foreground" />
          </div>
          Utilizadores
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col justify-between">
        <span className="text-6xl">{data?.total_users}</span>
        <div className="flex gap-1 items-baseline">
          <div className="flex items-baseline gap-1">
            <Plus className="size-3 text-green-400 border-[1.5px] border-green-400 rounded-sm" />
            <span className="text-green-400 font-bold ">{`${percentageDifference.toFixed(1)}%`}</span>
          </div>
          <span className="text-sx text-muted-foreground text-xs">nos últimos 7 dias</span>
        </div>
      </CardContent>
    </Card>
  );
}
