import { ChartDataObjectProps, GroupByProps } from '@/types';
import { useChart } from '../hooks/use-chart';
import { ChartConfig } from '../ui/chart';
import { BarChartMultiple } from '../charts/_components/bar-chart-multiple';
import { Users } from 'lucide-react';
import Page from '../layout/page';

export const satesDistributionChartConfig = {
  total_users: {
    label: 'Utilizadores',
    color: 'hsl(var(--chart-1))',
  },
  new_users: {
    label: 'Novos Utilizadores',
    color: 'hsl(var(--chart-4))',
  },
} satisfies ChartConfig;

export default function UsersDistributionChartCard({ data, groupBy }: { data?: ChartDataObjectProps[]; groupBy: GroupByProps }) {
  // const combinedData = mergeArrays(chartSendersMockedData, chartSessionsMockedData);
  const chartData = useChart(data, groupBy);
  return (
    <Page title="Utilizadores" Icon={Users}>
      <BarChartMultiple data={chartData} config={satesDistributionChartConfig} />
    </Page>
  );
}
