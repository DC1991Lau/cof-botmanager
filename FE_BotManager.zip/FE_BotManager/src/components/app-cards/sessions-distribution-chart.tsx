import { ChartDataObjectProps, GroupByProps } from '@/types';
import { useChart } from '../hooks/use-chart';
import { ChartConfig } from '../ui/chart';
import { AreaChartComponent } from '../charts/_components/area-chart';
import { MessageCircle } from 'lucide-react';
import Page from '../layout/page';

export const satesDistributionChartConfig = {
  sessions: {
    label: 'Nº de Conversas',
    color: 'hsl(var(--chart-1))',
  },
} satisfies ChartConfig;

export default function SessionsDistributionChartCard({ data, groupBy }: { data?: ChartDataObjectProps[]; groupBy: GroupByProps }) {
  // const combinedData = mergeArrays(chartSendersMockedData, chartSessionsMockedData);
  const chartData = useChart(data, groupBy);
  return (
    <Page title="Conversas" Icon={MessageCircle}>
      <AreaChartComponent data={chartData} config={satesDistributionChartConfig} />
    </Page>
  );
}
