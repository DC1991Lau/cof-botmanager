'use client';

import * as React from 'react';
import { addDays, addMonths, format } from 'date-fns';
import { CalendarIcon } from 'lucide-react';
import type { DateRange } from 'react-day-picker';

import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function DatePickerWithRange({
  className,
  setDateRange,
}: {
  className?: string;
  setDateRange: React.Dispatch<React.SetStateAction<DateRange | undefined>>;
}) {
  const [popoverIsOpen, setPopoverIsOpen] = React.useState(false);
  const [selectValue, setSelectValue] = React.useState('7days');
  const [date, setDate] = React.useState<DateRange | undefined>({
    from: addDays(new Date(), -7),
    to: new Date(),
  });

  const handlePresetChange = (value: string) => {
    const today = new Date();

    switch (value) {
      case '7days':
        setDate({
          from: addDays(today, -7),
          to: today,
        });
        break;
      case '30days':
        setDate({
          from: addDays(today, -30),
          to: today,
        });
        break;
      case '6months':
        setDate({
          from: addMonths(today, -6),
          to: today,
        });
        break;
      case '12months':
        setDate({
          from: addMonths(today, -12),
          to: today,
        });
        break;
      default:
        if (!date) {
          setDate({
            from: addDays(today, -7),
            to: today,
          });
        }
    }
    setSelectValue(value);
  };

  const handleConfirm = () => {
    setPopoverIsOpen(false);
    setDateRange(date);
  };

  return (
    <div className={cn('flex gap-3 items-start', className)}>
      <Popover open={popoverIsOpen} onOpenChange={setPopoverIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={'outline'}
            size="sm"
            className={cn('w-full md:w-[250px] justify-start text-left font-normal', !date && 'text-muted-foreground')}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, 'LLL dd, y')} - {format(date.to, 'LLL dd, y')}
                </>
              ) : (
                format(date.from, 'LLL dd, y')
              )
            ) : (
              <span>Pick a date</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto" align="start" side="left">
          <div className="space-y-3">
            <Select onValueChange={handlePresetChange} defaultValue={selectValue}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Select preset range" />
              </SelectTrigger>
              <SelectContent position="popper">
                <SelectItem value="7days">7 dias</SelectItem>
                <SelectItem value="30days">30 dias</SelectItem>
                <SelectItem value="6months">6 meses</SelectItem>
                <SelectItem value="12months">12 meses</SelectItem>
              </SelectContent>
            </Select>

            <Calendar
              initialFocus
              mode="range"
              defaultMonth={date?.from}
              selected={date}
              onSelect={setDate}
              numberOfMonths={2}
              className="p-0"
            />

            <div className="flex justify-end px-2 pb-2">
              <Button onClick={handleConfirm} size="sm">
                Filtrar
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
