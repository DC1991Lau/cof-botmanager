import { Bar, BarChart, CartesianGrid, XAxis } from 'recharts';

import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { ChartProps } from '@/types';

export function BarChartMultiple({ data, config }: ChartProps) {
  const dataKeys = Object.keys(config);
  return (
    <ChartContainer config={config} className="h-[300px] w-full">
      <BarChart accessibilityLayer data={data}>
        <CartesianGrid vertical={false} />
        <XAxis dataKey="timestamp" tickLine={false} tickMargin={10} axisLine={false} tickFormatter={value => value} />
        <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dashed" />} />
        {dataKeys.map(key => (
          <Bar key={key} dataKey={key} fill={`var(--color-${key})`} radius={4} />
        ))}
        <ChartLegend content={<ChartLegendContent />} />
      </BarChart>
    </ChartContainer>
  );
}
