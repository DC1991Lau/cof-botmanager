'use client';

import { Bar, BarChart, CartesianGrid, XAxis } from 'recharts';

import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import type { ChartProps } from '@/types';

export function BarChartComponent({ data, config }: ChartProps) {
  const dataKeys = Object.keys(config);

  return (
    <ChartContainer config={config} className="h-[300px] w-full">
      <BarChart
        accessibilityLayer
        data={data}
        margin={{
          left: 12,
          right: 12,
        }}
      >
        <CartesianGrid vertical={false} />
        <XAxis dataKey="timestamp" tickLine={false} tickMargin={10} axisLine={false} tickFormatter={value => value} />
        <ChartTooltip content={<ChartTooltipContent />} />
        <ChartLegend content={<ChartLegendContent />} />
        {dataKeys.map((key, index) => (
          <Bar key={key} dataKey={key} stackId="a" fill={`var(--color-${key})`} radius={index === 0 ? [0, 0, 4, 4] : [4, 4, 0, 0]} />
        ))}
      </BarChart>
    </ChartContainer>
  );
}
