import { Area, AreaChart, CartesianGrid, XAxis } from 'recharts';

import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { ChartProps } from '@/types';

export function AreaChartComponent({ data, config, areaProps }: ChartProps) {
  const dataKeys = Object.keys(config);
  return (
    <ChartContainer config={config} className="h-[300px] w-full">
      <AreaChart
        accessibilityLayer
        data={data}
        margin={{
          right: 12,
        }}
      >
        <CartesianGrid vertical={false} />
        <XAxis dataKey="timestamp" tickLine={false} axisLine={false} tickMargin={8} tickFormatter={value => value} />
        <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dot" />} />
        {dataKeys.map(key => (
          <Area
            key={key}
            dataKey={key}
            type={areaProps?.type}
            fill={`var(--color-${key})`}
            fillOpacity={areaProps?.fillOpacity}
            stroke={`var(--color-${key})`}
            stackId="a"
            dot={true}
          />
        ))}
        <ChartLegend content={<ChartLegendContent />} />
      </AreaChart>
    </ChartContainer>
  );
}
