import { ChartConfig } from '../../ui/chart';

export const chartSessionsMockedData = [
  { timestamp: '2025-03-11', sessions: 78 },
  { timestamp: '2025-03-12', sessions: 83 },
  { timestamp: '2025-03-13', sessions: 91 },
  { timestamp: '2025-03-14', sessions: 75 },
  { timestamp: '2025-03-15', sessions: 48 },
  { timestamp: '2025-03-16', sessions: 42 },
  { timestamp: '2025-03-17', sessions: 73 },
];

export const chartSendersMockedData = [
  { timestamp: '2025-03-11', new_users: 3, total_users: 38 },
  { timestamp: '2025-03-12', new_users: 1, total_users: 39 },
  { timestamp: '2025-03-13', new_users: 6, total_users: 45 },
  { timestamp: '2025-03-14', new_users: 0, total_users: 45 },
  { timestamp: '2025-03-15', new_users: 2, total_users: 47 },
  { timestamp: '2025-03-16', new_users: 6, total_users: 53 },
  { timestamp: '2025-03-17', new_users: 1, total_users: 54 },
];

export const chartConfig = {
  views: {
    label: 'Page Views',
  },
  desktop: {
    label: 'Desktop',
    color: 'hsl(var(--chart-1))',
  },
  mobile: {
    label: 'Mobile',
    color: 'hsl(var(--chart-2))',
  },
} satisfies ChartConfig;
