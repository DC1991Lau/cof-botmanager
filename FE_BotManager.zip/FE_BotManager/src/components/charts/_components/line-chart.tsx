import { CartesianGrid, Line, LineChart, XAxis } from 'recharts';

import { ChartProps } from '@/types';
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '../../ui/chart';

export function LineChartComponent({ data, config, lineProps }: ChartProps) {
  const dataKeys = Object.keys(config);
  return (
    <ChartContainer config={config} className="h-[300px] w-full">
      <LineChart
        accessibilityLayer
        data={data}
        margin={{
          left: 12,
          right: 12,
        }}
      >
        <CartesianGrid vertical={false} />
        <XAxis dataKey="timestamp" tickLine={false} axisLine={false} tickMargin={8} tickFormatter={value => value} />
        <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
        {dataKeys.map(key => (
          <Line key={key} dataKey={key} type={lineProps?.type} stroke={`var(--color-${key})`} strokeWidth={2} dot={true} />
        ))}
        <ChartLegend content={<ChartLegendContent />} />
      </LineChart>
    </ChartContainer>
  );
}
