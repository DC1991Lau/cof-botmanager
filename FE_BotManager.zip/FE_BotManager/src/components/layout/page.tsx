import { LucideIcon } from 'lucide-react';
import { Card, CardHeader, CardTitle } from '../ui/card';
import { ReactNode } from 'react';

export default function Page({ title, Icon, children }: { title: string; Icon: LucideIcon; children: ReactNode }) {
  return (
    <Card className="p-4 flex flex-col gap-4">
      <CardHeader className="p-0 w-full flex flex-row justify-between items-start ">
        <CardTitle>
          <div className="text-xs flex gap-1 items-center uppercase text-foreground">
            <div className="w-6 h-6 bg-sidebar-accent rounded flex items-center justify-center">
              <Icon className="h-4 w-4 text-sidebar-accent-foreground" />
            </div>
            {title}
          </div>
        </CardTitle>
      </CardHeader>
      {children}
    </Card>
  );
}
