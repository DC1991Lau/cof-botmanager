import { Navigate, Outlet, useSearchParams } from 'react-router-dom';

import {
  useProjectsServiceReadProjectsProjectsGet,
  useProjectsServiceReadProjectsProjectsGetKey,
  useUsersServiceUsersCurrentUserUsersMeGet,
} from '@/services/api/queries';
import { useAppStore } from '@/hooks/use-app-store';
import { useEffect } from 'react';
import { SidebarInset, SidebarProvider, SidebarTrigger } from '../ui/sidebar';
import { AppSidebar } from '../sidebar/app-sidebar';
import { Separator } from '../ui/separator';
import AppBreadcrumb from '../app-breadcrumbs';
import ConversationDetail from '../conversation-detail/conversation-detail';

export default function AppLayout() {
  const { setProjects } = useAppStore();
  const [searchParams] = useSearchParams();
  const {
    data: user,
    isError,
    isLoading: userLoading,
  } = useUsersServiceUsersCurrentUserUsersMeGet(undefined, {
    staleTime: 10 * (60 * 1000),
    retry: false,
  });

  const {
    data: projects,
    isLoading: projectsLoading,
    isRefetchError,
  } = useProjectsServiceReadProjectsProjectsGet(undefined, [useProjectsServiceReadProjectsProjectsGetKey], {
    staleTime: 10 * (60 * 1000),
    retry: false,
  });

  useEffect(() => {
    if (projects) {
      setProjects(projects);
    }
  }, [projects, setProjects]);

  if (userLoading || projectsLoading) {
    return <div>Loading...</div>;
  }

  if (!user || isError || isRefetchError) {
    return <Navigate to="/sign-in" />;
  }
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="h-screen overflow-x-hidden pb-4">
        <header className="flex h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-[[data-collapsible=icon]]/sidebar-wrapper:h-12">
          <div className="flex items-center gap-2">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <AppBreadcrumb />
          </div>
        </header>
        <Outlet />
      </SidebarInset>
      {searchParams.get('conversationId') && <ConversationDetail />}
    </SidebarProvider>
  );
}
