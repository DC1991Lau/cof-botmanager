import { NavLink, useLocation } from 'react-router-dom';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from './ui/breadcrumb';
import { Home } from 'lucide-react';
import { useAppStore } from '@/hooks/use-app-store';
import { cn } from '@/lib/utils';

export default function AppBreadcrumb() {
  const { activeProject } = useAppStore();
  const location = useLocation();
  const locationDividev = location.pathname.split('/');

  return (
    <Breadcrumb>
      <BreadcrumbList>
        <BreadcrumbItem className="hidden md:block">
          <BreadcrumbLink asChild>
            <NavLink to="/">
              <Home className="h-4 w-4" />
            </NavLink>
          </BreadcrumbLink>
        </BreadcrumbItem>
        {location.pathname !== '/' && <BreadcrumbSeparator className={cn('hidden md:block')} />}
        <BreadcrumbItem className="hidden md:block">
          <BreadcrumbLink asChild>
            <NavLink to={`/${activeProject?.queue_name}/overview`}>{locationDividev[1]}</NavLink>
          </BreadcrumbLink>
        </BreadcrumbItem>
        {locationDividev.length > 2 && <BreadcrumbSeparator className="hidden md:block" />}
        <BreadcrumbItem>
          <BreadcrumbPage className="capitalize">{locationDividev[2]}</BreadcrumbPage>
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
}
