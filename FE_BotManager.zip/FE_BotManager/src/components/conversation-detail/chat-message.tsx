import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface ChatMessageProps {
  message: {
    id: string | number;
    text: string;
    sender: string;
    timestamp: string;
  };
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const isBot = message.sender === 'bot';
  const timestamp = new Date(message.timestamp);

  return (
    <div className={cn('flex', isBot ? 'justify-start' : 'justify-end')}>
      <div className={cn('flex flex-col max-w-[80%]', isBot ? 'items-start' : 'items-end')}>
        <div
          className={cn(
            'px-4 py-2.5 rounded-2xl',
            isBot ? 'bg-muted text-foreground rounded-tl-none' : 'bg-primary text-primary-foreground rounded-tr-none',
          )}
        >
          <p className="text-xs whitespace-pre-wrap break-words">{message.text}</p>
        </div>
        <span className="text-[10px] text-muted-foreground mt-1 px-1">{format(timestamp, 'HH:mm')}</span>
      </div>
    </div>
  );
}
