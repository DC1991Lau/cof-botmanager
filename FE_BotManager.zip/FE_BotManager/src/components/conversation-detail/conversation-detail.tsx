import { useConversationsServiceReadConversationDetailConversationsConversationIdDetailGet } from '@/services/api/queries';
import { useSearchParams } from 'react-router-dom';
import { ArrowLeft, X, MessageSquare } from 'lucide-react';

import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import ChatMessage from './chat-message';

export default function ConversationDetail() {
  const [searchParams, setSearchParams] = useSearchParams();
  const conversationId = Number(searchParams.get('conversationId'));

  const { data: conversation, isLoading } = useConversationsServiceReadConversationDetailConversationsConversationIdDetailGet(
    {
      conversationId,
    },
    undefined,
    {
      staleTime: 1000 * 60,
      retry: false,
    },
  );

  const handleRemoveConversationId = () => {
    const newParams = new URLSearchParams(searchParams.toString());
    newParams.delete('conversationId');
    setSearchParams(newParams);
  };

  // Group messages by date
  const groupedMessages =
    conversation?.messages.reduce(
      (groups, message) => {
        const date = new Date(message.timestamp).toLocaleDateString();
        if (!groups[date]) {
          groups[date] = [];
        }

        groups[date]!.push(message);
        return groups;
      },
      {} as Record<string, typeof conversation.messages>,
    ) || {};

  if (isLoading) {
    return (
      <div className="h-full w-full md:w-2/3 lg:w-1/3 flex flex-col border-l">
        <div className="p-4 bg-background border-b flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-[150px]" />
              <Skeleton className="h-3 w-[100px]" />
            </div>
          </div>
          <Skeleton className="h-8 w-8 rounded-md" />
        </div>
        <div className="flex-1 p-6 flex flex-col gap-4">
          <Skeleton className="h-16 w-2/3 rounded-lg ml-auto" />
          <Skeleton className="h-16 w-3/4 rounded-lg" />
          <Skeleton className="h-16 w-2/3 rounded-lg ml-auto" />
          <Skeleton className="h-16 w-1/2 rounded-lg" />
        </div>
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="w-full md:w-2/3 lg:w-1/3 flex h-full flex-col justify-center items-center border-l bg-muted/10 text-center p-8">
        <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">Nenhuma conversa selecionada</h3>
        <p className="text-muted-foreground text-sm max-w-xs">
          Selecione uma conversa da lista para visualizar os detalhes e o histórico de mensagens.
        </p>
      </div>
    );
  }

  return (
    <div className={cn('h-screen flex flex-col w-full md:w-2/3 lg:w-1/3 border-l right-0 top-0 bg-background')}>
      <div className="p-3 bg-background border-b flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={handleRemoveConversationId}>
            <ArrowLeft className="h-5 w-5" />
          </Button>

          <div className="flex flex-col font-semibold">
            <h2>{conversation.sender_key}</h2>
          </div>
        </div>

        <Button variant="ghost" size="icon" onClick={handleRemoveConversationId}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4 bg-white">
        <div className="flex flex-col gap-6 pb-6">
          {Object.entries(groupedMessages).map(([date, messages]) => (
            <div key={date} className="space-y-4">
              <div className="relative flex items-center justify-center">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <Badge variant="outline" className="relative bg-background px-2 text-xs text-muted-foreground">
                  {new Date(date).toLocaleDateString('pt-BR', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </Badge>
              </div>

              {messages.map(message => {
                return <ChatMessage message={message} key={`${message.id} - ${message.sender}`} />;
              })}
            </div>
          ))}
        </div>
      </ScrollArea>
      <div className="p-3 bg-background border-t flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={handleRemoveConversationId}>
            <ArrowLeft className="h-5 w-5" />
          </Button>

          <div className="flex flex-col font-semibold">
            <h2>{conversation.sender_key}</h2>
          </div>
        </div>
      </div>
    </div>
  );
}
