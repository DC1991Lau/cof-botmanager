'use client';

import { useMemo } from 'react';
import type { ComponentType, ReactNode } from 'react';
import { format, parseISO, isValid } from 'date-fns';

import { pt } from 'date-fns/locale';

export type ChartDataObjectProps = {
  timestamp: string | Date;
  [key: string]: string | Date | number | unknown;
};

export type ChartConfig = {
  [k in string]: {
    label?: ReactNode;
    icon?: ComponentType;
  } & ({ color?: string; theme?: never } | { color?: never; theme: Record<string, string> });
};

type DateRange = 'day' | 'month' | 'year';

// Format timestamp based on date range
const formatTimestamp = (timestamp: Date, range: DateRange): string => {
  if (range === 'day') {
    return format(timestamp, 'dd MMM yy', { locale: pt });
  }

  if (range === 'month') {
    return format(timestamp, 'MMM yyyy', { locale: pt });
  }

  if (range === 'year') {
    return format(timestamp, 'yyyy', { locale: pt });
  }

  // Default to day format
  return format(timestamp, 'dd MM yyyy', { locale: pt });
};

// Parse timestamp safely
const parseTimestamp = (timestamp: string | Date): Date | null => {
  if (timestamp instanceof Date) {
    return isValid(timestamp) ? timestamp : null;
  }

  try {
    const parsedDate = parseISO(timestamp);
    return isValid(parsedDate) ? parsedDate : null;
  } catch {
    return null;
  }
};

// Extract unique keys from data
const extractUniqueKeys = (data: ChartDataObjectProps[]): Set<string> => {
  const keys = new Set<string>();

  data.forEach(item => {
    Object.keys(item).forEach(key => {
      if (key !== 'timestamp') {
        keys.add(key);
      }
    });
  });

  return keys;
};

// Extract formatted timestamps from data
const extractFormattedTimestamps = (data: ChartDataObjectProps[], dateRange: DateRange): Map<string, Date> => {
  const timestampMap = new Map<string, Date>();

  data.forEach(item => {
    const parsedDate = parseTimestamp(item.timestamp);
    if (parsedDate) {
      const formattedTimestamp = formatTimestamp(parsedDate, dateRange);
      timestampMap.set(formattedTimestamp, parsedDate);
    }
  });

  return timestampMap;
};

// Sort data chronologically
const sortChronologically = <T extends { timestamp: string | Date }>(items: T[]): T[] => {
  return [...items].sort((a, b) => {
    const dateA = parseTimestamp(a.timestamp);
    const dateB = parseTimestamp(b.timestamp);
    if (!dateA || !dateB) return 0;
    return dateA.getTime() - dateB.getTime();
  });
};

// Create initial data map with last known values
const createInitialDataMap = (
  sortedTimestamps: [string, Date][],
  allKeys: Set<string>,
): [Map<string, Record<string, unknown>>, Record<string, unknown>] => {
  const dataMap = new Map<string, Record<string, unknown>>();
  const lastKnownValues: Record<string, unknown> = {};

  // Initialize last known values
  allKeys.forEach(key => {
    lastKnownValues[key] = 0;
  });

  // Initialize entries with last known values
  sortedTimestamps.forEach(([formattedTimestamp]) => {
    const initialItem: Record<string, unknown> = { timestamp: formattedTimestamp };

    allKeys.forEach(key => {
      initialItem[key] = lastKnownValues[key];
    });

    dataMap.set(formattedTimestamp, initialItem);
  });

  return [dataMap, lastKnownValues];
};

// Process data and update values
const processData = (
  sortedData: ChartDataObjectProps[],
  dataMap: Map<string, Record<string, unknown>>,
  lastKnownValues: Record<string, unknown>,
  dateRange: DateRange,
): void => {
  sortedData.forEach(item => {
    const parsedTimestamp = parseTimestamp(item.timestamp);
    if (!parsedTimestamp) return;

    const formattedTimestamp = formatTimestamp(parsedTimestamp, dateRange);
    const aggregatedItem = dataMap.get(formattedTimestamp);
    if (!aggregatedItem) return;

    // Update each property and track last known values
    Object.entries(item).forEach(([key, value]) => {
      if (key !== 'timestamp') {
        aggregatedItem[key] = value;
        lastKnownValues[key] = value;
      }
    });
  });
};

export function useChart(data: ChartDataObjectProps[] | undefined, dateRange: DateRange = 'day') {
  return useMemo(() => {
    if (!data || !data.length) return [];

    // Extract unique keys and timestamps
    const allKeys = extractUniqueKeys(data);
    const timestampMap = extractFormattedTimestamps(data, dateRange);

    if (timestampMap.size === 0) return [];

    // Sort timestamps chronologically
    const sortedTimestamps = Array.from(timestampMap.entries()).sort((a, b) => a[1].getTime() - b[1].getTime());

    // Create initial data map with last known values
    const [dataMap, lastKnownValues] = createInitialDataMap(sortedTimestamps, allKeys);

    // Process data and update values
    const sortedData = sortChronologically(data);
    processData(sortedData, dataMap, lastKnownValues, dateRange);

    // Convert to array and sort
    return Array.from(dataMap.values()).sort((a, b) => {
      const dateA = parseISO(a.timestamp as string);
      const dateB = parseISO(b.timestamp as string);
      return dateA.getTime() - dateB.getTime();
    }) as ChartDataObjectProps[];
  }, [data, dateRange]);
}
