import * as React from 'react';
import type { DateRange } from 'react-day-picker';
import { endOfMonth, endOfWeek, format, getYear, startOfMonth, startOfWeek } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';

import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface CalendarFilterProps {
  setDateRange: (range: DateRange) => void;
  dateRange: DateRange | undefined;
}

export const getCurrentWeekRange = (): DateRange => {
  const now = new Date();

  const from = startOfWeek(now, { weekStartsOn: 1 });

  const to = endOfWeek(now, { weekStartsOn: 1 });
  return { from, to };
};

export function CalendarDateRangePicker({ dateRange, setDateRange }: CalendarFilterProps) {
  const [open, setOpen] = React.useState(false);

  const [displayedDate, setDisplayedDate] = React.useState<DateRange | undefined>(dateRange);

  const handleDateChange = (newDate: DateRange | undefined) => {
    if (newDate) {
      setDisplayedDate(newDate);
    }
  };

  function handleConfirm() {
    if (displayedDate) {
      setDateRange(displayedDate);
    }

    setOpen(false);
  }

  const handleThisWeekClick = () => {
    const weekRange = getCurrentWeekRange();
    setDateRange(weekRange);
    setOpen(false);
  };

  const handleMonthSelect = (value: string) => {
    const monthMap: Record<string, number> = {
      janeiro: 0,
      fevereiro: 1,
      março: 2,
      abril: 3,
      maio: 4,
      junho: 5,
      julho: 6,
      agosto: 7,
      setembro: 8,
      outubro: 9,
      novembro: 10,
      dezembro: 11,
    };

    const monthIndex = monthMap[value.toLowerCase()];
    if (monthIndex === undefined) return;

    const year = displayedDate?.from ? getYear(displayedDate.from) : new Date().getFullYear();
    const from = startOfMonth(new Date(year, monthIndex));
    const to = endOfMonth(new Date(year, monthIndex));

    setDisplayedDate({ from, to });
  };

  const handleYearSelect = (value: string) => {
    const year = Number.parseInt(value);
    if (isNaN(year)) return;

    const monthFrom = displayedDate?.from?.getMonth();
    const monthTo = displayedDate?.to?.getMonth();

    const from = new Date(year, monthFrom || 0, 1);
    const to = new Date(year, monthTo || 11, 31);

    setDisplayedDate({ from, to });
  };

  return (
    <div className={cn('grid gap-2 px-4')}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant="outline"
            size="sm"
            className={cn('justify-start text-left font-normal', !displayedDate && 'text-muted-foreground')}
          >
            <CalendarIcon className="h-4 w-4" />
            {displayedDate?.from &&
              (displayedDate.to ? (
                <>
                  {format(displayedDate.from, 'LLL dd, y')} - {format(displayedDate.to, 'LLL dd, y')}
                </>
              ) : (
                format(displayedDate.from, 'LLL dd, y')
              ))}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <div className="p-4 flex items-center gap-2">
            <Button variant="outline" onClick={handleThisWeekClick} className="font-normal">
              Esta semana
            </Button>
            <Select onValueChange={handleMonthSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Mês" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="janeiro">Janeiro</SelectItem>
                  <SelectItem value="fevereiro">Fevereiro</SelectItem>
                  <SelectItem value="março">Março</SelectItem>
                  <SelectItem value="abril">Abril</SelectItem>
                  <SelectItem value="maio">Maio</SelectItem>
                  <SelectItem value="junho">Junho</SelectItem>
                  <SelectItem value="julho">Julho</SelectItem>
                  <SelectItem value="agosto">Agosto</SelectItem>
                  <SelectItem value="setembro">Setembro</SelectItem>
                  <SelectItem value="outubro">Outubro</SelectItem>
                  <SelectItem value="novembro">Novembro</SelectItem>
                  <SelectItem value="dezembro">Dezembro</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            <Select onValueChange={handleYearSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Ano" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="2023">2023</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={displayedDate?.from}
            selected={displayedDate}
            onSelect={handleDateChange}
            numberOfMonths={2}
          />
          <div className="px-4 pb-4 flex justify-end">
            <Button variant="secondary" onClick={handleConfirm}>
              Confirmar
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
