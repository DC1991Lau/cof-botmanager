import { type LucideIcon } from 'lucide-react';

import { SidebarGroup, SidebarMenu } from '@/components/ui/sidebar';
import { NavGroup } from './nav-group';
import NavItem from './nav-item';
import { useAppStore } from '@/hooks/use-app-store';
import { useLocation } from 'react-router-dom';

export function NavProject({
  items,
}: {
  items: {
    title: string;
    url: string;
    icon?: LucideIcon;
    isActive?: boolean;
    items?: {
      title: string;
      url: string;
    }[];
  }[];
}) {
  const location = useLocation();
  const { activeProject } = useAppStore();

  if (!activeProject || location.pathname === '/') {
    return;
  }
  return (
    <SidebarGroup>
      <SidebarMenu>
        {items.map(item =>
          item.items && item.items.length > 0 ? <NavGroup item={item} key={item.url} /> : <NavItem item={item} key={item.url} />,
        )}
      </SidebarMenu>
    </SidebarGroup>
  );
}
