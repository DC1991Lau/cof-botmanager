import { type LucideIcon } from 'lucide-react';

import { SidebarGroup, SidebarGroupLabel, SidebarMenu } from '@/components/ui/sidebar';

import { NavGroup } from './nav-group';
import { NavAppItem } from './nav-app-item';

export function NavApp({
  items,
}: {
  items: {
    title: string;
    url: string;
    icon?: LucideIcon;
    isActive?: boolean;
    items?: {
      title: string;
      url: string;
    }[];
  }[];
}) {
  return (
    <SidebarGroup className="self-end">
      <SidebarGroupLabel>App</SidebarGroupLabel>
      <SidebarMenu>
        {items.map(item =>
          item.items && item.items.length > 0 ? <NavGroup item={item} key={item.url} /> : <NavAppItem item={item} key={item.url} />,
        )}
      </SidebarMenu>
    </SidebarGroup>
  );
}
