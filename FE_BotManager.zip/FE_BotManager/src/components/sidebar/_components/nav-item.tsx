import { NavLink } from 'react-router-dom';
import { SidebarMenuButton, SidebarMenuItem } from '../../ui/sidebar';
import { NavItemProps } from './nav-group';
import { useAppStore } from '@/hooks/use-app-store';

export default function NavItem({ item }: { item: NavItemProps }) {
  const { activeProject } = useAppStore();
  return (
    <SidebarMenuItem key={item.title}>
      <NavLink to={`/${activeProject?.name}${item.url}`}>
        {({ isActive }) => (
          <SidebarMenuButton tooltip={item.title} isActive={isActive}>
            {item.icon && <item.icon />}
            <span>{item.title}</span>
          </SidebarMenuButton>
        )}
      </NavLink>
    </SidebarMenuItem>
  );
}
