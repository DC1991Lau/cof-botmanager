import { Collapsible, CollapsibleContent } from '@/components/ui/collapsible';
import { SidebarMenuButton, SidebarMenuItem, SidebarMenuSub } from '@/components/ui/sidebar';
import { CollapsibleTrigger } from '@radix-ui/react-collapsible';

import { ChevronRight, LucideIcon } from 'lucide-react';
import NavItem from './nav-item';

export interface NavItemProps {
  title: string;
  url: string;
  icon?: LucideIcon;
  isActive?: boolean;
  items?: {
    title: string;
    icon?: LucideIcon;
    url: string;
  }[];
}

export function NavGroup({ item }: { item: NavItemProps }) {
  return (
    <Collapsible key={item.title} asChild defaultOpen={item.isActive} className="group/collapsible">
      <SidebarMenuItem>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton tooltip={item.title}>
            {item.icon && <item.icon />}
            <span>{item.title}</span>
            <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <SidebarMenuSub>{item.items?.map(subItem => <NavItem key={subItem.title} item={subItem} />)}</SidebarMenuSub>
        </CollapsibleContent>
      </SidebarMenuItem>
    </Collapsible>
  );
}
