import { NavLink } from 'react-router-dom';
import { SidebarMenuButton, SidebarMenuItem } from '../../ui/sidebar';
import { NavItemProps } from './nav-group';

export function NavAppItem({ item }: { item: NavItemProps }) {
  return (
    <SidebarMenuItem key={item.title}>
      <NavLink to={item.url}>
        {({ isActive }) => (
          <SidebarMenuButton tooltip={item.title} isActive={isActive}>
            {item.icon && <item.icon />}
            <span>{item.title}</span>
          </SidebarMenuButton>
        )}
      </NavLink>
    </SidebarMenuItem>
  );
}
