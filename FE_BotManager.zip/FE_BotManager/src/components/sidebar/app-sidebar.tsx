import * as React from 'react';
import { Brain, Home, Inbox, Lock, MessageCircle, PieChart, Settings, SquareTerminal, TableOfContents, User } from 'lucide-react';
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarRail } from '@/components/ui/sidebar';
import { ProjectSwitcher } from './_components/project-switcher';
import { NavProject } from './_components/nav-project';
import { useAppStore } from '@/hooks/use-app-store';
import AppLogo from '../app-logo';
import { NavApp } from './_components/nav-app';

const sidebarConfig = {
  projectNav: [
    {
      title: 'Overview',
      url: '/overview',
      icon: SquareTerminal,
    },
    {
      title: 'Conversas',
      url: '/conversations',
      icon: MessageCircle,
    },
    {
      title: 'Nlu',
      url: '#nlu',
      icon: Brain,
      items: [
        {
          title: 'Inbox',
          icon: Inbox,
          url: '/nlu-inbox',
        },
        {
          title: 'Anotações',
          icon: TableOfContents,
          url: '/annotations',
        },
      ],
    },
    // {
    //   title: 'Treino',
    //   url: '#treino',
    //   icon: Workflow,
    //   items: [
    //     {
    //       title: 'Dados de Treino',
    //       icon: FileText,
    //       url: '/training-data',
    //     },
    //     {
    //       title: 'Dominio',
    //       icon: Blocks,
    //       url: '/domain',
    //     },
    //   ],
    // },
    {
      title: 'Analytics',
      url: '/analytics',
      icon: PieChart,
    },
    // {
    //   title: 'Modelos',
    //   url: '/models',
    //   icon: Package,
    // },
    {
      title: 'Definições',
      url: '/settings',
      icon: Settings,
    },
  ],
  appNav: [
    {
      title: 'Home',
      url: '/',
      icon: Home,
    },
    {
      title: 'Admin',
      url: '/admin',
      icon: Lock,
    },
    {
      title: 'Perfil',
      url: '/profile',
      icon: User,
    },
  ],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { projects } = useAppStore();
  if (!projects) {
    return;
  }

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <ProjectSwitcher projects={projects} />
      </SidebarHeader>
      <SidebarContent className="flex flex-1 flex-col justify-between">
        <NavProject items={sidebarConfig.projectNav} />
        <NavApp items={sidebarConfig.appNav} />
      </SidebarContent>
      <SidebarFooter>
        {' '}
        <AppLogo />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
