import { cn } from '@/lib/utils';
import React from 'react';

interface JsonHighlighterProps {
  text: string;
  className?: string;
}

export function JsonHighlighter({ text, className }: JsonHighlighterProps) {
  const jsonRegex = /{[^{}]*}|{.*}/g;
  const parts = text.split(jsonRegex);
  const matches = text.match(jsonRegex) || [];

  return (
    <span>
      {parts.map((part, index) => (
        <React.Fragment key={index}>
          {part}
          {matches[index] && <span className={cn('bg-primary', className)}>{matches[index]}</span>}
        </React.Fragment>
      ))}
    </span>
  );
}
