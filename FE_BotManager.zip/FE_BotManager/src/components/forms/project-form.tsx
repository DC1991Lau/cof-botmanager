import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';

import Spinner from '@/components/ui/spinner';

import { Project, ProjectCreate } from '@/services/api/requests';
import {
  useProjectsServiceCreateProjectProjectsPost,
  useProjectsServiceReadProjectsProjectsGetKey,
  useProjectsServiceUpdateProjectProjectsProjectIdPut,
} from '@/services/api/queries';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

type ProjectFormProps = {
  project?: Project;
};

const signInFormSchema = z.object({
  name: z.string().min(1),
  description: z.string(),
  queue_name: z.string().min(1),
  url_connection: z.string().min(1),
  port: z.string().min(1),
});

export function ProjectForm({ project }: ProjectFormProps) {
  const queryClient = useQueryClient();
  const { mutateAsync: createProject, isPending: createIsPending } = useProjectsServiceCreateProjectProjectsPost({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [useProjectsServiceReadProjectsProjectsGetKey],
      });
    },
  });
  const { mutateAsync: updateProject, isPending: updateIsPending } = useProjectsServiceUpdateProjectProjectsProjectIdPut({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [useProjectsServiceReadProjectsProjectsGetKey],
      });
    },
  });

  const defaultValues: Project | ProjectCreate = project
    ? project
    : {
        name: '',
        description: '',
        url_connection: '',
        queue_name: '',
        port: 0,
      };

  const form = useForm<Project>({
    resolver: zodResolver(signInFormSchema),
    defaultValues,
  });

  async function onSubmit(values: Project) {
    if (project) {
      await updateProject({
        projectId: project.id,
        requestBody: { ...values, port: Number(values.port) },
      });
    } else {
      await createProject({
        requestBody: { ...values, port: Number(values.port) },
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="grid gap-4">
          <div className="grid gap-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    {/* @ts-expect-error: Should expect string */}
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="url_connection"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Url</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="port"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Port</FormLabel>
                  <FormControl>
                    <Input {...field} type="number" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="queue_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Queue</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <Button type="submit" variant="secondary" disabled={updateIsPending || createIsPending} className="mt-3">
          {(updateIsPending || createIsPending) && <Spinner />}
          Criar
        </Button>
      </form>
    </Form>
  );
}
