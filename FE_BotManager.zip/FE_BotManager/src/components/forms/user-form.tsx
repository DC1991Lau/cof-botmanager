import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

import type { UserCreate } from '@/services/api/requests';
import { useAuthServiceRegisterRegisterAuthRegisterPost, useProjectsServiceReadProjectsProjectsGetKey } from '@/services/api/queries';

type UserFormProps = {
  user?: UserCreate;
};

const signInFormSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  is_active: z.boolean().default(true),
  is_superuser: z.boolean().default(false),
  is_verified: z.boolean().default(true),
});

export function UserForm({ user }: UserFormProps) {
  const queryClient = useQueryClient();
  const { mutateAsync: createUser, isPending: createIsPending } = useAuthServiceRegisterRegisterAuthRegisterPost({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [useProjectsServiceReadProjectsProjectsGetKey],
      });
    },
  });

  const defaultValues: UserCreate = user
    ? user
    : {
        email: '',
        password: '',
        is_active: true,
        is_superuser: false,
        is_verified: true,
      };

  const form = useForm<UserCreate>({
    resolver: zodResolver(signInFormSchema),
    defaultValues,
  });

  async function onSubmit(values: UserCreate) {
    await createUser({
      requestBody: {
        email: values.email,
        password: values.password,
        is_active: values.is_active,
        is_superuser: values.is_superuser,
        is_verified: values.is_verified,
      },
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <CardContent className="space-y-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input placeholder="email@example.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input type="password" placeholder="••••••" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2">
            <h3 className="text-sm font-medium">User Permissions</h3>

            <FormField
              control={form.control}
              name="is_superuser"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    {/* @ts-expect-error: Should expect string */}
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Admin User</FormLabel>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="is_active"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    {/* @ts-expect-error: Should expect string */}
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Active Account</FormLabel>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="is_verified"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    {/* @ts-expect-error: Should expect string */}
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Verified Account</FormLabel>
                  </div>
                </FormItem>
              )}
            />
          </div>
        </CardContent>

        <Button type="submit" className="w-full" disabled={createIsPending}>
          {createIsPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            'Create User'
          )}
        </Button>
      </form>
    </Form>
  );
}
