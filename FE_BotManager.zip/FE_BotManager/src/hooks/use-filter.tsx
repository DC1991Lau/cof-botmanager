import { useSearchParams } from 'react-router-dom';
import { useCallback, useMemo } from 'react';

export interface UseFiltersOptions {
  preserveParams?: boolean;
}

export function useFilters({ preserveParams = false }: UseFiltersOptions = {}) {
  const [searchParams, setSearchParams] = useSearchParams();

  const updateFilters = useCallback(
    (updates: Record<string, string | null>) => {
      setSearchParams(prev => {
        const newParams = new URLSearchParams();

        // Apply updates
        Object.entries(updates).forEach(([key, value]) => {
          if (value === null) {
            newParams.delete(key);
          } else {
            newParams.set(key, value);
          }
        });

        // Handle existing params
        if (preserveParams) {
          prev.forEach((value, key) => {
            if (!(key in updates)) {
              newParams.set(key, value);
            }
          });
        }

        return newParams;
      });
    },
    [setSearchParams, preserveParams],
  );

  const setFilter = useCallback(
    (filterId: string, value: string | null) => {
      setSearchParams(prev => {
        const newParams = new URLSearchParams(prev);

        if (value === null) {
          newParams.delete(filterId);
        } else {
          newParams.set(filterId, value);
        }

        if (!preserveParams) {
          // Keep only current filter params
          prev.forEach((_, key) => {
            if (key !== filterId) {
              newParams.delete(key);
            }
          });
        }

        return newParams;
      });
    },
    [setSearchParams, preserveParams],
  );

  const resetFilters = useCallback(() => {
    setSearchParams(new URLSearchParams());
  }, [setSearchParams]);

  const hasActiveFilters = useMemo(() => searchParams.size > 0, [searchParams]);

  return {
    // State
    searchParams,
    hasActiveFilters,

    // Actions
    setFilter,
    updateFilters,
    resetFilters,

    // Utilities
    getFilterValue: useCallback((filterId: string) => searchParams.get(filterId), [searchParams]),
    isFilterActive: useCallback((filterId: string) => searchParams.has(filterId), [searchParams]),
  };
}
