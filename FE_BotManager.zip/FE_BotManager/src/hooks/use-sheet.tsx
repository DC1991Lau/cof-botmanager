import { create } from 'zustand';
import { ReactNode } from 'react';

type GlobalSheetStore = {
  isOpen: boolean;
  sheetContent: ReactNode | null;
  openSheet: (form: ReactNode) => void;
  closeSheet: () => void;
  setIsOpen: (isOpen: boolean) => void;
};

export const useSheetStore = create<GlobalSheetStore>(set => ({
  isOpen: false,
  sheetContent: null,
  openSheet: form => set({ isOpen: true, sheetContent: form }),
  closeSheet: () => set({ isOpen: false, sheetContent: null }),
  setIsOpen: isOpen => set({ isOpen }),
}));

export const useSheet = () => {
  const { openSheet, closeSheet } = useSheetStore();
  return { openSheet, closeSheet };
};
