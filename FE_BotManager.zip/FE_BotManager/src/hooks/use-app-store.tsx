import { create } from 'zustand';
import { Project } from '@/services/api/requests';

interface GlobalAppStore {
  projects: Project[] | null;
  activeProject: Project | null;
  activeConversationId: number | null;
  setProjects: (projects: Project[] | null | undefined) => void;
  setActiveProject: (project: Project) => void;
  setActiveConversationId: (conversationId: number | null) => void;
  getProjectByName: (projectName: string) => Project | null;
  clearActiveProject: () => void;
}

export const useAppStore = create<GlobalAppStore>((set, get) => ({
  projects: null,
  activeProject: null,
  activeConversationId: null,

  setProjects: projects => set({ projects: projects ?? null }),

  getProjectByName: projectName => {
    const { projects } = get();
    if (!projects) return null;

    return projects.find(project => project.name === projectName) ?? null;
  },

  setActiveProject: project => set({ activeProject: project }),
  setActiveConversationId: conversationId => {
    return set({ activeConversationId: conversationId });
  },

  clearActiveProject: () => set({ activeProject: null }),
}));
