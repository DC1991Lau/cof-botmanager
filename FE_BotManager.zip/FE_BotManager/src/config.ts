// IMPORTANT NOTE:
// If the variable is not a string, then convert it to desired type (boolean, number, date...)

export const appConfig = {
  URL_API: import.meta.env.VITE_URL_API,
};
