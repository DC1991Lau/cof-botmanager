import { ChartConfig } from '@/components/ui/chart';
import { NLUInboxItem } from '@/services/api/requests';
import { Table } from '@tanstack/react-table';
import { AreaProps, LineProps } from 'recharts';

export type FilterType = 'text' | 'select' | 'date' | 'number' | 'boolean' | 'range';

export interface FilterOption {
  label: string;
  value: string | number;
}

export interface FilterSchema {
  id: string;
  label: string;
  type: FilterType;
  options?: FilterOption[];
}

export interface FiltersConfig {
  filters: FilterSchema[];
  preserveParams?: boolean;
}

export interface DataTableToolbarProps<TData> {
  table: Table<TData>;
  filters: FilterSchema[];
}

export interface FilterComponentProps {
  filter: FilterSchema;
  table: Table<any>;
}

export interface NluGroupedItems extends NLUInboxItem {
  children?: NLUInboxItem[];
}

export interface ChartComponentProps {
  range: 'day' | 'month' | 'year';
}

export interface nluInboxItemIntentRankingProps {
  name: string;
  confidence: number;
}

export type ChartDataObjectProps = {
  timestamp: string | Date;
  [key: string]: string | Date | number | unknown;
};

export type ChartDataProps = ChartDataObjectProps[];

export type ChartProps = {
  data: ChartDataProps;
  config: ChartConfig;
  groupBy?: GroupByProps;
  areaProps?: AreaProps;
  lineProps?: LineProps;
};

export type GroupByProps = 'day' | 'month' | 'year';
