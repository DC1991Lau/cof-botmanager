import Page from '@/components/layout/page';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Input } from '@/components/ui/input';
import { useAppStore } from '@/hooks/use-app-store';
import { useNluServiceReadAnnotationsDataAnnotationsDataGet } from '@/services/api/queries';
import { transformToGroupedArray } from '@/utils/data-utils';
import { ChevronDown, Search, TableIcon as TableOfContents } from 'lucide-react';
import { useState } from 'react';
import Loading from './loading';

export default function AnnotationsPage() {
  const { activeProject } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');

  const { data, isLoading } = useNluServiceReadAnnotationsDataAnnotationsDataGet({
    projectId: activeProject!.id,
  });

  if (isLoading) {
    return <Loading />;
  }

  if (!data || data.length === 0) {
    return (
      <Page title="Anotações" Icon={TableOfContents}>
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <TableOfContents className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">Nenhuma anotação encontrada</h3>
          <p className="text-muted-foreground max-w-md">
            Não há anotações disponíveis para este projeto. Adicione anotações para visualizá-las aqui.
          </p>
        </div>
      </Page>
    );
  }

  const groupedData = transformToGroupedArray(data);

  // Filter data based on search query
  const filteredData = searchQuery
    ? groupedData.filter(
        intent =>
          intent.annotated_intent.toLowerCase().includes(searchQuery.toLowerCase()) ||
          intent.items.some(item => item.text.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    : groupedData;

  return (
    <Page title="Anotações" Icon={TableOfContents}>
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por intenção ou texto..."
            className="pl-8"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-4">
        {filteredData.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">Nenhum resultado encontrado para "{searchQuery}"</p>
        ) : (
          filteredData.map(intent => (
            <Card key={intent.annotated_intent} className="overflow-hidden">
              <Collapsible>
                <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-2 font-medium">
                    <span>{intent.annotated_intent}</span>
                    <Badge variant="secondary" className="ml-2">
                      {intent.items.length} {intent.items.length === 1 ? 'exemplo' : 'exemplos'}
                    </Badge>
                  </div>
                  <ChevronDown
                    size={18}
                    className="text-muted-foreground transition-transform duration-200 group-data-[state=open]:rotate-180"
                  />
                </CollapsibleTrigger>

                <CollapsibleContent>
                  <CardContent className="pt-0">
                    <div className="border-t pt-4 space-y-3">
                      {intent.items.map((item, index) => (
                        <div key={item.id} className="p-3 rounded-md bg-muted/50 hover:bg-muted transition-colors">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground font-mono">#{index + 1}</span>
                            <p>{item.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ))
        )}
      </div>
    </Page>
  );
}
