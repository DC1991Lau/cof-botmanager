import { useNluServiceReadNluInboxItemsNluInboxGet } from '@/services/api/queries';
import { columns } from './_components/columns';

import { useAppStore } from '@/hooks/use-app-store';
import Loading from './loading';

import { NluInboxTable } from './_components/nlu-inbox-table';
import Page from '@/components/layout/page';
import { Inbox } from 'lucide-react';
import { transformApiResponse } from '@/utils/data-utils';

export default function NluInboxPage() {
  const { activeProject } = useAppStore();

  const { data: nluInboxItems, isLoading } = useNluServiceReadNluInboxItemsNluInboxGet(
    {
      projectId: activeProject!.id,
      annotatedIntentIsnull: true,
    },
    undefined,
    {
      staleTime: 1000 * 30,
      refetchOnWindowFocus: true,
    },
  );

  if (isLoading) {
    return <Loading />;
  }

  if (!nluInboxItems) {
    return <div>No data</div>;
  }

  const transformed = transformApiResponse(nluInboxItems);

  return (
    <Page title="Nlu Inbox" Icon={Inbox}>
      <NluInboxTable columns={columns} data={transformed} />
    </Page>
  );
}
