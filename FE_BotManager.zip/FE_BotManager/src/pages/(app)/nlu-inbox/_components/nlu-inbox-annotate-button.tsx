import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import { useToast } from '@/hooks/use-toast';
import {
  useNluServiceCreateAnnotationsDataAnnotationsDataPost,
  useNluServiceReadAnnotationsDataAnnotationsDataGetKey,
  useNluServiceReadNluInboxItemsNluInboxGetKey,
  useNluServiceUpdateNluInboxItemNluInboxItemIdPut,
} from '@/services/api/queries';
import { nluInboxItemIntentRankingProps } from '@/types';
import { TransformedItem } from '@/utils/data-utils';
import { useQueryClient } from '@tanstack/react-query';
import { Check } from 'lucide-react';
import { useState } from 'react';

export default function NluInboxAnnotateButton({
  intentRankingJson,
  predicted_intent,
  nluInboxItem,
}: {
  intentRankingJson: nluInboxItemIntentRankingProps[];
  predicted_intent: string;
  nluInboxItem: TransformedItem;
}) {
  const queryClient = useQueryClient();
  const [value, setValue] = useState(nluInboxItem.predicted_intent);
  const { toast } = useToast();

  const { mutateAsync, isPending } = useNluServiceUpdateNluInboxItemNluInboxItemIdPut({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [useNluServiceReadNluInboxItemsNluInboxGetKey],
      });
    },
    onError: () => {
      toast({
        title: 'Ups alguma coisa correu mal',
        variant: 'destructive',
      });
    },
  });

  const { mutateAsync: createAnnotation, isPending: annotationPending } = useNluServiceCreateAnnotationsDataAnnotationsDataPost({
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [useNluServiceReadAnnotationsDataAnnotationsDataGetKey],
      });
      toast({
        title: 'Anotação feita com sucesso',
        variant: 'default',
      });
    },
    onError: () => {
      toast({
        title: 'Ups alguma coisa correu mal',
        variant: 'destructive',
      });
    },
  });

  async function handleAnnotateNluItem() {
    try {
      await mutateAsync({
        itemId: nluInboxItem.id,
        requestBody: {
          ...nluInboxItem,
          annotated_intent: value,
        },
      });

      await createAnnotation({
        requestBody: {
          project_id: nluInboxItem.project_id,
          text: nluInboxItem.text,
          annotated_intent: value,
        },
      });

      toast({
        title: 'Anotação completa com sucesso',
        description: 'Item atualizado e anotação criada',
        variant: 'default',
      });
    } catch (error) {
      toast({
        title: 'Erro ao processar anotação',
        description: 'Verifique os logs para mais detalhes',
        variant: 'destructive',
      });
      console.error('Error during annotation process:', error);
    }
  }
  return (
    <div className="flex justify-between items-center gap-2 min-w-fit">
      <Select onValueChange={value => setValue(value)} value={value}>
        <SelectTrigger className="h-8">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {intentRankingJson.length > 1 && (
            <SelectGroup>
              <SelectLabel>Intent Ranking</SelectLabel>
              {intentRankingJson
                .filter(item => item.name !== predicted_intent)
                .map(item => (
                  <SelectItem key={item.name} value={item.name}>
                    {item.name}
                  </SelectItem>
                ))}
            </SelectGroup>
          )}
          <SelectGroup>
            <SelectLabel>Model Intents</SelectLabel>
            {intentRankingJson.map(item => (
              <SelectItem key={item.name} value={item.name}>
                {item.name}
              </SelectItem>
            ))}
          </SelectGroup>
        </SelectContent>
      </Select>
      <Button variant="outline" size="icon" className=" hover:bg-green-300 h-7 w-7" onClick={handleAnnotateNluItem} disabled={isPending}>
        {isPending || annotationPending ? <Spinner /> : <Check />}
      </Button>
    </div>
  );
}
