import { useDataTable } from '@/components/hooks/use-data-table';
import { NluInboxDataTableToolbar } from './nlu-inbox-data-table-toolbar';
import { DataTableComponent } from '@/components/data-table/data-table-component';
import { ColumnDef } from '@tanstack/react-table';
import { ScrollArea } from '@/components/ui/scroll-area';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
}

export function NluInboxTable<TData, TValue>({ columns, data }: DataTableProps<TData, TValue>) {
  const { table } = useDataTable({
    data,
    columns,
  });
  return (
    <div className="flex flex-col gap-3 w-full h-full">
      <NluInboxDataTableToolbar table={table} />
      <ScrollArea className="h-full">
        <DataTableComponent table={table} columns={columns} />
      </ScrollArea>
    </div>
  );
}
