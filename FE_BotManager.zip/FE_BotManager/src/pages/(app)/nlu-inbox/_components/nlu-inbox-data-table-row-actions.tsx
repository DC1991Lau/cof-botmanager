import { Row } from '@tanstack/react-table';
import { MessageCircle, MoreHorizontal } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { NavLink, useLocation } from 'react-router-dom';

import { TransformedItem } from '@/utils/data-utils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface DataTableRowActionsProps {
  row: Row<TransformedItem>;
}

export function NluInboxDataTableRowActions({ row }: DataTableRowActionsProps) {
  const location = useLocation();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="h-7 w-7">
          <MoreHorizontal />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent className="rounded-lg" side="bottom">
        {row.original.conversations.map(conversation => (
          <DropdownMenuItem asChild key={conversation.conversation_id}>
            <NavLink
              to={{
                pathname: location.pathname, // or whatever your current path is
                search: `?conversationId=${conversation.conversation_id}`,
              }}
            >
              <MessageCircle size={4} />
              {conversation.conversation_id}
            </NavLink>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
