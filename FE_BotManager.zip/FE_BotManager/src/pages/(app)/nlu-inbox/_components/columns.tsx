import type { ColumnDef } from '@tanstack/react-table';

import { DataTableColumnHeader } from '@/components/data-table/data-table-column-header';

import { cn } from '@/lib/utils';
import type { nluInboxItemIntentRankingProps } from '@/types';
import { JsonHighlighter } from '@/components/json-highlight';
import NluInboxAnnotateButton from './nlu-inbox-annotate-button';
import { NluInboxDataTableRowActions } from './nlu-inbox-data-table-row-actions';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { TransformedItem } from '@/utils/data-utils';

export const columns: ColumnDef<TransformedItem>[] = [
  {
    accessorKey: 'text',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Texto" />,
    cell: ({ row }) => {
      const text = row.getValue('text') as string;
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 max-w-md overflow-hidden">
                <JsonHighlighter className="text-xs truncate" text={text} />
              </div>
            </TooltipTrigger>
            <TooltipContent side="bottom" align="start" className="max-w-md p-4 z-50">
              <div className="flex items-center gap-2 max-w-md overflow-hidden">
                <JsonHighlighter className="text-xs truncate" text={text} />
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    },
  },
  {
    accessorKey: 'confidence',
    header: ({ column }) => <DataTableColumnHeader column={column} title="%" />,
    cell: ({ row }) => {
      const confidence = Number(row.getValue('confidence')) as number;
      return (
        <div className="flex space-x-2 justify-center">
          <span className={cn(getConfidenceColor(confidence), 'rounded-md p-1')}>{confidence.toFixed(2)}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: 'predicted_intent',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Intent" />,
    cell: ({ row }) => {
      const jsonString = row.original.intent_ranking.replace(/'/g, '"');
      let intentRankingJson: nluInboxItemIntentRankingProps[];

      try {
        intentRankingJson = JSON.parse(jsonString);
      } catch (error) {
        intentRankingJson = [];
      }

      return (
        <NluInboxAnnotateButton
          intentRankingJson={intentRankingJson}
          nluInboxItem={row.original}
          predicted_intent={row.original.predicted_intent}
          key={row.original.id}
        />
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    id: 'actions',
    cell: ({ row }) => <NluInboxDataTableRowActions row={row} />,
    enableSorting: false,
    enableHiding: false,
  },
];

function getConfidenceColor(confidence: number) {
  if (confidence >= 0.7) {
    return 'bg-green-100';
  }

  if (confidence > 0.5 && confidence < 0.7) {
    return 'bg-yellow-100';
  }

  if (confidence < 0.5) {
    return 'bg-red-100';
  }

  return 'secondary';
}
