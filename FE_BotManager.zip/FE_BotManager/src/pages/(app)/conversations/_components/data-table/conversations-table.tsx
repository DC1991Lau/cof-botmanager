import { useDataTable } from '@/components/hooks/use-data-table';

import { DataTableComponent } from '@/components/data-table/data-table-component';
import { ColumnDef } from '@tanstack/react-table';

import { ScrollArea } from '@/components/ui/scroll-area';
import { ConversationsDataTableToolbar } from './conversations-data-table-toolbar';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
}

export function ConversationsboxTable<TData, TValue>({ columns, data }: DataTableProps<TData, TValue>) {
  const { table } = useDataTable({
    data,
    columns,
  });
  return (
    <div className=" flex flex-col gap-3 w-full h-full">
      <ConversationsDataTableToolbar table={table} />
      <ScrollArea className="">
        <DataTableComponent table={table} columns={columns} />
      </ScrollArea>
    </div>
  );
}
