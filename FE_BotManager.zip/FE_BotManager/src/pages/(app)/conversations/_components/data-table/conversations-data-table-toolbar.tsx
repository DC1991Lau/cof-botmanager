import { Table } from '@tanstack/react-table';
import { X } from 'lucide-react';

import { Button } from '@/components/ui/button';

import { DataTableViewOptions } from '@/components/data-table/data-table-view-options';
import { DataTableFacetedFilter } from '@/components/data-table/data-table-faceted-filter';
import { getFacetedUniqueOptions } from '@/lib/utils';

interface DataTableToolbarProps<TData> {
  table: Table<TData>;
}

export function ConversationsDataTableToolbar<TData>({ table }: DataTableToolbarProps<TData>) {
  const isFiltered = table.getState().columnFilters.length > 0;
  const senderKeyOptions = getFacetedUniqueOptions(table, 'sender_key');
  const channelOptions = getFacetedUniqueOptions(table, 'latest_input_channel');

  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-1 items-center space-x-2">
        {/* <Input
          placeholder="Procurar por texto..."
          value={(table.getColumn('last_message')?.getFilterValue() as string) ?? ''}
          onChange={event => table.getColumn('last_message')?.setFilterValue(event.target.value)}
          className="h-8 w-[150px] lg:w-[250px]"
        /> */}

        {table.getColumn('sender_key') && (
          <DataTableFacetedFilter column={table.getColumn('sender_key')} title="Sender" options={senderKeyOptions} />
        )}
        {table.getColumn('latest_input_channel') && (
          <DataTableFacetedFilter column={table.getColumn('latest_input_channel')} title="Canal" options={channelOptions} />
        )}
        {isFiltered && (
          <Button variant="ghost" onClick={() => table.resetColumnFilters()} className="h-8 px-2 lg:px-3">
            Reset
            <X />
          </Button>
        )}
      </div>
      <DataTableViewOptions table={table} />
    </div>
  );
}
