import { Row } from '@tanstack/react-table';
import { MessageCircle } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { NavLink } from 'react-router-dom';
import { Conversation } from '@/services/api/requests';

interface DataTableRowActionsProps {
  row: Row<Conversation>;
}

export function ConversationsDataTableRowActions({ row }: DataTableRowActionsProps) {
  return (
    <NavLink
      to={{
        pathname: location.pathname, // or whatever your current path is
        search: `?conversationId=${row.original.id}`,
      }}
    >
      <Button variant="outline" size="icon" className="rounded-[6px] h-7 w-7">
        <MessageCircle size={4} />
      </Button>
    </NavLink>
  );
}
