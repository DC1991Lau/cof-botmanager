import type { ColumnDef } from '@tanstack/react-table';

import type { Conversation, LastMessage } from '@/services/api/requests';
import { DataTableColumnHeader } from '@/components/data-table/data-table-column-header';

import { JsonHighlighter } from '@/components/json-highlight';

import { Badge } from '@/components/ui/badge';
import { Bot, MessageSquare } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';
import { ConversationsDataTableRowActions } from './conversations-data-table-row-actions';

export const conversationColumns: ColumnDef<Conversation>[] = [
  {
    accessorKey: 'sender_key',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Sender" />,
    cell: ({ row }) => {
      const senderKey = row.getValue('sender_key') as string;
      return (
        <div className="flex space-x-2">
          <Badge variant="outline" className="text-xs px-2 py-0.5 border-primary">
            {senderKey.length > 20 ? `${senderKey.substring(0, 15)}...` : senderKey}
          </Badge>
          <div className="hidden group-hover:block">
            <JsonHighlighter text={senderKey} />
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: 'last_message',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Conversa" />,
    cell: ({ row }) => {
      const lastMessage = row.getValue('last_message') as LastMessage;
      return (
        <div className="flex items-center gap-2 max-w-md h-6 overflow-hidden">
          {lastMessage.is_bot ? (
            <Bot className="h-4 w-4 text-muted-foreground flex-shrink-0" />
          ) : (
            <MessageSquare className="h-4 w-4 text-muted-foreground flex-shrink-0" />
          )}
          <span className="text-xs truncate">{lastMessage.text}</span>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      const lastMessage = row.getValue(id) as LastMessage;
      return value.includes(lastMessage.text.toLowerCase());
    },
  },
  {
    accessorKey: 'latest_input_channel',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Canal" />,
    cell: ({ row }) => {
      const channel = row.getValue('latest_input_channel') as string;
      return (
        <Badge variant="outline" className="capitalize">
          {channel}
        </Badge>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableHiding: true,
    meta: {
      hidden: true,
    },
  },
  {
    accessorKey: 'latest_event_time',
    header: ({ column }) => <DataTableColumnHeader column={column} title="Updated" />,
    cell: ({ row }) => {
      const timestamp = row.getValue('latest_event_time') as string;
      const date = new Date(timestamp);
      return (
        <span className="text-muted-foreground text-sm whitespace-nowrap">{formatDistanceToNowStrict(date, { addSuffix: true })}</span>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: 'actions',
    cell: ({ row }) => <ConversationsDataTableRowActions row={row} />,
    enableSorting: false,
    enableHiding: false,
  },
];
