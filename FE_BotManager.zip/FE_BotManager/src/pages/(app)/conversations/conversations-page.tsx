import { useSearchParams } from 'react-router-dom';
import { useConversationsServiceReadConversationsConversationsGet } from '@/services/api/queries';
import { useAppStore } from '@/hooks/use-app-store';

import { MessageCircle } from 'lucide-react';
import { ConversationsboxTable } from './_components/data-table/conversations-table';
import { conversationColumns } from './_components/data-table/conversation-columns';
import Page from '@/components/layout/page';

export default function ConversationsPage() {
  const { activeProject } = useAppStore();
  const [searchParams] = useSearchParams();
  const { data: conversations, isLoading } = useConversationsServiceReadConversationsConversationsGet(
    {
      projectId: activeProject!.id,
      ...Object.fromEntries(searchParams),
    },
    undefined,
    {
      staleTime: 1000 * 30,
    },
  );

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!conversations) {
    return <div>No data</div>;
  }

  return (
    <Page title="Conversas" Icon={MessageCircle}>
      <ConversationsboxTable columns={conversationColumns} data={conversations} />
    </Page>
  );
}
