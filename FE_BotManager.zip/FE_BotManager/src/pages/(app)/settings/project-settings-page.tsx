import Page from '@/components/layout/page';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import { Pencil, Settings, Users } from 'lucide-react';
import EditProjectTab from './_components/edit-project-tab';
import ProjectUsersTab from './_components/project-users-tab';

export default function ProjectSettingsPage() {
  return (
    <Page title="Definições" Icon={Settings}>
      <Tabs defaultValue="edit_project" className="w-full">
        <TabsList>
          <TabsTrigger
            value="edit_project"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Pencil className="h-4 w-4" />
            <span>Editar Projeto</span>
          </TabsTrigger>
          <TabsTrigger
            value="users"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Users className="h-4 w-4" />
            <span>Utilizadores</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="edit_project">
          <EditProjectTab />
        </TabsContent>
        <TabsContent value="users">
          <ProjectUsersTab />
        </TabsContent>
      </Tabs>
    </Page>
  );
}
