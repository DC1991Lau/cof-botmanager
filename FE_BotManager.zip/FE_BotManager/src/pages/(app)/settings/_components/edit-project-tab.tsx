import { ProjectForm } from '@/components/forms/project-form';
import { useAppStore } from '@/hooks/use-app-store';

export default function EditProjectTab() {
  const { activeProject } = useAppStore();
  return (
    <div className="flex flex-col gap-4">
      <ProjectForm project={activeProject!} />
    </div>
  );
}
