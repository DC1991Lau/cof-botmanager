import { useAppStore } from '@/hooks/use-app-store';

import { Navigate, Outlet } from 'react-router-dom';

export default function ProjectLayout() {
  const { activeProject } = useAppStore();

  if (!activeProject) {
    return <Navigate to="/" />;
  }

  return <Outlet />;
}
