import Page from '@/components/layout/page';
import { Blocks } from 'lucide-react';

export default function DomainPage() {
  return (
    <Page title="Domain" Icon={Blocks}>
      DomainPage
    </Page>
  );
}
