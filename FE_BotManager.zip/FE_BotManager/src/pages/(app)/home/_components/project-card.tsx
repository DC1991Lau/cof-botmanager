import { Globe, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Project } from '@/services/api/requests';
import { NavLink } from 'react-router-dom';
import { useAppStore } from '@/hooks/use-app-store';

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const { setActiveProject } = useAppStore();
  return (
    <NavLink to={`/${project.queue_name}/overview`} onClick={() => setActiveProject(project)}>
      <Card className="w-full p-4 flex flex-col gap-3">
        <CardHeader className="flex flex-col">
          <CardTitle className="font-bold text-md flex gap-2 items-center">{project.name}</CardTitle>
          <CardDescription className="text-xs">{project.description || 'No description provided'}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm">
            <Globe className="mr-2 h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">URL:</span>
            <span className="ml-2 font-medium">{project.url_connection}</span>
          </div>
        </CardContent>
        <CardFooter className="pt-2">
          <div className="flex justify-between items-center w-full">
            <Badge variant={project.active ? 'success' : 'destructive'} className="flex items-center gap-1 ">
              {project.active ? (
                <>
                  <CheckCircle className="h-3 w-3" />
                  Active
                </>
              ) : (
                <>
                  <XCircle className="h-3 w-3" />
                  Inactive
                </>
              )}
            </Badge>
          </div>
        </CardFooter>
      </Card>
    </NavLink>
  );
}
