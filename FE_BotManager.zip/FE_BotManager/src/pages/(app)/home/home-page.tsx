import { useProjectsServiceReadProjectsProjectsGet, useProjectsServiceReadProjectsProjectsGetKey } from '@/services/api/queries';
import CreateProjectButton from '../../../components/new-project-button';
import ProjectCard from './_components/project-card';

export default function HomePage() {
  const { data: projects } = useProjectsServiceReadProjectsProjectsGet(undefined, [useProjectsServiceReadProjectsProjectsGetKey], {
    staleTime: 1000 * 60 * 5,
  });
  return (
    <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
      <CreateProjectButton />
      <div className="grid auto-rows-min gap-4 grd-cols-1 lg:grid-cols-3">
        {projects?.map(project => <ProjectCard project={project} key={project.id} />)}
      </div>
    </div>
  );
}
