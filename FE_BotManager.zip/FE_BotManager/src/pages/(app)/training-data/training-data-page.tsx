export default function TrainingDataPage() {
  return <div>TrainingDataPage</div>;
}
