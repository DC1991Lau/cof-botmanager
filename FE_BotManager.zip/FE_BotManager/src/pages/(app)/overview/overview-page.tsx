import {
  useStatsServiceGetGeneralStatsStatsGeneralGet,
  useStatsServiceGetSendersDistributionStatsSendersDistributionGet,
  useStatsServiceGetSessionsDistributionStatsSessionsDistributionGet,
} from '@/services/api/queries';
import { useAppStore } from '@/hooks/use-app-store';
import React from 'react';
import { DateRange } from 'react-day-picker';

import { SquareTerminal } from 'lucide-react';

import { addDays } from 'date-fns';

import UsersStatsCard from '../../../components/app-cards/users-stats-card';
import ConversationsStatsCard from '../../../components/app-cards/conversations-stats-card';
import { DatePickerWithRange } from '@/components/charts/_components/date-range-filter';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { GroupByProps } from '@/types';
import Page from '@/components/layout/page';
import RetentionRateStatsCard from '@/components/app-cards/retention-rate-stats-card';
import ConfidenceStatsCard from '@/components/app-cards/confidence-stats-card';
import SessionsDistributionChartCard from '@/components/app-cards/sessions-distribution-chart';
import UsersDistributionChartCard from '@/components/app-cards/users-distribution-chart';

export default function OverviewPage() {
  const { activeProject } = useAppStore();
  const [groupBy, setGroupBy] = React.useState<GroupByProps>('day');
  const [dateRange, setDateRange] = React.useState<DateRange | undefined>({
    from: addDays(new Date(), -7),
    to: new Date(),
  });
  const { data } = useStatsServiceGetGeneralStatsStatsGeneralGet(
    {
      projectId: activeProject!.id,
      timestampLt: dateRange?.to?.toISOString(),
      timestampGte: dateRange?.from?.toISOString(),
    },
    undefined,
    {
      staleTime: 1000 * 30,
    },
  );

  const { data: sessionsData } = useStatsServiceGetSessionsDistributionStatsSessionsDistributionGet({
    projectId: activeProject!.id,
    timestampGte: dateRange?.from?.toISOString(),
    timestampLt: dateRange?.to?.toISOString(),
  });

  const { data: sendersData } = useStatsServiceGetSendersDistributionStatsSendersDistributionGet({
    projectId: activeProject!.id,
    lastSeenGte: dateRange?.from?.toISOString(),
    lastSeenLt: dateRange?.to?.toISOString(),
  });

  const handleConfirm = (value: GroupByProps) => {
    setGroupBy(value);
  };

  return (
    <Page title="Overview" Icon={SquareTerminal}>
      <div className="flex gap-3 justify-end">
        <Select onValueChange={handleConfirm} defaultValue={groupBy}>
          <SelectTrigger className="h-9 max-w-fit">
            <SelectValue placeholder="Select preset range" />
          </SelectTrigger>
          <SelectContent position="popper">
            <SelectItem value="day">Dia</SelectItem>
            <SelectItem value="month">Mês</SelectItem>
            <SelectItem value="year">Ano</SelectItem>
          </SelectContent>
        </Select>
        <DatePickerWithRange setDateRange={setDateRange} />
      </div>

      <div className="flex flex-col gap-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <UsersStatsCard data={data} />
          <ConversationsStatsCard data={data} />
          <RetentionRateStatsCard data={data} />
          <ConfidenceStatsCard data={data} />
        </div>

        <SessionsDistributionChartCard data={sessionsData} groupBy={groupBy} />
        <UsersDistributionChartCard data={sendersData} groupBy={groupBy} />
      </div>
      <div />
    </Page>
  );
}
