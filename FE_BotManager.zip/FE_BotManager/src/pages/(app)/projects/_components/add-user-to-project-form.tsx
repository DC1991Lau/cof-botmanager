import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  useProjectsServiceAddUserToProjectProjectsProjectIdUsersPost,
  useProjectsServiceReadProjectsUsersGet,
  useProjectsServiceReadProjectsUsersGetKey,
} from '@/services/api/queries';
import { useForm } from 'react-hook-form';
import { ProjectRoleCreate } from '@/services/api/requests';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAppStore } from '@/hooks/use-app-store';
import { useQueryClient } from '@tanstack/react-query';

const signInFormSchema = z.object({
  user_id: z.string().min(1),
  role: z.string().min(1),
});

export function AddUserToProjectForm() {
  const { activeProject } = useAppStore();
  const queryClient = useQueryClient();
  const { data: users, isPending: userIsPending } = useProjectsServiceReadProjectsUsersGet(
    [useProjectsServiceReadProjectsUsersGetKey],
    undefined,
  );
  const { mutateAsync, isPending } = useProjectsServiceAddUserToProjectProjectsProjectIdUsersPost({
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [useProjectsServiceReadProjectsUsersGetKey] }),
  });

  const form = useForm<ProjectRoleCreate>({
    resolver: zodResolver(signInFormSchema),
    defaultValues: {
      user_id: undefined,
      role: 'manager',
    },
  });

  if (userIsPending || isPending) {
    return <div>Loading</div>;
  }

  async function onSubmit(values: ProjectRoleCreate) {
    await mutateAsync({
      projectId: activeProject!.id,
      requestBody: {
        user_id: values.user_id,
        role: values.role,
      },
    });
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="grid gap-4">
          <div className="grid gap-4">
            <FormField
              control={form.control}
              name="user_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>User</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a verified email to display" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {users?.map(user => (
                          <SelectItem value={String(user.id)} key={user.id}>
                            {user.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a verified email to display" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value={'admin'} key={'admin'}>
                          admin
                        </SelectItem>
                        <SelectItem value={'manager'} key={'manager'}>
                          manager
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="mt-3">
              {isPending && <Spinner />}
              Submit
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
