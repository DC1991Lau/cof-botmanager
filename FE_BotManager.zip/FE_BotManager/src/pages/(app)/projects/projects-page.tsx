export default function ProjectsPage() {
  return <div>Projects Page</div>;
}
