import { DatePickerWithRange } from '@/components/charts/_components/date-range-filter';
import React, { useState } from 'react';
import { DateRange } from 'react-day-picker';
import { addDays } from 'date-fns';
import { ChartConfig } from '@/components/ui/chart';
import { useChart } from '@/components/hooks/use-chart';
import { useStatsServiceGetSendersDistributionStatsSendersDistributionGet } from '@/services/api/queries';
import { useAppStore } from '@/hooks/use-app-store';
import { BarChartComponent } from '@/components/charts/_components/bar-chart-stacked';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { GroupByProps } from '@/types';

export const UserAnalyticsDistributionChartConfig = {
  total_users: {
    label: 'Total de Utilizadores',
    color: 'hsl(var(--chart-4))',
  },
  new_users: {
    label: 'Novos Utilizadores',
    color: 'hsl(var(--chart-3))',
  },
} satisfies ChartConfig;

export default function NluAnalytics() {
  const { activeProject } = useAppStore();
  const [groupBy, setGroupBy] = useState<GroupByProps>('day');
  const [dateRange, setDateRange] = React.useState<DateRange | undefined>({
    from: addDays(new Date(), -7),
    to: new Date(),
  });

  const { data } = useStatsServiceGetSendersDistributionStatsSendersDistributionGet({
    projectId: activeProject!.id,
    lastSeenGte: dateRange?.from?.toISOString(),
    lastSeenLt: dateRange?.to?.toISOString(),
  });

  const handleConfirm = (value: GroupByProps) => {
    setGroupBy(value);
  };

  const chartData = useChart(data, groupBy);

  return (
    <>
      <div className="flex gap-3 items-start justify-end">
        <Select onValueChange={handleConfirm} defaultValue={groupBy}>
          <SelectTrigger className="h-9 max-w-fit">
            <SelectValue placeholder="Select preset range" />
          </SelectTrigger>
          <SelectContent position="popper">
            <SelectItem value="day">Dia</SelectItem>
            <SelectItem value="month">Mês</SelectItem>
            <SelectItem value="year">Ano</SelectItem>
          </SelectContent>
        </Select>
        <DatePickerWithRange setDateRange={setDateRange} />
      </div>

      <div className="flex flex-col gap-4">
        <BarChartComponent data={chartData} config={UserAnalyticsDistributionChartConfig} />
      </div>
      <div />
    </>
  );
}
