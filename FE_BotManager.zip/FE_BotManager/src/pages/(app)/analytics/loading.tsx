export default function Loading() {
  return <div>Loading</div>;
}
