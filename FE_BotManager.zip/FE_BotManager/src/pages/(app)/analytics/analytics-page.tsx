import Page from '@/components/layout/page';
import { Brain, PieChart, Users } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UserAnalytics from './_components/user-analytics';

export default function AnalyticsPage() {
  return (
    <Page title="Analytics" Icon={PieChart}>
      <Tabs defaultValue="conversations" className="w-full">
        <TabsList>
          <TabsTrigger
            value="conversations"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <PieChart className="h-4 w-4" />
            <span>Conversas</span>
          </TabsTrigger>
          <TabsTrigger
            value="users"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Users className="h-4 w-4" />
            <span>Utilizadores</span>
          </TabsTrigger>
          <TabsTrigger
            value="nlu"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Brain className="h-4 w-4" />
            <span>NLU</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="conversations">
          <UserAnalytics />
        </TabsContent>
        <TabsContent value="users">
          <UserAnalytics />
        </TabsContent>
        <TabsContent value="nlu">
          <UserAnalytics />
        </TabsContent>
      </Tabs>
    </Page>
  );
}
