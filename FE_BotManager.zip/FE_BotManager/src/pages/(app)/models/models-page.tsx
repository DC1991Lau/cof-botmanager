import Page from '@/components/layout/page';
import { Package } from 'lucide-react';

export default function ModelsPage() {
  return (
    <Page title="Modelos" Icon={Package}>
      Página de Modelos: lista de modelos e status
    </Page>
  );
}
