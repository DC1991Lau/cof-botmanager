import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useNavigate } from 'react-router-dom';
import { useAuthServiceAuthJwtLoginAuthJwtLoginPost } from '@/services/api/queries';
import { useForm } from 'react-hook-form';
import { Body_auth_jwt_login_auth_jwt_login_post } from '@/services/api/requests';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import Spinner from '@/components/ui/spinner';

const signInFormSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export function SignInForm() {
  const navigate = useNavigate();
  const { mutateAsync, isPending } = useAuthServiceAuthJwtLoginAuthJwtLoginPost({
    onSuccess: () => {
      navigate('/');
    },
  });

  const form = useForm<Body_auth_jwt_login_auth_jwt_login_post>({
    resolver: zodResolver(signInFormSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  async function onSubmit(values: Body_auth_jwt_login_auth_jwt_login_post) {
    await mutateAsync({
      formData: values,
    });
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="grid gap-4">
          <div className="grid gap-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Username</FormLabel>
                  <FormControl>
                    <Input placeholder="shadcn" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input placeholder="*****" {...field} type="password" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isPending} className="mt-3">
              {isPending && <Spinner />}
              Submit
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
