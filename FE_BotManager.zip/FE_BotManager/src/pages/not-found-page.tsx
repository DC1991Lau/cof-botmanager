export default function NotFoundPage() {
  return <div>NotFoundPage</div>;
}
