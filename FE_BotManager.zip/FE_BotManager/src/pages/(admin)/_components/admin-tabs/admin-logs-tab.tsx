export default function AdminLogsTab() {
  return <div>Admin Metrics Tab</div>;
}
