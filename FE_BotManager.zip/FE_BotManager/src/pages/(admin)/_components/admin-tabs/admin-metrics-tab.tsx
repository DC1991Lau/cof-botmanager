export default function AdminMetricsTab() {
  return <div>Admin Metrics Tab</div>;
}
