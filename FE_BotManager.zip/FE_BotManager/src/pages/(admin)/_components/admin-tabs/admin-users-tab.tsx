export default function AdminUsersTab() {
  return <div>Admin Users Metrics Tab</div>;
}
