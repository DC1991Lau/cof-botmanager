export default function AdminProjectsTab() {
  return <div>Admin Projects Metrics Tab</div>;
}
