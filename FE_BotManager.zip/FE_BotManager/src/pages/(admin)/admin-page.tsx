import { Bot, Lock, LogInIcon as Logs, PieChart, Users } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AdminMetricsTab from '../../pages/(admin)/_components/admin-tabs/admin-metrics-tab';
import AdminUsersTab from '../../pages/(admin)/_components/admin-tabs/admin-users-tab';
import AdminProjectsTab from '../../pages/(admin)/_components/admin-tabs/admin-projects-tab';
import AdminLogsTab from '../../pages/(admin)/_components/admin-tabs/admin-logs-tab';
import Page from '@/components/layout/page';

export default function AdminPage() {
  return (
    <Page title="Admin" Icon={Lock}>
      <Tabs defaultValue="metrics" className="w-full">
        <TabsList>
          <TabsTrigger
            value="metrics"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <PieChart className="h-4 w-4" />
            <span>Métricas</span>
          </TabsTrigger>
          <TabsTrigger
            value="users"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Users className="h-4 w-4" />
            <span>Utilizadores</span>
          </TabsTrigger>
          <TabsTrigger
            value="projects"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Bot className="h-4 w-4" />
            <span>Chatbots</span>
          </TabsTrigger>
          <TabsTrigger
            value="logs"
            className="flex items-center gap-2 rounded-none border-b-2 border-transparent px-2 py-1.5 data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:shadow-none"
          >
            <Logs className="h-4 w-4" />
            <span>Logs</span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="metrics">
          <AdminMetricsTab />
        </TabsContent>
        <TabsContent value="users">
          <AdminUsersTab />
        </TabsContent>
        <TabsContent value="projects">
          <AdminProjectsTab />
        </TabsContent>
        <TabsContent value="logs">
          <AdminLogsTab />
        </TabsContent>
      </Tabs>
    </Page>
  );
}
