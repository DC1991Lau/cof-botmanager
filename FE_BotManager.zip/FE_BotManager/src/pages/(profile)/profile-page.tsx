import { UserSettingsDialog } from './_components/user-settings-dialog';

export default function ProfilePage() {
  return (
    <div className="flex h-svh items-center justify-center">
      <UserSettingsDialog />
    </div>
  );
}
