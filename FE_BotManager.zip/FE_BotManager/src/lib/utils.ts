import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Table } from '@tanstack/react-table';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface FilterOption {
  label: string;
  value: string;
}

export function getFacetedUniqueOptions<TData>(table: Table<TData>, columnId: string, maxLength = 30, maxOptions = 100): FilterOption[] {
  if (!table.getColumn(columnId)) return [];

  const facetedValues = table.getColumn(columnId)?.getFacetedUniqueValues();
  if (!facetedValues || facetedValues.size === 0) return [];

  return Array.from(facetedValues.entries())
    .sort((a, b) => b[1] - a[1]) // Sort by count, descending
    .slice(0, maxOptions)
    .map(([value, count]) => {
      const valueStr = String(value);
      const truncatedValue = valueStr.length > maxLength ? `${valueStr.substring(0, maxLength)}...` : valueStr;

      return {
        label: `${truncatedValue} (${count})`,
        value: valueStr,
      };
    });
}
