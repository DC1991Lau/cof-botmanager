import './globals.css';

import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { OpenAPI } from './services/api/requests/index.ts';
import { Toaster } from './components/ui/toaster.tsx';
import OverviewPage from './pages/(app)/overview/overview-page.tsx';
import NotFoundPage from './pages/not-found-page.tsx';
import SignInPage from './pages/(auth)/sign-in.tsx';

import HomePage from './pages/(app)/home/home-page.tsx';
import ProjectLayout from './pages/(app)/project-layout.tsx';
import NluInboxPage from './pages/(app)/nlu-inbox/nlu-inbox-page.tsx';
import ConversationsPage from './pages/(app)/conversations/conversations-page.tsx';
import ModelsPage from './pages/(app)/models/models-page.tsx';
import AnalyticsPage from './pages/(app)/analytics/analytics-page.tsx';
import ProfilePage from './pages/(profile)/profile-page.tsx';
import DomainPage from './pages/(app)/domain/domain-page.tsx';

import AppLayout from './components/layout/app-layout.tsx';
import ProjectSettingsPage from './pages/(app)/settings/project-settings-page.tsx';
import AnnotationsPage from './pages/(app)/annotations/annotations-page.tsx';
import AdminPage from './pages/(admin)/admin-page.tsx';
import { appConfig } from './config.ts';

OpenAPI.BASE = appConfig.URL_API;
OpenAPI.WITH_CREDENTIALS = true;

export const queryClient = new QueryClient();

const router = createBrowserRouter([
  {
    path: '/sign-in',
    element: <SignInPage />,
    errorElement: <NotFoundPage />,
  },
  {
    path: '/',
    element: <AppLayout />,
    children: [
      { index: true, element: <HomePage />, errorElement: <NotFoundPage /> },
      {
        path: ':projectName',
        element: <ProjectLayout />,
        children: [
          { path: 'overview', element: <OverviewPage />, errorElement: <NotFoundPage /> },
          { path: 'conversations', element: <ConversationsPage />, errorElement: <NotFoundPage /> },
          { path: 'nlu-inbox', element: <NluInboxPage />, errorElement: <NotFoundPage /> },
          { path: 'annotations', element: <AnnotationsPage />, errorElement: <NotFoundPage /> },
          { path: 'models', element: <ModelsPage />, errorElement: <NotFoundPage /> },
          { path: 'analytics', element: <AnalyticsPage />, errorElement: <NotFoundPage /> },
          { path: 'domain', element: <DomainPage />, errorElement: <NotFoundPage /> },
          { path: 'settings', element: <ProjectSettingsPage />, errorElement: <NotFoundPage /> },
        ],
      },
      { path: 'profile', element: <ProfilePage />, errorElement: <NotFoundPage /> },
      {
        path: 'admin',
        element: <AdminPage />,
        errorElement: <NotFoundPage />,
      },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <QueryClientProvider client={queryClient}>
    <RouterProvider router={router} />
    <Toaster />
  </QueryClientProvider>,
);
