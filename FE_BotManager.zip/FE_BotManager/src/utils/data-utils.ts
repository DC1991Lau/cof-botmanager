import { AnnotationsData, ReadNluInboxItemsNluInboxGetResponse } from '@/services/api/requests';

interface ConversationItem {
  conversation_id: number;
  predicted_intent: string;
  intent_ranking: string;
  confidence: number;
  message_id: string;
}

export interface TransformedItem {
  project_id: number;
  conversations: ConversationItem[];
  text: string;
  predicted_intent: string;
  intent_ranking: string;
  confidence: number;
  id: number;
}

export interface GroupedAnnotatedData {
  intent: string;
  items: AnnotationsData[];
}

export const transformApiResponse = (data: ReadNluInboxItemsNluInboxGetResponse | undefined): TransformedItem[] => {
  if (!Array.isArray(data)) {
    throw new Error('Input must be an array');
  }

  // Group by predicted_intent, excluding items where text starts with a slash
  const groupedByIntent = data.reduce<Record<string, TransformedItem & { seenConversationIds: Set<number> }>>((acc, item) => {
    // Skip items where text starts with a slash
    if (item.text.startsWith('/')) {
      return acc;
    }

    const key = item.predicted_intent;

    if (!acc[key]) {
      acc[key] = {
        project_id: item.project_id,
        predicted_intent: item.predicted_intent,
        conversations: [],
        text: item.text,
        intent_ranking: item.intent_ranking,
        confidence: item.confidence,
        id: item.id,
        seenConversationIds: new Set<number>(), // Track seen conversation_ids
      };
    }

    // Only add conversation if we haven't seen this conversation_id before
    if (!acc[key]!.seenConversationIds.has(item.conversation_id)) {
      // Add conversation to the group
      acc[key]!.conversations.push({
        conversation_id: item.conversation_id,
        predicted_intent: item.predicted_intent,
        intent_ranking: item.intent_ranking,
        confidence: item.confidence,
        message_id: item.message_id,
      });

      // Mark this conversation_id as seen
      acc[key]!.seenConversationIds.add(item.conversation_id);
    }

    return acc;
  }, {});

  // Convert the record to an array and remove the helper property
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  return Object.values(groupedByIntent).map(({ seenConversationIds, ...rest }) => rest);
};

interface OutputItem {
  id: number;
  text: string;
}

interface GroupedOutput {
  annotated_intent: string;
  items: OutputItem[];
}

export function transformToGroupedArray(inputData: AnnotationsData[]): GroupedOutput[] {
  const groupedMap = new Map<string, OutputItem[]>();

  inputData.forEach(item => {
    const { project_id, text, annotated_intent } = item;

    if (!groupedMap.has(annotated_intent!)) {
      groupedMap.set(annotated_intent!, []);
    }

    groupedMap.get(annotated_intent!)?.push({
      id: project_id,
      text,
    });
  });

  const result: GroupedOutput[] = [];
  groupedMap.forEach((items, annotated_intent) => {
    result.push({
      annotated_intent,
      items,
    });
  });

  return result;
}
