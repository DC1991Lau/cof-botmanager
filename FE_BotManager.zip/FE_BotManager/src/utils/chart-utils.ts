/* eslint-disable prefer-destructuring */

type WithTimestamp = {
  timestamp: string;
  [key: string]: unknown;
};

type ChartDataItem = {
  label: string;
  [key: string]: unknown;
};

type ChartConfig = {
  [key: string]: {
    label: string;
    color: string;
  };
};

interface DataItem {
  timestamp: string;
  count: number;
}

export function createEmptyData<T extends WithTimestamp>(template: T, data?: T): ChartDataItem {
  const result: ChartDataItem = { label: '' };

  Object.keys(template).forEach(key => {
    if (key !== 'timestamp') {
      const value = template[key];
      result[key] = data ? data[key] : typeof value === 'number' ? 0 : null;
    }
  });

  return result;
}

export function joinArraysByTimestamp<T extends { timestamp: string }, U extends { timestamp: string }>(
  array1: T[],
  array2: U[],
): Array<T & Partial<U>> {
  // Create a map to store merged objects by timestamp
  const mergedMap = new Map<string, any>();

  // Process the first array
  array1.forEach(item => {
    mergedMap.set(item.timestamp, { ...item });
  });

  // Process the second array and merge with existing items
  array2.forEach(item => {
    const timestamp = item.timestamp;
    if (mergedMap.has(timestamp)) {
      // Merge with existing item
      mergedMap.set(timestamp, {
        ...mergedMap.get(timestamp),
        ...item,
      });
    } else {
      // Add new item
      mergedMap.set(timestamp, { ...item });
    }
  });

  // Convert map back to array and sort by timestamp
  return Array.from(mergedMap.values()).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}

/**
 * Transforms an array of data items with timestamp and count into a format
 * where each count is assigned to a property named according to the chart config
 */
export function transformDataByChartConfig(data: DataItem[] | undefined, chartConfig: ChartConfig): WithTimestamp[] {
  if (!data || data.length === 0 || Object.keys(chartConfig).length === 0) {
    return [];
  }

  // Get the first key from chartConfig
  const keys = Object.keys(chartConfig);
  if (keys.length === 0) {
    return [];
  }
  const configKey = keys[0];

  // Create a map to store transformed data by timestamp
  const transformedMap = new Map<string, WithTimestamp>();

  // Process each data item
  data.forEach(item => {
    transformedMap.set(item.timestamp, {
      timestamp: item.timestamp,
      [configKey as string]: item.count,
    });
  });

  // Convert map to array
  return Array.from(transformedMap.values());
}

/**
 * Transforms multiple datasets according to chart config keys
 */
export function transformMultipleDatasets(
  datasets: Record<string, DataItem[] | undefined>,
  chartConfig: ChartConfig,
): Record<string, any>[] {
  if (Object.keys(datasets).length === 0 || Object.keys(chartConfig).length === 0) {
    return [];
  }

  // Create a map to store all timestamps and their data
  const timestampMap = new Map<string, Record<string, any>>();

  // Process each dataset
  Object.entries(datasets).forEach(([datasetKey, dataItems]) => {
    // Skip if dataset doesn't exist in config or data is undefined
    if (!chartConfig[datasetKey as string] || !dataItems) return;

    dataItems.forEach(item => {
      if (!timestampMap.has(item.timestamp)) {
        // Initialize with timestamp and empty values for all config keys
        const newEntry: Record<string, any> = { timestamp: item.timestamp };
        Object.keys(chartConfig).forEach(key => {
          newEntry[key] = 0;
        });
        timestampMap.set(item.timestamp, newEntry);
      }

      // Update the specific key with count value
      const entry = timestampMap.get(item.timestamp)!;
      entry[datasetKey] = item.count;
    });
  });

  return Array.from(timestampMap.values());
}

export function mergeArrays<T extends any[][]>(...arrays: (T[number] | undefined)[]): T[number][number][] {
  // Filter out undefined arrays and flatten the result
  return arrays.filter((arr): arr is T[number] => arr !== undefined).flatMap(arr => arr);
}
