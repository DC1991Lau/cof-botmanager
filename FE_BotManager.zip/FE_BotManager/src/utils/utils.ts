import { NLUInboxItem } from '@/services/api/requests';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getBreadcrumbs({ pathname }: { pathname: string }) {
  const segments = pathname.split('/').filter(Boolean);

  return segments.map((segment, index) => ({
    label: segment.charAt(0).toUpperCase() + segment.slice(1),
    path: '/' + segments.slice(0, index + 1).join('/'),
  }));
}

export function transformPythonArray(pythonArray: string): Array<{ name: string; confidence: number }> {
  const cleanedStr = pythonArray.replace(/'/g, '"').replace(/\s+/g, '');

  try {
    return JSON.parse(cleanedStr);
  } catch (error) {
    console.error('Failed to parse array:', error);
    return [];
  }
}

export function groupSimilarNluMessages(messages: NLUInboxItem[]): (NLUInboxItem & { children: NLUInboxItem[] })[] {
  const messageGroups = messages.reduce(
    (groups, message) => {
      const key = JSON.stringify({
        project_id: message.project_id,
        text: message.text,
        predicted_intent: message.predicted_intent,
        intent_ranking: message.intent_ranking,
        confidence: message.confidence,
        annotated_intent: message.annotated_intent,
      });
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key]!.push(message);
      return groups;
    },
    {} as Record<string, NLUInboxItem[]>,
  );

  return Object.values(messageGroups)
    .filter(group => group.length > 0)
    .map(group => {
      const sortedGroup = group.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      const firstMessage = sortedGroup[0]!; // Non-null assertion since we filtered empty groups
      const remainingMessages = sortedGroup.slice(1);

      return {
        project_id: firstMessage.project_id,
        conversation_id: firstMessage.conversation_id,
        message_id: firstMessage.message_id,
        text: firstMessage.text,
        predicted_intent: firstMessage.predicted_intent,
        intent_ranking: firstMessage.intent_ranking,
        confidence: firstMessage.confidence,
        is_correct: firstMessage.is_correct,
        is_deleted: firstMessage.is_deleted,
        id: firstMessage.id,
        annotated_intent: firstMessage.annotated_intent,
        timestamp: firstMessage.timestamp,
        annotated_at: firstMessage.annotated_at,
        children: remainingMessages,
      } as NLUInboxItem & { children: NLUInboxItem[] };
    });
}
