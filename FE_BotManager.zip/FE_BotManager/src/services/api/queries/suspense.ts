// generated with @7nohe/openapi-react-query-codegen@1.6.0

import { UseQueryOptions, useSuspenseQuery } from '@tanstack/react-query';
import { ConversationsService, DefaultService, NluService, ProjectsService, StatsService, UsersService } from '../requests/services.gen';
import * as Common from './common';
/**
 * Users:Current User
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersCurrentUserUsersMeGetSuspense = <
  TData = Common.UsersServiceUsersCurrentUserUsersMeGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseUsersServiceUsersCurrentUserUsersMeGetKeyFn(queryKey),
    queryFn: () => UsersService.usersCurrentUserUsersMeGet() as TData,
    ...options,
  });
/**
 * Users:User
 * @param data The data for the request.
 * @param data.id
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersUserUsersIdGetSuspense = <
  TData = Common.UsersServiceUsersUserUsersIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    id,
  }: {
    id: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseUsersServiceUsersUserUsersIdGetKeyFn({ id }, queryKey),
    queryFn: () => UsersService.usersUserUsersIdGet({ id }) as TData,
    ...options,
  });
/**
 * Read Projects
 * @param data The data for the request.
 * @param data.name
 * @param data.description
 * @param data.urlConnection
 * @param data.port
 * @param data.queueName
 * @param data.active
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectsProjectsGetSuspense = <
  TData = Common.ProjectsServiceReadProjectsProjectsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    active,
    description,
    name,
    port,
    queueName,
    urlConnection,
  }: {
    active?: boolean;
    description?: string;
    name?: string;
    port?: number;
    queueName?: string;
    urlConnection?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectsProjectsGetKeyFn(
      { active, description, name, port, queueName, urlConnection },
      queryKey,
    ),
    queryFn: () => ProjectsService.readProjectsProjectsGet({ active, description, name, port, queueName, urlConnection }) as TData,
    ...options,
  });
/**
 * Read Projects
 * @returns User Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectsUsersGetSuspense = <
  TData = Common.ProjectsServiceReadProjectsUsersGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectsUsersGetKeyFn(queryKey),
    queryFn: () => ProjectsService.readProjectsUsersGet() as TData,
    ...options,
  });
/**
 * Read Project
 * @param data The data for the request.
 * @param data.projectId
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectProjectsProjectIdGetSuspense = <
  TData = Common.ProjectsServiceReadProjectProjectsProjectIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectProjectsProjectIdGetKeyFn({ projectId }, queryKey),
    queryFn: () => ProjectsService.readProjectProjectsProjectIdGet({ projectId }) as TData,
    ...options,
  });
/**
 * Read Project Users
 * @param data The data for the request.
 * @param data.projectId
 * @returns ProjectUsers Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectUsersProjectsProjectIdUsersGetSuspense = <
  TData = Common.ProjectsServiceReadProjectUsersProjectsProjectIdUsersGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKeyFn({ projectId }, queryKey),
    queryFn: () => ProjectsService.readProjectUsersProjectsProjectIdUsersGet({ projectId }) as TData,
    ...options,
  });
/**
 * Read Conversations
 * @param data The data for the request.
 * @param data.projectId
 * @param data.senderId
 * @param data.numberUserMessages
 * @param data.numberUserMessagesGte
 * @param data.latestInputChannel
 * @param data.latestEventTime
 * @param data.inTrainingData
 * @param data.evaluation
 * @param data.minimumActionConfidence
 * @param data.maximumActionConfidence
 * @param data.minimumIntentConfidence
 * @param data.maximumIntentConfidence
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationsConversationsGetSuspense = <
  TData = Common.ConversationsServiceReadConversationsConversationsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    evaluation,
    inTrainingData,
    latestEventTime,
    latestInputChannel,
    maximumActionConfidence,
    maximumIntentConfidence,
    minimumActionConfidence,
    minimumIntentConfidence,
    numberUserMessages,
    numberUserMessagesGte,
    projectId,
    senderId,
  }: {
    evaluation?: string;
    inTrainingData?: boolean;
    latestEventTime?: string;
    latestInputChannel?: string;
    maximumActionConfidence?: number;
    maximumIntentConfidence?: number;
    minimumActionConfidence?: number;
    minimumIntentConfidence?: number;
    numberUserMessages?: number;
    numberUserMessagesGte?: number;
    projectId: number;
    senderId?: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationsConversationsGetKeyFn(
      {
        evaluation,
        inTrainingData,
        latestEventTime,
        latestInputChannel,
        maximumActionConfidence,
        maximumIntentConfidence,
        minimumActionConfidence,
        minimumIntentConfidence,
        numberUserMessages,
        numberUserMessagesGte,
        projectId,
        senderId,
      },
      queryKey,
    ),
    queryFn: () =>
      ConversationsService.readConversationsConversationsGet({
        evaluation,
        inTrainingData,
        latestEventTime,
        latestInputChannel,
        maximumActionConfidence,
        maximumIntentConfidence,
        minimumActionConfidence,
        minimumIntentConfidence,
        numberUserMessages,
        numberUserMessagesGte,
        projectId,
        senderId,
      }) as TData,
    ...options,
  });
/**
 * Read Conversation
 * @param data The data for the request.
 * @param data.conversationId
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationConversationsConversationIdGetSuspense = <
  TData = Common.ConversationsServiceReadConversationConversationsConversationIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationConversationsConversationIdGetKeyFn({ conversationId }, queryKey),
    queryFn: () => ConversationsService.readConversationConversationsConversationIdGet({ conversationId }) as TData,
    ...options,
  });
/**
 * Read Conversation Detail
 * @param data The data for the request.
 * @param data.conversationId
 * @returns ConversationDetail Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationDetailConversationsConversationIdDetailGetSuspense = <
  TData = Common.ConversationsServiceReadConversationDetailConversationsConversationIdDetailGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKeyFn({ conversationId }, queryKey),
    queryFn: () => ConversationsService.readConversationDetailConversationsConversationIdDetailGet({ conversationId }) as TData,
    ...options,
  });
/**
 * Read Nlu Inbox Items
 * @param data The data for the request.
 * @param data.projectId
 * @param data.conversationId
 * @param data.messageId
 * @param data.text
 * @param data.predictedIntent
 * @param data.confidence
 * @param data.confidenceGte
 * @param data.confidenceLte
 * @param data.isCorrect
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceReadNluInboxItemsNluInboxGetSuspense = <
  TData = Common.NluServiceReadNluInboxItemsNluInboxGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    annotatedIntent,
    annotatedIntentIsnull,
    confidence,
    confidenceGte,
    confidenceLte,
    conversationId,
    isCorrect,
    messageId,
    predictedIntent,
    projectId,
    text,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    confidence?: number;
    confidenceGte?: number;
    confidenceLte?: number;
    conversationId?: number;
    isCorrect?: boolean;
    messageId?: string;
    predictedIntent?: string;
    projectId?: number;
    text?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadNluInboxItemsNluInboxGetKeyFn(
      {
        annotatedIntent,
        annotatedIntentIsnull,
        confidence,
        confidenceGte,
        confidenceLte,
        conversationId,
        isCorrect,
        messageId,
        predictedIntent,
        projectId,
        text,
      },
      queryKey,
    ),
    queryFn: () =>
      NluService.readNluInboxItemsNluInboxGet({
        annotatedIntent,
        annotatedIntentIsnull,
        confidence,
        confidenceGte,
        confidenceLte,
        conversationId,
        isCorrect,
        messageId,
        predictedIntent,
        projectId,
        text,
      }) as TData,
    ...options,
  });
/**
 * Read Nlu Inbox Item
 * @param data The data for the request.
 * @param data.itemId
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceReadNluInboxItemNluInboxItemIdGetSuspense = <
  TData = Common.NluServiceReadNluInboxItemNluInboxItemIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    itemId,
  }: {
    itemId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadNluInboxItemNluInboxItemIdGetKeyFn({ itemId }, queryKey),
    queryFn: () => NluService.readNluInboxItemNluInboxItemIdGet({ itemId }) as TData,
    ...options,
  });
/**
 * Read Annotations Data
 * @param data The data for the request.
 * @param data.projectId
 * @param data.text
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const useNluServiceReadAnnotationsDataAnnotationsDataGetSuspense = <
  TData = Common.NluServiceReadAnnotationsDataAnnotationsDataGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    annotatedIntent,
    annotatedIntentIsnull,
    projectId,
    text,
    timestampGte,
    timestampLt,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    projectId?: number;
    text?: string;
    timestampGte?: string;
    timestampLt?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadAnnotationsDataAnnotationsDataGetKeyFn(
      { annotatedIntent, annotatedIntentIsnull, projectId, text, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () =>
      NluService.readAnnotationsDataAnnotationsDataGet({
        annotatedIntent,
        annotatedIntentIsnull,
        projectId,
        text,
        timestampGte,
        timestampLt,
      }) as TData,
    ...options,
  });
/**
 * Get General Stats
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns GeneralStats Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetGeneralStatsStatsGeneralGetSuspense = <
  TData = Common.StatsServiceGetGeneralStatsStatsGeneralGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetGeneralStatsStatsGeneralGetKeyFn({ projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getGeneralStatsStatsGeneralGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Sessions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSessionsDistributionStatsSessionsDistributionGetSuspense = <
  TData = Common.StatsServiceGetSessionsDistributionStatsSessionsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getSessionsDistributionStatsSessionsDistributionGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Sessions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetSuspense = <
  TData = Common.StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getSessionsPerChannelStatsSessionsPerChannelGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Senders Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSendersDistributionStatsSendersDistributionGetSuspense = <
  TData = Common.StatsServiceGetSendersDistributionStatsSendersDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSendersDistributionStatsSendersDistributionGetKeyFn(
      { lastSeenGte, lastSeenLt, projectId },
      queryKey,
    ),
    queryFn: () => StatsService.getSendersDistributionStatsSendersDistributionGet({ lastSeenGte, lastSeenLt, projectId }) as TData,
    ...options,
  });
/**
 * Get Senders Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSendersPerChannelStatsSendersPerChannelGetSuspense = <
  TData = Common.StatsServiceGetSendersPerChannelStatsSendersPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKeyFn({ lastSeenGte, lastSeenLt, projectId }, queryKey),
    queryFn: () => StatsService.getSendersPerChannelStatsSendersPerChannelGet({ lastSeenGte, lastSeenLt, projectId }) as TData,
    ...options,
  });
/**
 * Get Actions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetActionsDistributionStatsActionsDistributionGetSuspense = <
  TData = Common.StatsServiceGetActionsDistributionStatsActionsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetActionsDistributionStatsActionsDistributionGetKeyFn(
      { name, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getActionsDistributionStatsActionsDistributionGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Actions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetActionsPerChannelStatsActionsPerChannelGetSuspense = <
  TData = Common.StatsServiceGetActionsPerChannelStatsActionsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKeyFn(
      { name, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getActionsPerChannelStatsActionsPerChannelGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Top Actions
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopAction Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetTopActionsStatsTopActionsGetSuspense = <
  TData = Common.StatsServiceGetTopActionsStatsTopActionsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetTopActionsStatsTopActionsGetKeyFn({ name, projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getTopActionsStatsTopActionsGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Intents Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetIntentsDistributionStatsIntentsDistributionGetSuspense = <
  TData = Common.StatsServiceGetIntentsDistributionStatsIntentsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKeyFn(
      { intent, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () =>
      StatsService.getIntentsDistributionStatsIntentsDistributionGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Intents Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetSuspense = <
  TData = Common.StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKeyFn(
      { intent, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getIntentsPerChannelStatsIntentsPerChannelGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Top Intents
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopIntent Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetTopIntentsStatsTopIntentsGetSuspense = <
  TData = Common.StatsServiceGetTopIntentsStatsTopIntentsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetTopIntentsStatsTopIntentsGetKeyFn({ intent, projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getTopIntentsStatsTopIntentsGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Response Time Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ResponseTimeDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetSuspense = <
  TData = Common.StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getResponseTimeDistributionStatsAvgResponseTimeGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Health
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const useDefaultServiceHealthHealthGetSuspense = <
  TData = Common.DefaultServiceHealthHealthGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useSuspenseQuery<TData, TError>({
    queryKey: Common.UseDefaultServiceHealthHealthGetKeyFn(queryKey),
    queryFn: () => DefaultService.healthHealthGet() as TData,
    ...options,
  });
