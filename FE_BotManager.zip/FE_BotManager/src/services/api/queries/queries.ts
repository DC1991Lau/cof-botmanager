// generated with @7nohe/openapi-react-query-codegen@1.6.0

import { UseMutationOptions, UseQueryOptions, useMutation, useQuery } from '@tanstack/react-query';
import {
  AuthService,
  ConversationsService,
  DefaultService,
  NluService,
  ProjectsService,
  StatsService,
  UsersService,
} from '../requests/services.gen';
import {
  AnnotationsDataCreate,
  AnnotationsDataUpdate,
  Body_auth_jwt_login_auth_jwt_login_post,
  Body_reset_forgot_password_auth_forgot_password_post,
  Body_reset_reset_password_auth_reset_password_post,
  Body_verify_request_token_auth_request_verify_token_post,
  Body_verify_verify_auth_verify_post,
  ConversationUpdate,
  NLUInboxItemBulkUpdate,
  NLUInboxItemCreate,
  NLUInboxItemUpdate,
  ProjectCreate,
  ProjectRoleCreate,
  ProjectUpdate,
  UserCreate,
  UserUpdate,
} from '../requests/types.gen';
import * as Common from './common';
/**
 * Users:Current User
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersCurrentUserUsersMeGet = <
  TData = Common.UsersServiceUsersCurrentUserUsersMeGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseUsersServiceUsersCurrentUserUsersMeGetKeyFn(queryKey),
    queryFn: () => UsersService.usersCurrentUserUsersMeGet() as TData,
    ...options,
  });
/**
 * Users:User
 * @param data The data for the request.
 * @param data.id
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersUserUsersIdGet = <
  TData = Common.UsersServiceUsersUserUsersIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    id,
  }: {
    id: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseUsersServiceUsersUserUsersIdGetKeyFn({ id }, queryKey),
    queryFn: () => UsersService.usersUserUsersIdGet({ id }) as TData,
    ...options,
  });
/**
 * Read Projects
 * @param data The data for the request.
 * @param data.name
 * @param data.description
 * @param data.urlConnection
 * @param data.port
 * @param data.queueName
 * @param data.active
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectsProjectsGet = <
  TData = Common.ProjectsServiceReadProjectsProjectsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    active,
    description,
    name,
    port,
    queueName,
    urlConnection,
  }: {
    active?: boolean;
    description?: string;
    name?: string;
    port?: number;
    queueName?: string;
    urlConnection?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectsProjectsGetKeyFn(
      { active, description, name, port, queueName, urlConnection },
      queryKey,
    ),
    queryFn: () => ProjectsService.readProjectsProjectsGet({ active, description, name, port, queueName, urlConnection }) as TData,
    ...options,
  });
/**
 * Read Projects
 * @returns User Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectsUsersGet = <
  TData = Common.ProjectsServiceReadProjectsUsersGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectsUsersGetKeyFn(queryKey),
    queryFn: () => ProjectsService.readProjectsUsersGet() as TData,
    ...options,
  });
/**
 * Read Project
 * @param data The data for the request.
 * @param data.projectId
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectProjectsProjectIdGet = <
  TData = Common.ProjectsServiceReadProjectProjectsProjectIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectProjectsProjectIdGetKeyFn({ projectId }, queryKey),
    queryFn: () => ProjectsService.readProjectProjectsProjectIdGet({ projectId }) as TData,
    ...options,
  });
/**
 * Read Project Users
 * @param data The data for the request.
 * @param data.projectId
 * @returns ProjectUsers Successful Response
 * @throws ApiError
 */
export const useProjectsServiceReadProjectUsersProjectsProjectIdUsersGet = <
  TData = Common.ProjectsServiceReadProjectUsersProjectsProjectIdUsersGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKeyFn({ projectId }, queryKey),
    queryFn: () => ProjectsService.readProjectUsersProjectsProjectIdUsersGet({ projectId }) as TData,
    ...options,
  });
/**
 * Read Conversations
 * @param data The data for the request.
 * @param data.projectId
 * @param data.senderId
 * @param data.numberUserMessages
 * @param data.numberUserMessagesGte
 * @param data.latestInputChannel
 * @param data.latestEventTime
 * @param data.inTrainingData
 * @param data.evaluation
 * @param data.minimumActionConfidence
 * @param data.maximumActionConfidence
 * @param data.minimumIntentConfidence
 * @param data.maximumIntentConfidence
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationsConversationsGet = <
  TData = Common.ConversationsServiceReadConversationsConversationsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    evaluation,
    inTrainingData,
    latestEventTime,
    latestInputChannel,
    maximumActionConfidence,
    maximumIntentConfidence,
    minimumActionConfidence,
    minimumIntentConfidence,
    numberUserMessages,
    numberUserMessagesGte,
    projectId,
    senderId,
  }: {
    evaluation?: string;
    inTrainingData?: boolean;
    latestEventTime?: string;
    latestInputChannel?: string;
    maximumActionConfidence?: number;
    maximumIntentConfidence?: number;
    minimumActionConfidence?: number;
    minimumIntentConfidence?: number;
    numberUserMessages?: number;
    numberUserMessagesGte?: number;
    projectId: number;
    senderId?: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationsConversationsGetKeyFn(
      {
        evaluation,
        inTrainingData,
        latestEventTime,
        latestInputChannel,
        maximumActionConfidence,
        maximumIntentConfidence,
        minimumActionConfidence,
        minimumIntentConfidence,
        numberUserMessages,
        numberUserMessagesGte,
        projectId,
        senderId,
      },
      queryKey,
    ),
    queryFn: () =>
      ConversationsService.readConversationsConversationsGet({
        evaluation,
        inTrainingData,
        latestEventTime,
        latestInputChannel,
        maximumActionConfidence,
        maximumIntentConfidence,
        minimumActionConfidence,
        minimumIntentConfidence,
        numberUserMessages,
        numberUserMessagesGte,
        projectId,
        senderId,
      }) as TData,
    ...options,
  });
/**
 * Read Conversation
 * @param data The data for the request.
 * @param data.conversationId
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationConversationsConversationIdGet = <
  TData = Common.ConversationsServiceReadConversationConversationsConversationIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationConversationsConversationIdGetKeyFn({ conversationId }, queryKey),
    queryFn: () => ConversationsService.readConversationConversationsConversationIdGet({ conversationId }) as TData,
    ...options,
  });
/**
 * Read Conversation Detail
 * @param data The data for the request.
 * @param data.conversationId
 * @returns ConversationDetail Successful Response
 * @throws ApiError
 */
export const useConversationsServiceReadConversationDetailConversationsConversationIdDetailGet = <
  TData = Common.ConversationsServiceReadConversationDetailConversationsConversationIdDetailGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKeyFn({ conversationId }, queryKey),
    queryFn: () => ConversationsService.readConversationDetailConversationsConversationIdDetailGet({ conversationId }) as TData,
    ...options,
  });
/**
 * Read Nlu Inbox Items
 * @param data The data for the request.
 * @param data.projectId
 * @param data.conversationId
 * @param data.messageId
 * @param data.text
 * @param data.predictedIntent
 * @param data.confidence
 * @param data.confidenceGte
 * @param data.confidenceLte
 * @param data.isCorrect
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceReadNluInboxItemsNluInboxGet = <
  TData = Common.NluServiceReadNluInboxItemsNluInboxGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    annotatedIntent,
    annotatedIntentIsnull,
    confidence,
    confidenceGte,
    confidenceLte,
    conversationId,
    isCorrect,
    messageId,
    predictedIntent,
    projectId,
    text,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    confidence?: number;
    confidenceGte?: number;
    confidenceLte?: number;
    conversationId?: number;
    isCorrect?: boolean;
    messageId?: string;
    predictedIntent?: string;
    projectId?: number;
    text?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadNluInboxItemsNluInboxGetKeyFn(
      {
        annotatedIntent,
        annotatedIntentIsnull,
        confidence,
        confidenceGte,
        confidenceLte,
        conversationId,
        isCorrect,
        messageId,
        predictedIntent,
        projectId,
        text,
      },
      queryKey,
    ),
    queryFn: () =>
      NluService.readNluInboxItemsNluInboxGet({
        annotatedIntent,
        annotatedIntentIsnull,
        confidence,
        confidenceGte,
        confidenceLte,
        conversationId,
        isCorrect,
        messageId,
        predictedIntent,
        projectId,
        text,
      }) as TData,
    ...options,
  });
/**
 * Read Nlu Inbox Item
 * @param data The data for the request.
 * @param data.itemId
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceReadNluInboxItemNluInboxItemIdGet = <
  TData = Common.NluServiceReadNluInboxItemNluInboxItemIdGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    itemId,
  }: {
    itemId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadNluInboxItemNluInboxItemIdGetKeyFn({ itemId }, queryKey),
    queryFn: () => NluService.readNluInboxItemNluInboxItemIdGet({ itemId }) as TData,
    ...options,
  });
/**
 * Read Annotations Data
 * @param data The data for the request.
 * @param data.projectId
 * @param data.text
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const useNluServiceReadAnnotationsDataAnnotationsDataGet = <
  TData = Common.NluServiceReadAnnotationsDataAnnotationsDataGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    annotatedIntent,
    annotatedIntentIsnull,
    projectId,
    text,
    timestampGte,
    timestampLt,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    projectId?: number;
    text?: string;
    timestampGte?: string;
    timestampLt?: string;
  } = {},
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseNluServiceReadAnnotationsDataAnnotationsDataGetKeyFn(
      { annotatedIntent, annotatedIntentIsnull, projectId, text, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () =>
      NluService.readAnnotationsDataAnnotationsDataGet({
        annotatedIntent,
        annotatedIntentIsnull,
        projectId,
        text,
        timestampGte,
        timestampLt,
      }) as TData,
    ...options,
  });
/**
 * Get General Stats
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns GeneralStats Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetGeneralStatsStatsGeneralGet = <
  TData = Common.StatsServiceGetGeneralStatsStatsGeneralGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetGeneralStatsStatsGeneralGetKeyFn({ projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getGeneralStatsStatsGeneralGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Sessions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSessionsDistributionStatsSessionsDistributionGet = <
  TData = Common.StatsServiceGetSessionsDistributionStatsSessionsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getSessionsDistributionStatsSessionsDistributionGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Sessions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGet = <
  TData = Common.StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getSessionsPerChannelStatsSessionsPerChannelGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Senders Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSendersDistributionStatsSendersDistributionGet = <
  TData = Common.StatsServiceGetSendersDistributionStatsSendersDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSendersDistributionStatsSendersDistributionGetKeyFn(
      { lastSeenGte, lastSeenLt, projectId },
      queryKey,
    ),
    queryFn: () => StatsService.getSendersDistributionStatsSendersDistributionGet({ lastSeenGte, lastSeenLt, projectId }) as TData,
    ...options,
  });
/**
 * Get Senders Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetSendersPerChannelStatsSendersPerChannelGet = <
  TData = Common.StatsServiceGetSendersPerChannelStatsSendersPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKeyFn({ lastSeenGte, lastSeenLt, projectId }, queryKey),
    queryFn: () => StatsService.getSendersPerChannelStatsSendersPerChannelGet({ lastSeenGte, lastSeenLt, projectId }) as TData,
    ...options,
  });
/**
 * Get Actions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetActionsDistributionStatsActionsDistributionGet = <
  TData = Common.StatsServiceGetActionsDistributionStatsActionsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetActionsDistributionStatsActionsDistributionGetKeyFn(
      { name, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getActionsDistributionStatsActionsDistributionGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Actions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetActionsPerChannelStatsActionsPerChannelGet = <
  TData = Common.StatsServiceGetActionsPerChannelStatsActionsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKeyFn(
      { name, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getActionsPerChannelStatsActionsPerChannelGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Top Actions
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopAction Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetTopActionsStatsTopActionsGet = <
  TData = Common.StatsServiceGetTopActionsStatsTopActionsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetTopActionsStatsTopActionsGetKeyFn({ name, projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getTopActionsStatsTopActionsGet({ name, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Intents Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetIntentsDistributionStatsIntentsDistributionGet = <
  TData = Common.StatsServiceGetIntentsDistributionStatsIntentsDistributionGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKeyFn(
      { intent, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () =>
      StatsService.getIntentsDistributionStatsIntentsDistributionGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Intents Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsPerChannel Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGet = <
  TData = Common.StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKeyFn(
      { intent, projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getIntentsPerChannelStatsIntentsPerChannelGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Top Intents
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopIntent Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetTopIntentsStatsTopIntentsGet = <
  TData = Common.StatsServiceGetTopIntentsStatsTopIntentsGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetTopIntentsStatsTopIntentsGetKeyFn({ intent, projectId, timestampGte, timestampLt }, queryKey),
    queryFn: () => StatsService.getTopIntentsStatsTopIntentsGet({ intent, projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Get Response Time Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ResponseTimeDistribution Successful Response
 * @throws ApiError
 */
export const useStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGet = <
  TData = Common.StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKeyFn(
      { projectId, timestampGte, timestampLt },
      queryKey,
    ),
    queryFn: () => StatsService.getResponseTimeDistributionStatsAvgResponseTimeGet({ projectId, timestampGte, timestampLt }) as TData,
    ...options,
  });
/**
 * Health
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const useDefaultServiceHealthHealthGet = <
  TData = Common.DefaultServiceHealthHealthGetDefaultResponse,
  TError = unknown,
  TQueryKey extends Array<unknown> = unknown[],
>(
  queryKey?: TQueryKey,
  options?: Omit<UseQueryOptions<TData, TError>, 'queryKey' | 'queryFn'>,
) =>
  useQuery<TData, TError>({
    queryKey: Common.UseDefaultServiceHealthHealthGetKeyFn(queryKey),
    queryFn: () => DefaultService.healthHealthGet() as TData,
    ...options,
  });
/**
 * Auth:Jwt.Login
 * @param data The data for the request.
 * @param data.formData
 * @returns unknown Successful Response
 * @returns void No Content
 * @throws ApiError
 */
export const useAuthServiceAuthJwtLoginAuthJwtLoginPost = <
  TData = Common.AuthServiceAuthJwtLoginAuthJwtLoginPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        formData: Body_auth_jwt_login_auth_jwt_login_post;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      formData: Body_auth_jwt_login_auth_jwt_login_post;
    },
    TContext
  >({ mutationFn: ({ formData }) => AuthService.authJwtLoginAuthJwtLoginPost({ formData }) as unknown as Promise<TData>, ...options });
/**
 * Auth:Jwt.Logout
 * @returns unknown Successful Response
 * @returns void No Content
 * @throws ApiError
 */
export const useAuthServiceAuthJwtLogoutAuthJwtLogoutPost = <
  TData = Common.AuthServiceAuthJwtLogoutAuthJwtLogoutPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<UseMutationOptions<TData, TError, void, TContext>, 'mutationFn'>,
) =>
  useMutation<TData, TError, void, TContext>({
    mutationFn: () => AuthService.authJwtLogoutAuthJwtLogoutPost() as unknown as Promise<TData>,
    ...options,
  });
/**
 * Register:Register
 * @param data The data for the request.
 * @param data.requestBody
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useAuthServiceRegisterRegisterAuthRegisterPost = <
  TData = Common.AuthServiceRegisterRegisterAuthRegisterPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: UserCreate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: UserCreate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => AuthService.registerRegisterAuthRegisterPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Reset:Forgot Password
 * @param data The data for the request.
 * @param data.requestBody
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const useAuthServiceResetForgotPasswordAuthForgotPasswordPost = <
  TData = Common.AuthServiceResetForgotPasswordAuthForgotPasswordPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: Body_reset_forgot_password_auth_forgot_password_post;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: Body_reset_forgot_password_auth_forgot_password_post;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => AuthService.resetForgotPasswordAuthForgotPasswordPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Reset:Reset Password
 * @param data The data for the request.
 * @param data.requestBody
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const useAuthServiceResetResetPasswordAuthResetPasswordPost = <
  TData = Common.AuthServiceResetResetPasswordAuthResetPasswordPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: Body_reset_reset_password_auth_reset_password_post;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: Body_reset_reset_password_auth_reset_password_post;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => AuthService.resetResetPasswordAuthResetPasswordPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Verify:Request-Token
 * @param data The data for the request.
 * @param data.requestBody
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const useAuthServiceVerifyRequestTokenAuthRequestVerifyTokenPost = <
  TData = Common.AuthServiceVerifyRequestTokenAuthRequestVerifyTokenPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: Body_verify_request_token_auth_request_verify_token_post;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: Body_verify_request_token_auth_request_verify_token_post;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => AuthService.verifyRequestTokenAuthRequestVerifyTokenPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Verify:Verify
 * @param data The data for the request.
 * @param data.requestBody
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useAuthServiceVerifyVerifyAuthVerifyPost = <
  TData = Common.AuthServiceVerifyVerifyAuthVerifyPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: Body_verify_verify_auth_verify_post;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: Body_verify_verify_auth_verify_post;
    },
    TContext
  >({ mutationFn: ({ requestBody }) => AuthService.verifyVerifyAuthVerifyPost({ requestBody }) as unknown as Promise<TData>, ...options });
/**
 * Create Project
 * @param data The data for the request.
 * @param data.requestBody
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceCreateProjectProjectsPost = <
  TData = Common.ProjectsServiceCreateProjectProjectsPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: ProjectCreate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: ProjectCreate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => ProjectsService.createProjectProjectsPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Add User To Project
 * @param data The data for the request.
 * @param data.projectId
 * @param data.requestBody
 * @returns ProjectRole Successful Response
 * @throws ApiError
 */
export const useProjectsServiceAddUserToProjectProjectsProjectIdUsersPost = <
  TData = Common.ProjectsServiceAddUserToProjectProjectsProjectIdUsersPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        projectId: number;
        requestBody: ProjectRoleCreate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      projectId: number;
      requestBody: ProjectRoleCreate;
    },
    TContext
  >({
    mutationFn: ({ projectId, requestBody }) =>
      ProjectsService.addUserToProjectProjectsProjectIdUsersPost({ projectId, requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Create Nlu Inbox Item
 * @param data The data for the request.
 * @param data.requestBody
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceCreateNluInboxItemNluInboxPost = <
  TData = Common.NluServiceCreateNluInboxItemNluInboxPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: NLUInboxItemCreate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: NLUInboxItemCreate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => NluService.createNluInboxItemNluInboxPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Bulk Update Nlu Inbox Items
 * @param data The data for the request.
 * @param data.requestBody
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceBulkUpdateNluInboxItemsNluInboxBulkUpdatePost = <
  TData = Common.NluServiceBulkUpdateNluInboxItemsNluInboxBulkUpdatePostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: NLUInboxItemBulkUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: NLUInboxItemBulkUpdate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => NluService.bulkUpdateNluInboxItemsNluInboxBulkUpdatePost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Create Annotations Data
 * @param data The data for the request.
 * @param data.requestBody
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const useNluServiceCreateAnnotationsDataAnnotationsDataPost = <
  TData = Common.NluServiceCreateAnnotationsDataAnnotationsDataPostMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: AnnotationsDataCreate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: AnnotationsDataCreate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => NluService.createAnnotationsDataAnnotationsDataPost({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Update Project
 * @param data The data for the request.
 * @param data.projectId
 * @param data.requestBody
 * @returns Project Successful Response
 * @throws ApiError
 */
export const useProjectsServiceUpdateProjectProjectsProjectIdPut = <
  TData = Common.ProjectsServiceUpdateProjectProjectsProjectIdPutMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        projectId: number;
        requestBody: ProjectUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      projectId: number;
      requestBody: ProjectUpdate;
    },
    TContext
  >({
    mutationFn: ({ projectId, requestBody }) =>
      ProjectsService.updateProjectProjectsProjectIdPut({ projectId, requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Update User Role In Project
 * @param data The data for the request.
 * @param data.projectId
 * @param data.userId
 * @param data.newRole
 * @returns ProjectRole Successful Response
 * @throws ApiError
 */
export const useProjectsServiceUpdateUserRoleInProjectProjectsProjectIdUsersUserIdPut = <
  TData = Common.ProjectsServiceUpdateUserRoleInProjectProjectsProjectIdUsersUserIdPutMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        newRole: string;
        projectId: number;
        userId: number;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      newRole: string;
      projectId: number;
      userId: number;
    },
    TContext
  >({
    mutationFn: ({ newRole, projectId, userId }) =>
      ProjectsService.updateUserRoleInProjectProjectsProjectIdUsersUserIdPut({ newRole, projectId, userId }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Update Conversation Status
 * @param data The data for the request.
 * @param data.conversationId
 * @param data.requestBody
 * @returns ConversationBase Successful Response
 * @throws ApiError
 */
export const useConversationsServiceUpdateConversationStatusConversationsConversationIdPut = <
  TData = Common.ConversationsServiceUpdateConversationStatusConversationsConversationIdPutMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        conversationId: number;
        requestBody: ConversationUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      conversationId: number;
      requestBody: ConversationUpdate;
    },
    TContext
  >({
    mutationFn: ({ conversationId, requestBody }) =>
      ConversationsService.updateConversationStatusConversationsConversationIdPut({
        conversationId,
        requestBody,
      }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Update Nlu Inbox Item
 * @param data The data for the request.
 * @param data.itemId
 * @param data.requestBody
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceUpdateNluInboxItemNluInboxItemIdPut = <
  TData = Common.NluServiceUpdateNluInboxItemNluInboxItemIdPutMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        itemId: number;
        requestBody: NLUInboxItemUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      itemId: number;
      requestBody: NLUInboxItemUpdate;
    },
    TContext
  >({
    mutationFn: ({ itemId, requestBody }) =>
      NluService.updateNluInboxItemNluInboxItemIdPut({ itemId, requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Update Annotations Data
 * @param data The data for the request.
 * @param data.itemId
 * @param data.requestBody
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const useNluServiceUpdateAnnotationsDataAnnotationsDataItemIdPut = <
  TData = Common.NluServiceUpdateAnnotationsDataAnnotationsDataItemIdPutMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        itemId: number;
        requestBody: AnnotationsDataUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      itemId: number;
      requestBody: AnnotationsDataUpdate;
    },
    TContext
  >({
    mutationFn: ({ itemId, requestBody }) =>
      NluService.updateAnnotationsDataAnnotationsDataItemIdPut({ itemId, requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Users:Patch Current User
 * @param data The data for the request.
 * @param data.requestBody
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersPatchCurrentUserUsersMePatch = <
  TData = Common.UsersServiceUsersPatchCurrentUserUsersMePatchMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        requestBody: UserUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      requestBody: UserUpdate;
    },
    TContext
  >({
    mutationFn: ({ requestBody }) => UsersService.usersPatchCurrentUserUsersMePatch({ requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Users:Patch User
 * @param data The data for the request.
 * @param data.id
 * @param data.requestBody
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersPatchUserUsersIdPatch = <
  TData = Common.UsersServiceUsersPatchUserUsersIdPatchMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        id: string;
        requestBody: UserUpdate;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      id: string;
      requestBody: UserUpdate;
    },
    TContext
  >({
    mutationFn: ({ id, requestBody }) => UsersService.usersPatchUserUsersIdPatch({ id, requestBody }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Users:Delete User
 * @param data The data for the request.
 * @param data.id
 * @returns void Successful Response
 * @throws ApiError
 */
export const useUsersServiceUsersDeleteUserUsersIdDelete = <
  TData = Common.UsersServiceUsersDeleteUserUsersIdDeleteMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        id: string;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      id: string;
    },
    TContext
  >({ mutationFn: ({ id }) => UsersService.usersDeleteUserUsersIdDelete({ id }) as unknown as Promise<TData>, ...options });
/**
 * Delete Project
 * @param data The data for the request.
 * @param data.projectId
 * @returns boolean Successful Response
 * @throws ApiError
 */
export const useProjectsServiceDeleteProjectProjectsProjectIdDelete = <
  TData = Common.ProjectsServiceDeleteProjectProjectsProjectIdDeleteMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        projectId: number;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      projectId: number;
    },
    TContext
  >({
    mutationFn: ({ projectId }) => ProjectsService.deleteProjectProjectsProjectIdDelete({ projectId }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Remove User From Project
 * @param data The data for the request.
 * @param data.projectId
 * @param data.userId
 * @returns boolean Successful Response
 * @throws ApiError
 */
export const useProjectsServiceRemoveUserFromProjectProjectsProjectIdUsersUserIdDelete = <
  TData = Common.ProjectsServiceRemoveUserFromProjectProjectsProjectIdUsersUserIdDeleteMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        projectId: number;
        userId: number;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      projectId: number;
      userId: number;
    },
    TContext
  >({
    mutationFn: ({ projectId, userId }) =>
      ProjectsService.removeUserFromProjectProjectsProjectIdUsersUserIdDelete({ projectId, userId }) as unknown as Promise<TData>,
    ...options,
  });
/**
 * Delete Nlu Inbox Item
 * @param data The data for the request.
 * @param data.itemId
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const useNluServiceDeleteNluInboxItemNluInboxItemIdDelete = <
  TData = Common.NluServiceDeleteNluInboxItemNluInboxItemIdDeleteMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        itemId: number;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      itemId: number;
    },
    TContext
  >({ mutationFn: ({ itemId }) => NluService.deleteNluInboxItemNluInboxItemIdDelete({ itemId }) as unknown as Promise<TData>, ...options });
/**
 * Delete Annotations Data
 * @param data The data for the request.
 * @param data.itemId
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const useNluServiceDeleteAnnotationsDataAnnotationsDataItemIdDelete = <
  TData = Common.NluServiceDeleteAnnotationsDataAnnotationsDataItemIdDeleteMutationResult,
  TError = unknown,
  TContext = unknown,
>(
  options?: Omit<
    UseMutationOptions<
      TData,
      TError,
      {
        itemId: number;
      },
      TContext
    >,
    'mutationFn'
  >,
) =>
  useMutation<
    TData,
    TError,
    {
      itemId: number;
    },
    TContext
  >({
    mutationFn: ({ itemId }) => NluService.deleteAnnotationsDataAnnotationsDataItemIdDelete({ itemId }) as unknown as Promise<TData>,
    ...options,
  });
