// generated with @7nohe/openapi-react-query-codegen@1.6.0

import { UseQueryResult } from '@tanstack/react-query';
import {
  AuthService,
  ConversationsService,
  DefaultService,
  NluService,
  ProjectsService,
  StatsService,
  UsersService,
} from '../requests/services.gen';
export type UsersServiceUsersCurrentUserUsersMeGetDefaultResponse = Awaited<ReturnType<typeof UsersService.usersCurrentUserUsersMeGet>>;
export type UsersServiceUsersCurrentUserUsersMeGetQueryResult<
  TData = UsersServiceUsersCurrentUserUsersMeGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useUsersServiceUsersCurrentUserUsersMeGetKey = 'UsersServiceUsersCurrentUserUsersMeGet';
export const UseUsersServiceUsersCurrentUserUsersMeGetKeyFn = (queryKey?: Array<unknown>) => [
  useUsersServiceUsersCurrentUserUsersMeGetKey,
  ...(queryKey ?? []),
];
export type UsersServiceUsersUserUsersIdGetDefaultResponse = Awaited<ReturnType<typeof UsersService.usersUserUsersIdGet>>;
export type UsersServiceUsersUserUsersIdGetQueryResult<
  TData = UsersServiceUsersUserUsersIdGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useUsersServiceUsersUserUsersIdGetKey = 'UsersServiceUsersUserUsersIdGet';
export const UseUsersServiceUsersUserUsersIdGetKeyFn = (
  {
    id,
  }: {
    id: string;
  },
  queryKey?: Array<unknown>,
) => [useUsersServiceUsersUserUsersIdGetKey, ...(queryKey ?? [{ id }])];
export type ProjectsServiceReadProjectsProjectsGetDefaultResponse = Awaited<ReturnType<typeof ProjectsService.readProjectsProjectsGet>>;
export type ProjectsServiceReadProjectsProjectsGetQueryResult<
  TData = ProjectsServiceReadProjectsProjectsGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useProjectsServiceReadProjectsProjectsGetKey = 'ProjectsServiceReadProjectsProjectsGet';
export const UseProjectsServiceReadProjectsProjectsGetKeyFn = (
  {
    active,
    description,
    name,
    port,
    queueName,
    urlConnection,
  }: {
    active?: boolean;
    description?: string;
    name?: string;
    port?: number;
    queueName?: string;
    urlConnection?: string;
  } = {},
  queryKey?: Array<unknown>,
) => [useProjectsServiceReadProjectsProjectsGetKey, ...(queryKey ?? [{ active, description, name, port, queueName, urlConnection }])];
export type ProjectsServiceReadProjectsUsersGetDefaultResponse = Awaited<ReturnType<typeof ProjectsService.readProjectsUsersGet>>;
export type ProjectsServiceReadProjectsUsersGetQueryResult<
  TData = ProjectsServiceReadProjectsUsersGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useProjectsServiceReadProjectsUsersGetKey = 'ProjectsServiceReadProjectsUsersGet';
export const UseProjectsServiceReadProjectsUsersGetKeyFn = (queryKey?: Array<unknown>) => [
  useProjectsServiceReadProjectsUsersGetKey,
  ...(queryKey ?? []),
];
export type ProjectsServiceReadProjectProjectsProjectIdGetDefaultResponse = Awaited<
  ReturnType<typeof ProjectsService.readProjectProjectsProjectIdGet>
>;
export type ProjectsServiceReadProjectProjectsProjectIdGetQueryResult<
  TData = ProjectsServiceReadProjectProjectsProjectIdGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useProjectsServiceReadProjectProjectsProjectIdGetKey = 'ProjectsServiceReadProjectProjectsProjectIdGet';
export const UseProjectsServiceReadProjectProjectsProjectIdGetKeyFn = (
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: Array<unknown>,
) => [useProjectsServiceReadProjectProjectsProjectIdGetKey, ...(queryKey ?? [{ projectId }])];
export type ProjectsServiceReadProjectUsersProjectsProjectIdUsersGetDefaultResponse = Awaited<
  ReturnType<typeof ProjectsService.readProjectUsersProjectsProjectIdUsersGet>
>;
export type ProjectsServiceReadProjectUsersProjectsProjectIdUsersGetQueryResult<
  TData = ProjectsServiceReadProjectUsersProjectsProjectIdUsersGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKey = 'ProjectsServiceReadProjectUsersProjectsProjectIdUsersGet';
export const UseProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKeyFn = (
  {
    projectId,
  }: {
    projectId: number;
  },
  queryKey?: Array<unknown>,
) => [useProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKey, ...(queryKey ?? [{ projectId }])];
export type ConversationsServiceReadConversationsConversationsGetDefaultResponse = Awaited<
  ReturnType<typeof ConversationsService.readConversationsConversationsGet>
>;
export type ConversationsServiceReadConversationsConversationsGetQueryResult<
  TData = ConversationsServiceReadConversationsConversationsGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useConversationsServiceReadConversationsConversationsGetKey = 'ConversationsServiceReadConversationsConversationsGet';
export const UseConversationsServiceReadConversationsConversationsGetKeyFn = (
  {
    evaluation,
    inTrainingData,
    latestEventTime,
    latestInputChannel,
    maximumActionConfidence,
    maximumIntentConfidence,
    minimumActionConfidence,
    minimumIntentConfidence,
    numberUserMessages,
    numberUserMessagesGte,
    projectId,
    senderId,
  }: {
    evaluation?: string;
    inTrainingData?: boolean;
    latestEventTime?: string;
    latestInputChannel?: string;
    maximumActionConfidence?: number;
    maximumIntentConfidence?: number;
    minimumActionConfidence?: number;
    minimumIntentConfidence?: number;
    numberUserMessages?: number;
    numberUserMessagesGte?: number;
    projectId: number;
    senderId?: number;
  },
  queryKey?: Array<unknown>,
) => [
  useConversationsServiceReadConversationsConversationsGetKey,
  ...(queryKey ?? [
    {
      evaluation,
      inTrainingData,
      latestEventTime,
      latestInputChannel,
      maximumActionConfidence,
      maximumIntentConfidence,
      minimumActionConfidence,
      minimumIntentConfidence,
      numberUserMessages,
      numberUserMessagesGte,
      projectId,
      senderId,
    },
  ]),
];
export type ConversationsServiceReadConversationConversationsConversationIdGetDefaultResponse = Awaited<
  ReturnType<typeof ConversationsService.readConversationConversationsConversationIdGet>
>;
export type ConversationsServiceReadConversationConversationsConversationIdGetQueryResult<
  TData = ConversationsServiceReadConversationConversationsConversationIdGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useConversationsServiceReadConversationConversationsConversationIdGetKey =
  'ConversationsServiceReadConversationConversationsConversationIdGet';
export const UseConversationsServiceReadConversationConversationsConversationIdGetKeyFn = (
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: Array<unknown>,
) => [useConversationsServiceReadConversationConversationsConversationIdGetKey, ...(queryKey ?? [{ conversationId }])];
export type ConversationsServiceReadConversationDetailConversationsConversationIdDetailGetDefaultResponse = Awaited<
  ReturnType<typeof ConversationsService.readConversationDetailConversationsConversationIdDetailGet>
>;
export type ConversationsServiceReadConversationDetailConversationsConversationIdDetailGetQueryResult<
  TData = ConversationsServiceReadConversationDetailConversationsConversationIdDetailGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKey =
  'ConversationsServiceReadConversationDetailConversationsConversationIdDetailGet';
export const UseConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKeyFn = (
  {
    conversationId,
  }: {
    conversationId: number;
  },
  queryKey?: Array<unknown>,
) => [useConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKey, ...(queryKey ?? [{ conversationId }])];
export type NluServiceReadNluInboxItemsNluInboxGetDefaultResponse = Awaited<ReturnType<typeof NluService.readNluInboxItemsNluInboxGet>>;
export type NluServiceReadNluInboxItemsNluInboxGetQueryResult<
  TData = NluServiceReadNluInboxItemsNluInboxGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useNluServiceReadNluInboxItemsNluInboxGetKey = 'NluServiceReadNluInboxItemsNluInboxGet';
export const UseNluServiceReadNluInboxItemsNluInboxGetKeyFn = (
  {
    annotatedIntent,
    annotatedIntentIsnull,
    confidence,
    confidenceGte,
    confidenceLte,
    conversationId,
    isCorrect,
    messageId,
    predictedIntent,
    projectId,
    text,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    confidence?: number;
    confidenceGte?: number;
    confidenceLte?: number;
    conversationId?: number;
    isCorrect?: boolean;
    messageId?: string;
    predictedIntent?: string;
    projectId?: number;
    text?: string;
  } = {},
  queryKey?: Array<unknown>,
) => [
  useNluServiceReadNluInboxItemsNluInboxGetKey,
  ...(queryKey ?? [
    {
      annotatedIntent,
      annotatedIntentIsnull,
      confidence,
      confidenceGte,
      confidenceLte,
      conversationId,
      isCorrect,
      messageId,
      predictedIntent,
      projectId,
      text,
    },
  ]),
];
export type NluServiceReadNluInboxItemNluInboxItemIdGetDefaultResponse = Awaited<
  ReturnType<typeof NluService.readNluInboxItemNluInboxItemIdGet>
>;
export type NluServiceReadNluInboxItemNluInboxItemIdGetQueryResult<
  TData = NluServiceReadNluInboxItemNluInboxItemIdGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useNluServiceReadNluInboxItemNluInboxItemIdGetKey = 'NluServiceReadNluInboxItemNluInboxItemIdGet';
export const UseNluServiceReadNluInboxItemNluInboxItemIdGetKeyFn = (
  {
    itemId,
  }: {
    itemId: number;
  },
  queryKey?: Array<unknown>,
) => [useNluServiceReadNluInboxItemNluInboxItemIdGetKey, ...(queryKey ?? [{ itemId }])];
export type NluServiceReadAnnotationsDataAnnotationsDataGetDefaultResponse = Awaited<
  ReturnType<typeof NluService.readAnnotationsDataAnnotationsDataGet>
>;
export type NluServiceReadAnnotationsDataAnnotationsDataGetQueryResult<
  TData = NluServiceReadAnnotationsDataAnnotationsDataGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useNluServiceReadAnnotationsDataAnnotationsDataGetKey = 'NluServiceReadAnnotationsDataAnnotationsDataGet';
export const UseNluServiceReadAnnotationsDataAnnotationsDataGetKeyFn = (
  {
    annotatedIntent,
    annotatedIntentIsnull,
    projectId,
    text,
    timestampGte,
    timestampLt,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    projectId?: number;
    text?: string;
    timestampGte?: string;
    timestampLt?: string;
  } = {},
  queryKey?: Array<unknown>,
) => [
  useNluServiceReadAnnotationsDataAnnotationsDataGetKey,
  ...(queryKey ?? [{ annotatedIntent, annotatedIntentIsnull, projectId, text, timestampGte, timestampLt }]),
];
export type StatsServiceGetGeneralStatsStatsGeneralGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getGeneralStatsStatsGeneralGet>
>;
export type StatsServiceGetGeneralStatsStatsGeneralGetQueryResult<
  TData = StatsServiceGetGeneralStatsStatsGeneralGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetGeneralStatsStatsGeneralGetKey = 'StatsServiceGetGeneralStatsStatsGeneralGet';
export const UseStatsServiceGetGeneralStatsStatsGeneralGetKeyFn = (
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetGeneralStatsStatsGeneralGetKey, ...(queryKey ?? [{ projectId, timestampGte, timestampLt }])];
export type StatsServiceGetSessionsDistributionStatsSessionsDistributionGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getSessionsDistributionStatsSessionsDistributionGet>
>;
export type StatsServiceGetSessionsDistributionStatsSessionsDistributionGetQueryResult<
  TData = StatsServiceGetSessionsDistributionStatsSessionsDistributionGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKey =
  'StatsServiceGetSessionsDistributionStatsSessionsDistributionGet';
export const UseStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKeyFn = (
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKey, ...(queryKey ?? [{ projectId, timestampGte, timestampLt }])];
export type StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getSessionsPerChannelStatsSessionsPerChannelGet>
>;
export type StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetQueryResult<
  TData = StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKey =
  'StatsServiceGetSessionsPerChannelStatsSessionsPerChannelGet';
export const UseStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKeyFn = (
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKey, ...(queryKey ?? [{ projectId, timestampGte, timestampLt }])];
export type StatsServiceGetSendersDistributionStatsSendersDistributionGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getSendersDistributionStatsSendersDistributionGet>
>;
export type StatsServiceGetSendersDistributionStatsSendersDistributionGetQueryResult<
  TData = StatsServiceGetSendersDistributionStatsSendersDistributionGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetSendersDistributionStatsSendersDistributionGetKey =
  'StatsServiceGetSendersDistributionStatsSendersDistributionGet';
export const UseStatsServiceGetSendersDistributionStatsSendersDistributionGetKeyFn = (
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetSendersDistributionStatsSendersDistributionGetKey, ...(queryKey ?? [{ lastSeenGte, lastSeenLt, projectId }])];
export type StatsServiceGetSendersPerChannelStatsSendersPerChannelGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getSendersPerChannelStatsSendersPerChannelGet>
>;
export type StatsServiceGetSendersPerChannelStatsSendersPerChannelGetQueryResult<
  TData = StatsServiceGetSendersPerChannelStatsSendersPerChannelGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKey = 'StatsServiceGetSendersPerChannelStatsSendersPerChannelGet';
export const UseStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKeyFn = (
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKey, ...(queryKey ?? [{ lastSeenGte, lastSeenLt, projectId }])];
export type StatsServiceGetActionsDistributionStatsActionsDistributionGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getActionsDistributionStatsActionsDistributionGet>
>;
export type StatsServiceGetActionsDistributionStatsActionsDistributionGetQueryResult<
  TData = StatsServiceGetActionsDistributionStatsActionsDistributionGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetActionsDistributionStatsActionsDistributionGetKey =
  'StatsServiceGetActionsDistributionStatsActionsDistributionGet';
export const UseStatsServiceGetActionsDistributionStatsActionsDistributionGetKeyFn = (
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [
  useStatsServiceGetActionsDistributionStatsActionsDistributionGetKey,
  ...(queryKey ?? [{ name, projectId, timestampGte, timestampLt }]),
];
export type StatsServiceGetActionsPerChannelStatsActionsPerChannelGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getActionsPerChannelStatsActionsPerChannelGet>
>;
export type StatsServiceGetActionsPerChannelStatsActionsPerChannelGetQueryResult<
  TData = StatsServiceGetActionsPerChannelStatsActionsPerChannelGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKey = 'StatsServiceGetActionsPerChannelStatsActionsPerChannelGet';
export const UseStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKeyFn = (
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKey, ...(queryKey ?? [{ name, projectId, timestampGte, timestampLt }])];
export type StatsServiceGetTopActionsStatsTopActionsGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getTopActionsStatsTopActionsGet>
>;
export type StatsServiceGetTopActionsStatsTopActionsGetQueryResult<
  TData = StatsServiceGetTopActionsStatsTopActionsGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetTopActionsStatsTopActionsGetKey = 'StatsServiceGetTopActionsStatsTopActionsGet';
export const UseStatsServiceGetTopActionsStatsTopActionsGetKeyFn = (
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetTopActionsStatsTopActionsGetKey, ...(queryKey ?? [{ name, projectId, timestampGte, timestampLt }])];
export type StatsServiceGetIntentsDistributionStatsIntentsDistributionGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getIntentsDistributionStatsIntentsDistributionGet>
>;
export type StatsServiceGetIntentsDistributionStatsIntentsDistributionGetQueryResult<
  TData = StatsServiceGetIntentsDistributionStatsIntentsDistributionGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKey =
  'StatsServiceGetIntentsDistributionStatsIntentsDistributionGet';
export const UseStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKeyFn = (
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [
  useStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKey,
  ...(queryKey ?? [{ intent, projectId, timestampGte, timestampLt }]),
];
export type StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getIntentsPerChannelStatsIntentsPerChannelGet>
>;
export type StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetQueryResult<
  TData = StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKey = 'StatsServiceGetIntentsPerChannelStatsIntentsPerChannelGet';
export const UseStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKeyFn = (
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKey, ...(queryKey ?? [{ intent, projectId, timestampGte, timestampLt }])];
export type StatsServiceGetTopIntentsStatsTopIntentsGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getTopIntentsStatsTopIntentsGet>
>;
export type StatsServiceGetTopIntentsStatsTopIntentsGetQueryResult<
  TData = StatsServiceGetTopIntentsStatsTopIntentsGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetTopIntentsStatsTopIntentsGetKey = 'StatsServiceGetTopIntentsStatsTopIntentsGet';
export const UseStatsServiceGetTopIntentsStatsTopIntentsGetKeyFn = (
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetTopIntentsStatsTopIntentsGetKey, ...(queryKey ?? [{ intent, projectId, timestampGte, timestampLt }])];
export type StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetDefaultResponse = Awaited<
  ReturnType<typeof StatsService.getResponseTimeDistributionStatsAvgResponseTimeGet>
>;
export type StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetQueryResult<
  TData = StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKey =
  'StatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGet';
export const UseStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKeyFn = (
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
  queryKey?: Array<unknown>,
) => [useStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKey, ...(queryKey ?? [{ projectId, timestampGte, timestampLt }])];
export type DefaultServiceHealthHealthGetDefaultResponse = Awaited<ReturnType<typeof DefaultService.healthHealthGet>>;
export type DefaultServiceHealthHealthGetQueryResult<
  TData = DefaultServiceHealthHealthGetDefaultResponse,
  TError = unknown,
> = UseQueryResult<TData, TError>;
export const useDefaultServiceHealthHealthGetKey = 'DefaultServiceHealthHealthGet';
export const UseDefaultServiceHealthHealthGetKeyFn = (queryKey?: Array<unknown>) => [
  useDefaultServiceHealthHealthGetKey,
  ...(queryKey ?? []),
];
export type AuthServiceAuthJwtLoginAuthJwtLoginPostMutationResult = Awaited<ReturnType<typeof AuthService.authJwtLoginAuthJwtLoginPost>>;
export type AuthServiceAuthJwtLogoutAuthJwtLogoutPostMutationResult = Awaited<
  ReturnType<typeof AuthService.authJwtLogoutAuthJwtLogoutPost>
>;
export type AuthServiceRegisterRegisterAuthRegisterPostMutationResult = Awaited<
  ReturnType<typeof AuthService.registerRegisterAuthRegisterPost>
>;
export type AuthServiceResetForgotPasswordAuthForgotPasswordPostMutationResult = Awaited<
  ReturnType<typeof AuthService.resetForgotPasswordAuthForgotPasswordPost>
>;
export type AuthServiceResetResetPasswordAuthResetPasswordPostMutationResult = Awaited<
  ReturnType<typeof AuthService.resetResetPasswordAuthResetPasswordPost>
>;
export type AuthServiceVerifyRequestTokenAuthRequestVerifyTokenPostMutationResult = Awaited<
  ReturnType<typeof AuthService.verifyRequestTokenAuthRequestVerifyTokenPost>
>;
export type AuthServiceVerifyVerifyAuthVerifyPostMutationResult = Awaited<ReturnType<typeof AuthService.verifyVerifyAuthVerifyPost>>;
export type ProjectsServiceCreateProjectProjectsPostMutationResult = Awaited<ReturnType<typeof ProjectsService.createProjectProjectsPost>>;
export type ProjectsServiceAddUserToProjectProjectsProjectIdUsersPostMutationResult = Awaited<
  ReturnType<typeof ProjectsService.addUserToProjectProjectsProjectIdUsersPost>
>;
export type NluServiceCreateNluInboxItemNluInboxPostMutationResult = Awaited<ReturnType<typeof NluService.createNluInboxItemNluInboxPost>>;
export type NluServiceBulkUpdateNluInboxItemsNluInboxBulkUpdatePostMutationResult = Awaited<
  ReturnType<typeof NluService.bulkUpdateNluInboxItemsNluInboxBulkUpdatePost>
>;
export type NluServiceCreateAnnotationsDataAnnotationsDataPostMutationResult = Awaited<
  ReturnType<typeof NluService.createAnnotationsDataAnnotationsDataPost>
>;
export type ProjectsServiceUpdateProjectProjectsProjectIdPutMutationResult = Awaited<
  ReturnType<typeof ProjectsService.updateProjectProjectsProjectIdPut>
>;
export type ProjectsServiceUpdateUserRoleInProjectProjectsProjectIdUsersUserIdPutMutationResult = Awaited<
  ReturnType<typeof ProjectsService.updateUserRoleInProjectProjectsProjectIdUsersUserIdPut>
>;
export type ConversationsServiceUpdateConversationStatusConversationsConversationIdPutMutationResult = Awaited<
  ReturnType<typeof ConversationsService.updateConversationStatusConversationsConversationIdPut>
>;
export type NluServiceUpdateNluInboxItemNluInboxItemIdPutMutationResult = Awaited<
  ReturnType<typeof NluService.updateNluInboxItemNluInboxItemIdPut>
>;
export type NluServiceUpdateAnnotationsDataAnnotationsDataItemIdPutMutationResult = Awaited<
  ReturnType<typeof NluService.updateAnnotationsDataAnnotationsDataItemIdPut>
>;
export type UsersServiceUsersPatchCurrentUserUsersMePatchMutationResult = Awaited<
  ReturnType<typeof UsersService.usersPatchCurrentUserUsersMePatch>
>;
export type UsersServiceUsersPatchUserUsersIdPatchMutationResult = Awaited<ReturnType<typeof UsersService.usersPatchUserUsersIdPatch>>;
export type UsersServiceUsersDeleteUserUsersIdDeleteMutationResult = Awaited<ReturnType<typeof UsersService.usersDeleteUserUsersIdDelete>>;
export type ProjectsServiceDeleteProjectProjectsProjectIdDeleteMutationResult = Awaited<
  ReturnType<typeof ProjectsService.deleteProjectProjectsProjectIdDelete>
>;
export type ProjectsServiceRemoveUserFromProjectProjectsProjectIdUsersUserIdDeleteMutationResult = Awaited<
  ReturnType<typeof ProjectsService.removeUserFromProjectProjectsProjectIdUsersUserIdDelete>
>;
export type NluServiceDeleteNluInboxItemNluInboxItemIdDeleteMutationResult = Awaited<
  ReturnType<typeof NluService.deleteNluInboxItemNluInboxItemIdDelete>
>;
export type NluServiceDeleteAnnotationsDataAnnotationsDataItemIdDeleteMutationResult = Awaited<
  ReturnType<typeof NluService.deleteAnnotationsDataAnnotationsDataItemIdDelete>
>;
