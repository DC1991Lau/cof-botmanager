// generated with @7nohe/openapi-react-query-codegen@1.6.0

import { type QueryClient } from '@tanstack/react-query';
import { ConversationsService, DefaultService, NluService, ProjectsService, StatsService, UsersService } from '../requests/services.gen';
import * as Common from './common';
/**
 * Users:Current User
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const prefetchUseUsersServiceUsersCurrentUserUsersMeGet = (queryClient: QueryClient) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseUsersServiceUsersCurrentUserUsersMeGetKeyFn(),
    queryFn: () => UsersService.usersCurrentUserUsersMeGet(),
  });
/**
 * Users:User
 * @param data The data for the request.
 * @param data.id
 * @returns UserRead Successful Response
 * @throws ApiError
 */
export const prefetchUseUsersServiceUsersUserUsersIdGet = (
  queryClient: QueryClient,
  {
    id,
  }: {
    id: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseUsersServiceUsersUserUsersIdGetKeyFn({ id }),
    queryFn: () => UsersService.usersUserUsersIdGet({ id }),
  });
/**
 * Read Projects
 * @param data The data for the request.
 * @param data.name
 * @param data.description
 * @param data.urlConnection
 * @param data.port
 * @param data.queueName
 * @param data.active
 * @returns Project Successful Response
 * @throws ApiError
 */
export const prefetchUseProjectsServiceReadProjectsProjectsGet = (
  queryClient: QueryClient,
  {
    active,
    description,
    name,
    port,
    queueName,
    urlConnection,
  }: {
    active?: boolean;
    description?: string;
    name?: string;
    port?: number;
    queueName?: string;
    urlConnection?: string;
  } = {},
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseProjectsServiceReadProjectsProjectsGetKeyFn({ active, description, name, port, queueName, urlConnection }),
    queryFn: () => ProjectsService.readProjectsProjectsGet({ active, description, name, port, queueName, urlConnection }),
  });
/**
 * Read Projects
 * @returns User Successful Response
 * @throws ApiError
 */
export const prefetchUseProjectsServiceReadProjectsUsersGet = (queryClient: QueryClient) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseProjectsServiceReadProjectsUsersGetKeyFn(),
    queryFn: () => ProjectsService.readProjectsUsersGet(),
  });
/**
 * Read Project
 * @param data The data for the request.
 * @param data.projectId
 * @returns Project Successful Response
 * @throws ApiError
 */
export const prefetchUseProjectsServiceReadProjectProjectsProjectIdGet = (
  queryClient: QueryClient,
  {
    projectId,
  }: {
    projectId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseProjectsServiceReadProjectProjectsProjectIdGetKeyFn({ projectId }),
    queryFn: () => ProjectsService.readProjectProjectsProjectIdGet({ projectId }),
  });
/**
 * Read Project Users
 * @param data The data for the request.
 * @param data.projectId
 * @returns ProjectUsers Successful Response
 * @throws ApiError
 */
export const prefetchUseProjectsServiceReadProjectUsersProjectsProjectIdUsersGet = (
  queryClient: QueryClient,
  {
    projectId,
  }: {
    projectId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseProjectsServiceReadProjectUsersProjectsProjectIdUsersGetKeyFn({ projectId }),
    queryFn: () => ProjectsService.readProjectUsersProjectsProjectIdUsersGet({ projectId }),
  });
/**
 * Read Conversations
 * @param data The data for the request.
 * @param data.projectId
 * @param data.senderId
 * @param data.numberUserMessages
 * @param data.numberUserMessagesGte
 * @param data.latestInputChannel
 * @param data.latestEventTime
 * @param data.inTrainingData
 * @param data.evaluation
 * @param data.minimumActionConfidence
 * @param data.maximumActionConfidence
 * @param data.minimumIntentConfidence
 * @param data.maximumIntentConfidence
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const prefetchUseConversationsServiceReadConversationsConversationsGet = (
  queryClient: QueryClient,
  {
    evaluation,
    inTrainingData,
    latestEventTime,
    latestInputChannel,
    maximumActionConfidence,
    maximumIntentConfidence,
    minimumActionConfidence,
    minimumIntentConfidence,
    numberUserMessages,
    numberUserMessagesGte,
    projectId,
    senderId,
  }: {
    evaluation?: string;
    inTrainingData?: boolean;
    latestEventTime?: string;
    latestInputChannel?: string;
    maximumActionConfidence?: number;
    maximumIntentConfidence?: number;
    minimumActionConfidence?: number;
    minimumIntentConfidence?: number;
    numberUserMessages?: number;
    numberUserMessagesGte?: number;
    projectId: number;
    senderId?: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseConversationsServiceReadConversationsConversationsGetKeyFn({
      evaluation,
      inTrainingData,
      latestEventTime,
      latestInputChannel,
      maximumActionConfidence,
      maximumIntentConfidence,
      minimumActionConfidence,
      minimumIntentConfidence,
      numberUserMessages,
      numberUserMessagesGte,
      projectId,
      senderId,
    }),
    queryFn: () =>
      ConversationsService.readConversationsConversationsGet({
        evaluation,
        inTrainingData,
        latestEventTime,
        latestInputChannel,
        maximumActionConfidence,
        maximumIntentConfidence,
        minimumActionConfidence,
        minimumIntentConfidence,
        numberUserMessages,
        numberUserMessagesGte,
        projectId,
        senderId,
      }),
  });
/**
 * Read Conversation
 * @param data The data for the request.
 * @param data.conversationId
 * @returns Conversation Successful Response
 * @throws ApiError
 */
export const prefetchUseConversationsServiceReadConversationConversationsConversationIdGet = (
  queryClient: QueryClient,
  {
    conversationId,
  }: {
    conversationId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseConversationsServiceReadConversationConversationsConversationIdGetKeyFn({ conversationId }),
    queryFn: () => ConversationsService.readConversationConversationsConversationIdGet({ conversationId }),
  });
/**
 * Read Conversation Detail
 * @param data The data for the request.
 * @param data.conversationId
 * @returns ConversationDetail Successful Response
 * @throws ApiError
 */
export const prefetchUseConversationsServiceReadConversationDetailConversationsConversationIdDetailGet = (
  queryClient: QueryClient,
  {
    conversationId,
  }: {
    conversationId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseConversationsServiceReadConversationDetailConversationsConversationIdDetailGetKeyFn({ conversationId }),
    queryFn: () => ConversationsService.readConversationDetailConversationsConversationIdDetailGet({ conversationId }),
  });
/**
 * Read Nlu Inbox Items
 * @param data The data for the request.
 * @param data.projectId
 * @param data.conversationId
 * @param data.messageId
 * @param data.text
 * @param data.predictedIntent
 * @param data.confidence
 * @param data.confidenceGte
 * @param data.confidenceLte
 * @param data.isCorrect
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const prefetchUseNluServiceReadNluInboxItemsNluInboxGet = (
  queryClient: QueryClient,
  {
    annotatedIntent,
    annotatedIntentIsnull,
    confidence,
    confidenceGte,
    confidenceLte,
    conversationId,
    isCorrect,
    messageId,
    predictedIntent,
    projectId,
    text,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    confidence?: number;
    confidenceGte?: number;
    confidenceLte?: number;
    conversationId?: number;
    isCorrect?: boolean;
    messageId?: string;
    predictedIntent?: string;
    projectId?: number;
    text?: string;
  } = {},
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseNluServiceReadNluInboxItemsNluInboxGetKeyFn({
      annotatedIntent,
      annotatedIntentIsnull,
      confidence,
      confidenceGte,
      confidenceLte,
      conversationId,
      isCorrect,
      messageId,
      predictedIntent,
      projectId,
      text,
    }),
    queryFn: () =>
      NluService.readNluInboxItemsNluInboxGet({
        annotatedIntent,
        annotatedIntentIsnull,
        confidence,
        confidenceGte,
        confidenceLte,
        conversationId,
        isCorrect,
        messageId,
        predictedIntent,
        projectId,
        text,
      }),
  });
/**
 * Read Nlu Inbox Item
 * @param data The data for the request.
 * @param data.itemId
 * @returns NLUInboxItem Successful Response
 * @throws ApiError
 */
export const prefetchUseNluServiceReadNluInboxItemNluInboxItemIdGet = (
  queryClient: QueryClient,
  {
    itemId,
  }: {
    itemId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseNluServiceReadNluInboxItemNluInboxItemIdGetKeyFn({ itemId }),
    queryFn: () => NluService.readNluInboxItemNluInboxItemIdGet({ itemId }),
  });
/**
 * Read Annotations Data
 * @param data The data for the request.
 * @param data.projectId
 * @param data.text
 * @param data.annotatedIntent
 * @param data.annotatedIntentIsnull
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns AnnotationsData Successful Response
 * @throws ApiError
 */
export const prefetchUseNluServiceReadAnnotationsDataAnnotationsDataGet = (
  queryClient: QueryClient,
  {
    annotatedIntent,
    annotatedIntentIsnull,
    projectId,
    text,
    timestampGte,
    timestampLt,
  }: {
    annotatedIntent?: string;
    annotatedIntentIsnull?: boolean;
    projectId?: number;
    text?: string;
    timestampGte?: string;
    timestampLt?: string;
  } = {},
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseNluServiceReadAnnotationsDataAnnotationsDataGetKeyFn({
      annotatedIntent,
      annotatedIntentIsnull,
      projectId,
      text,
      timestampGte,
      timestampLt,
    }),
    queryFn: () =>
      NluService.readAnnotationsDataAnnotationsDataGet({
        annotatedIntent,
        annotatedIntentIsnull,
        projectId,
        text,
        timestampGte,
        timestampLt,
      }),
  });
/**
 * Get General Stats
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns GeneralStats Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetGeneralStatsStatsGeneralGet = (
  queryClient: QueryClient,
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetGeneralStatsStatsGeneralGetKeyFn({ projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getGeneralStatsStatsGeneralGet({ projectId, timestampGte, timestampLt }),
  });
/**
 * Get Sessions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsDistribution Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetSessionsDistributionStatsSessionsDistributionGet = (
  queryClient: QueryClient,
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetSessionsDistributionStatsSessionsDistributionGetKeyFn({ projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getSessionsDistributionStatsSessionsDistributionGet({ projectId, timestampGte, timestampLt }),
  });
/**
 * Get Sessions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns SessionsPerChannel Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGet = (
  queryClient: QueryClient,
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetSessionsPerChannelStatsSessionsPerChannelGetKeyFn({ projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getSessionsPerChannelStatsSessionsPerChannelGet({ projectId, timestampGte, timestampLt }),
  });
/**
 * Get Senders Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersDistribution Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetSendersDistributionStatsSendersDistributionGet = (
  queryClient: QueryClient,
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetSendersDistributionStatsSendersDistributionGetKeyFn({ lastSeenGte, lastSeenLt, projectId }),
    queryFn: () => StatsService.getSendersDistributionStatsSendersDistributionGet({ lastSeenGte, lastSeenLt, projectId }),
  });
/**
 * Get Senders Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.lastSeenLt
 * @param data.lastSeenGte
 * @returns SendersPerChannel Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetSendersPerChannelStatsSendersPerChannelGet = (
  queryClient: QueryClient,
  {
    lastSeenGte,
    lastSeenLt,
    projectId,
  }: {
    lastSeenGte?: string;
    lastSeenLt?: string;
    projectId: number;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetSendersPerChannelStatsSendersPerChannelGetKeyFn({ lastSeenGte, lastSeenLt, projectId }),
    queryFn: () => StatsService.getSendersPerChannelStatsSendersPerChannelGet({ lastSeenGte, lastSeenLt, projectId }),
  });
/**
 * Get Actions Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsDistribution Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetActionsDistributionStatsActionsDistributionGet = (
  queryClient: QueryClient,
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetActionsDistributionStatsActionsDistributionGetKeyFn({ name, projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getActionsDistributionStatsActionsDistributionGet({ name, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Actions Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ActionsPerChannel Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetActionsPerChannelStatsActionsPerChannelGet = (
  queryClient: QueryClient,
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetActionsPerChannelStatsActionsPerChannelGetKeyFn({ name, projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getActionsPerChannelStatsActionsPerChannelGet({ name, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Top Actions
 * @param data The data for the request.
 * @param data.projectId
 * @param data.name
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopAction Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetTopActionsStatsTopActionsGet = (
  queryClient: QueryClient,
  {
    name,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    name: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetTopActionsStatsTopActionsGetKeyFn({ name, projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getTopActionsStatsTopActionsGet({ name, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Intents Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsDistribution Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetIntentsDistributionStatsIntentsDistributionGet = (
  queryClient: QueryClient,
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetIntentsDistributionStatsIntentsDistributionGetKeyFn({
      intent,
      projectId,
      timestampGte,
      timestampLt,
    }),
    queryFn: () => StatsService.getIntentsDistributionStatsIntentsDistributionGet({ intent, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Intents Per Channel
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns IntentsPerChannel Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGet = (
  queryClient: QueryClient,
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetIntentsPerChannelStatsIntentsPerChannelGetKeyFn({ intent, projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getIntentsPerChannelStatsIntentsPerChannelGet({ intent, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Top Intents
 * @param data The data for the request.
 * @param data.projectId
 * @param data.intent
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns TopIntent Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetTopIntentsStatsTopIntentsGet = (
  queryClient: QueryClient,
  {
    intent,
    projectId,
    timestampGte,
    timestampLt,
  }: {
    intent?: string;
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetTopIntentsStatsTopIntentsGetKeyFn({ intent, projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getTopIntentsStatsTopIntentsGet({ intent, projectId, timestampGte, timestampLt }),
  });
/**
 * Get Response Time Distribution
 * @param data The data for the request.
 * @param data.projectId
 * @param data.timestampLt
 * @param data.timestampGte
 * @returns ResponseTimeDistribution Successful Response
 * @throws ApiError
 */
export const prefetchUseStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGet = (
  queryClient: QueryClient,
  {
    projectId,
    timestampGte,
    timestampLt,
  }: {
    projectId: number;
    timestampGte?: string;
    timestampLt?: string;
  },
) =>
  queryClient.prefetchQuery({
    queryKey: Common.UseStatsServiceGetResponseTimeDistributionStatsAvgResponseTimeGetKeyFn({ projectId, timestampGte, timestampLt }),
    queryFn: () => StatsService.getResponseTimeDistributionStatsAvgResponseTimeGet({ projectId, timestampGte, timestampLt }),
  });
/**
 * Health
 * @returns unknown Successful Response
 * @throws ApiError
 */
export const prefetchUseDefaultServiceHealthHealthGet = (queryClient: QueryClient) =>
  queryClient.prefetchQuery({ queryKey: Common.UseDefaultServiceHealthHealthGetKeyFn(), queryFn: () => DefaultService.healthHealthGet() });
