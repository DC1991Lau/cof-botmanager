import path from 'path';
import { defineConfig } from 'vite';
import { common } from './vite.common';

export default defineConfig({
  ...common,
  server: {},
  plugins: [...common.plugins],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
