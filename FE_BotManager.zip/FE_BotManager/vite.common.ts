import path from 'path';
import svgr from 'vite-plugin-svgr';
import react from '@vitejs/plugin-react';
import { resolve as resolvePath } from 'path';
import { UserConfig } from 'vite';

export const common: UserConfig = {
  resolve: {
    alias: {
      '$fontpath': resolvePath('./node_modules/@/components/ui/fonts'),
      '@': path.resolve(__dirname, './src'),
    },
  },
  preview: {
    port: 7500,
    strictPort: true,
  },
  plugins: [react(), svgr()],
};
