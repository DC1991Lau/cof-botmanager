# TODO

Describe here what is needed for the developer continue working in the LIB environment...

## Important

When adding dependencies that are not dev dependencies, always add them as peer:
`pnpm i --save-peer @cofidis/api`

Dependencies should be defined in the peer because if the way that module federation will know that should add them to the shared modules, otherwise you may endup ship duplicated code in some mfe that is consuming this lib

## Tasks

## Tools

## Setup

## First steps
